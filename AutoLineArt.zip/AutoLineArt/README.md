# Auto Line Art (Android)

Starter project Kotlin/Android for converting a selected image to a monochrome preview, showing a movable/resizable overlay, and experimenting with Accessibility gesture tracing.

## Build APK with GitHub Actions (from Android phone)
1. Create a GitHub repository (e.g. `AutoLineArt`).
2. Upload the **contents** of this ZIP to the repository root (so `settings.gradle.kts` is at root). You can use GitHub's web upload, or extract on Android and push with Termux.
3. Open the repository's **Actions** tab and run **Build Auto Line Art APK** using **Run workflow**. A push to `main`/`master` also triggers a build.
4. Open the completed workflow run, scroll to **Artifacts**, and download `AutoLineArt-debug-apk`. Extract the downloaded artifact ZIP to get `app-debug.apk`.
5. Install the APK. Android may ask you to allow installation from that browser/file manager.

## First use
1. Open Auto Line Art and select a reference image.
2. Adjust threshold. This starter uses simple grayscale thresholding, not AI semantic contour extraction; dark shadows and textures may also become black.
3. Grant **Display over other apps** and open the overlay.
4. In Android Settings > Accessibility, enable **Auto Line Art**.
5. Open ibis Paint X and test only on a blank/test canvas first. Keep the overlay out of the drawing area when not tracing.

## Important limitations
- This is a starter implementation, not a verified production app. It has not been built on a real device in this environment.
- Android Accessibility gestures are screen-level input and may not be accepted by every app/device. Use only on your own device and while you can supervise it.
- The current raster tracer maps to a central screen region and does **not** read the actual overlay bounds. You may need to adjust the mapping in `DrawingAccessibilityService.kt` to your device/canvas. It can be slow and may create discontinuous horizontal strokes rather than smooth vector curves.
- The overlay displays the reference image, so align it carefully and avoid having it cover the destination canvas during tracing. For a reliable version, the next iteration should add explicit target-area calibration, contour extraction/vectorization, pause/resume and a drawing-speed control.
- The GitHub workflow creates an unsigned debug APK suitable for testing; it is not a Play Store release build.

## Project structure
- `app/src/main/java/.../MainActivity.kt`: image selection and threshold preview
- `FloatingOverlayService.kt`: floating reference window
- `DrawingAccessibilityService.kt`: accessibility gesture tracer
- `.github/workflows/build-apk.yml`: cloud build pipeline
