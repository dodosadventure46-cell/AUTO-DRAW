package com.example.autolineart

import android.graphics.Bitmap

object TraceState {
    @Volatile var bitmap: Bitmap? = null
    @Volatile var threshold: Int = 170
    @Volatile var detailStep: Int = 3
    @Volatile var traceRequested: Boolean = false
    @Volatile var targetX: Float = 0f
    @Volatile var targetY: Float = 0f
    @Volatile var targetW: Float = 0f
    @Volatile var targetH: Float = 0f
}
