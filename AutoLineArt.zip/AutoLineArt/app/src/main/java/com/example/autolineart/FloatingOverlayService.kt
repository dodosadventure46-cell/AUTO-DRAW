package com.example.autolineart

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*
import kotlin.math.abs

class FloatingOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private lateinit var params: WindowManager.LayoutParams
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (panel != null) return START_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(6,6,6,6); background = GradientDrawable().apply { setColor(0xDDEFEAFF.toInt()); cornerRadius = 14f; setStroke(2, Color.rgb(103,80,164)) } }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val label = TextView(this).apply { text = "Auto Line Art  ⋮"; textSize = 12f; setTextColor(Color.BLACK); setPadding(6,4,6,4) }
        val hide = TextView(this).apply { text = "×"; textSize = 20f; setTextColor(Color.BLACK); setPadding(10,0,10,0); setOnClickListener { stopSelf() } }
        bar.addView(label, LinearLayout.LayoutParams(0, -2, 1f)); bar.addView(hide)
        root.addView(bar)
        val image = ImageView(this).apply { setImageBitmap(TraceState.bitmap); scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(Color.WHITE); alpha = 0.72f; contentDescription = "Gambar line art untuk ditelusuri" }
        root.addView(image, LinearLayout.LayoutParams(-1, 300))
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val trace = Button(this).apply { text = "Mulai trace"; textSize = 11f; isAllCaps = false; setOnClickListener {
            if (DrawingAccessibilityService.instance == null) Toast.makeText(this@FloatingOverlayService, "Aktifkan Auto Line Art di Accessibility dahulu", Toast.LENGTH_LONG).show()
            else { DrawingAccessibilityService.instance?.startTracing(); Toast.makeText(this@FloatingOverlayService, "Tracing dimulai. Jangan sentuh layar.", Toast.LENGTH_SHORT).show() }
        } }
        val stop = Button(this).apply { text = "Stop"; textSize = 11f; isAllCaps = false; setOnClickListener { DrawingAccessibilityService.instance?.stopTracing() } }
        buttons.addView(trace, LinearLayout.LayoutParams(0, -2, 1f)); buttons.addView(stop, LinearLayout.LayoutParams(0, -2, 1f)); root.addView(buttons)
        params = WindowManager.LayoutParams(420, WindowManager.LayoutParams.WRAP_CONTENT, if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 120 }
        fun updateTargetBounds() {
            val bmp = TraceState.bitmap ?: return
            val loc = IntArray(2)
            image.getLocationOnScreen(loc)
            val vw = image.width.toFloat(); val vh = image.height.toFloat()
            if (vw <= 0f || vh <= 0f) return
            val scale = minOf(vw / bmp.width.toFloat(), vh / bmp.height.toFloat())
            TraceState.targetW = bmp.width * scale
            TraceState.targetH = bmp.height * scale
            TraceState.targetX = loc[0] + (vw - TraceState.targetW) / 2f
            TraceState.targetY = loc[1] + (vh - TraceState.targetH) / 2f
        }
        root.post { updateTargetBounds() }
        var startX = 0; var startY = 0; var downX = 0f; var downY = 0f
        bar.setOnTouchListener { _, event -> when (event.action) {
            MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; downX = event.rawX; downY = event.rawY; true }
            MotionEvent.ACTION_MOVE -> { params.x = startX + (event.rawX - downX).toInt(); params.y = startY + (event.rawY - downY).toInt(); wm.updateViewLayout(root, params); root.post { updateTargetBounds() }; true }
            else -> true
        } }
        // Drag the resize grip at the bottom-right to change overlay dimensions.
        val grip = TextView(this).apply { text = "⤢  Resize"; gravity = Gravity.END; setTextColor(Color.DKGRAY); textSize = 11f; setPadding(8,4,8,4) }
        root.addView(grip)
        var sw = 0; var sh = 0; var sx = 0f; var sy = 0f
        grip.setOnTouchListener { _, e -> when (e.action) {
            MotionEvent.ACTION_DOWN -> { sw = params.width; sh = (image.layoutParams.height); sx = e.rawX; sy = e.rawY; true }
            MotionEvent.ACTION_MOVE -> { params.width = (sw + e.rawX - sx).toInt().coerceIn(240, 900); image.layoutParams.height = (sh + e.rawY - sy).toInt().coerceIn(140, 900); wm.updateViewLayout(root, params); root.post { updateTargetBounds() }; true }
            else -> true
        } }
        panel = root
        wm.addView(root, params)
        return START_STICKY
    }

    override fun onDestroy() { if (panel != null) { try { wm.removeView(panel) } catch (_: Exception) {}; panel = null }; super.onDestroy() }
}
