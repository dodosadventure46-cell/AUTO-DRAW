package com.example.autolineart

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import java.util.concurrent.atomic.AtomicBoolean

class DrawingAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: DrawingAccessibilityService? = null }
    private val running = AtomicBoolean(false)
    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopTracing() }
    override fun onDestroy() { instance = null; stopTracing(); super.onDestroy() }

    fun stopTracing() { running.set(false) }
    fun startTracing() {
        val bitmap = TraceState.bitmap ?: run { Toast.makeText(this, "Pilih gambar dahulu", Toast.LENGTH_SHORT).show(); return }
        if (!running.compareAndSet(false, true)) return
        Thread { traceBitmap(bitmap) }.start()
    }

    // Sends horizontal black runs as short strokes. This is a first-pass raster tracer;
    // it requires the floating image to be aligned over the destination canvas.
    private fun traceBitmap(bitmap: Bitmap) {
        // The overlay publishes the exact on-screen bounds of its FIT_CENTER image.
        // If the overlay is moved/resized, those bounds are updated before the trace begins.
        val targetW = TraceState.targetW
        val targetH = TraceState.targetH
        val left = TraceState.targetX
        val top = TraceState.targetY
        if (targetW <= 0f || targetH <= 0f) {
            running.set(false)
            android.os.Handler(mainLooper).post { Toast.makeText(this, "Tunggu sampai gambar overlay tampil, lalu coba lagi", Toast.LENGTH_LONG).show() }
            return
        }
        val step = maxOf(2, TraceState.detailStep)
        var y = 0
        while (y < bitmap.height && running.get()) {
            var x = 0
            while (x < bitmap.width && running.get()) {
                while (x < bitmap.width && !isBlack(bitmap, x, y)) x += step
                if (x >= bitmap.width) break
                val start = x
                while (x < bitmap.width && isBlack(bitmap, x, y)) x += step
                val end = (x - step).coerceAtLeast(start)
                if (end - start >= step) {
                    val path = Path().apply {
                        moveTo(left + start.toFloat() / bitmap.width * targetW, top + y.toFloat() / bitmap.height * targetH)
                        lineTo(left + end.toFloat() / bitmap.width * targetW, top + y.toFloat() / bitmap.height * targetH)
                    }
                    val stroke = GestureDescription.StrokeDescription(path, 0, maxOf(35L, (end-start).toLong()/2))
                    val gesture = GestureDescription.Builder().addStroke(stroke).build()
                    dispatchGesture(gesture, null, null)
                    try { Thread.sleep(55) } catch (_: InterruptedException) { }
                }
            }
            y += step
            try { Thread.sleep(12) } catch (_: InterruptedException) { }
        }
        running.set(false)
        android.os.Handler(mainLooper).post { Toast.makeText(this, "Tracing selesai atau dihentikan", Toast.LENGTH_SHORT).show() }
    }
    private fun isBlack(bitmap: Bitmap, x: Int, y: Int): Boolean = Color.red(bitmap.getPixel(x,y)) < 100
}
