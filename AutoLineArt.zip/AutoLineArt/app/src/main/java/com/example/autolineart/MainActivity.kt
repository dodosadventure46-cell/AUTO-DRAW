package com.example.autolineart

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private var original: Bitmap? = null
    private var lineArt: Bitmap? = null
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var thresholdSeek: SeekBar
    private lateinit var detailSeek: SeekBar
    private val pickImage = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 22, 20, 18); setBackgroundColor(Color.rgb(248,247,250)) }
        val title = TextView(this).apply { text = "AUTO LINE ART"; textSize = 24f; setTextColor(Color.rgb(45,38,60)); gravity = Gravity.CENTER; setPadding(0, 4, 0, 8) }
        val subtitle = TextView(this).apply { text = "Ubah gambar jadi garis, lalu tracing lewat overlay."; textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.DKGRAY) }
        root.addView(title); root.addView(subtitle)
        val choose = button("1. Pilih gambar referensi") { val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }; startActivityForResult(i, pickImage) }
        root.addView(choose, matchWrap())
        preview = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(Color.WHITE) }
        root.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = 12; bottomMargin = 10 })
        root.addView(TextView(this).apply { text = "Ambang hitam (threshold)"; textSize = 14f })
        thresholdSeek = SeekBar(this).apply { max = 255; progress = 170; setOnSeekBarChangeListener(simpleChange { TraceState.threshold = it; rebuild() }) }
        root.addView(thresholdSeek, matchWrap())
        root.addView(TextView(this).apply { text = "Detail garis (lebih kecil = lebih detail, lebih lambat)"; textSize = 14f })
        detailSeek = SeekBar(this).apply { max = 7; progress = 3; setOnSeekBarChangeListener(simpleChange { TraceState.detailStep = (it + 1).coerceAtLeast(1); rebuild() }) }
        root.addView(detailSeek, matchWrap())
        root.addView(button("2. Tampilkan jendela mengambang") { showOverlay() }, matchWrap())
        root.addView(button("Buka pengaturan Accessibility") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, matchWrap())
        status = TextView(this).apply { text = "Pilih gambar untuk memulai. Aktifkan layanan Accessibility hanya jika ingin auto-tracing."; textSize = 12f; setTextColor(Color.DKGRAY); setPadding(4, 8, 4, 0) }
        root.addView(status, matchWrap())
        setContentView(root)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; isAllCaps = false; setOnClickListener { action() } }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun simpleChange(f: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) f(progress) }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    @Deprecated("Deprecated in Android API but works for this simple sample")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickImage && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri).use { stream -> original = BitmapFactory.decodeStream(stream) }
                rebuild()
                status.text = "Gambar dimuat. Atur threshold/detail, lalu tampilkan overlay."
            } catch (e: Exception) { status.text = "Gagal membuka gambar: ${e.message}" }
        }
    }

    private fun rebuild() {
        val src = original ?: return
        val maxDim = 700
        val scale = minOf(1f, maxDim.toFloat() / maxOf(src.width, src.height))
        val small = Bitmap.createScaledBitmap(src, (src.width * scale).toInt().coerceAtLeast(1), (src.height * scale).toInt().coerceAtLeast(1), true)
        val out = Bitmap.createBitmap(small.width, small.height, Bitmap.Config.ARGB_8888)
        val threshold = TraceState.threshold
        val step = TraceState.detailStep.coerceAtLeast(1)
        for (y in 0 until small.height) for (x in 0 until small.width) {
            val c = small.getPixel(x, y)
            val gray = (Color.red(c) * 0.299 + Color.green(c) * 0.587 + Color.blue(c) * 0.114).toInt()
            // Basic monochrome threshold. This keeps dark contours; it is not semantic line-art extraction.
            val adjusted = if (step > 1 && gray > threshold - step * 2) 255 else gray
            out.setPixel(x, y, if (adjusted < threshold) Color.BLACK else Color.WHITE)
        }
        lineArt = out
        TraceState.bitmap = out
        preview.setImageBitmap(out)
    }

    private fun showOverlay() {
        if (lineArt == null) { status.text = "Pilih gambar terlebih dahulu."; return }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            status.text = "Izinkan 'Tampil di atas aplikasi lain', lalu tekan tombol ini lagi."
            return
        }
        startService(Intent(this, FloatingOverlayService::class.java))
        status.text = "Overlay aktif. Geser/ubah ukuran kotak; gunakan ibis Paint X di bawahnya."
    }
}
