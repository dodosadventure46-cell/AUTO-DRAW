package com.autodraw;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

/** Helper kecil untuk membangun UI lewat kode (tanpa file layout). */
final class Ui {
    static final int BG = 0xFF0F1020;
    static final int CARD = 0xFF191A33;
    static final int CARD_HI = 0xFF23254A;
    static final int INSET = 0xFF11122A;
    static final int ACCENT = 0xFF7C5CFF;
    static final int ACCENT_SOFT = 0x337C5CFF;
    static final int BTN = 0xFF34376A;
    static final int TEXT = 0xFFF2F2F8;
    static final int MUTED = 0xFFA9ACCB;
    static final int DANGER = 0xFFE5484D;
    static final int OK = 0xFF3DD68C;
    static final int LINE = 0x1FFFFFFF;

    private Ui() {}

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable round(int color, float radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        return g;
    }

    static GradientDrawable stroke(int fill, int line, float radiusPx, int linePx) {
        GradientDrawable g = round(fill, radiusPx);
        g.setStroke(linePx, line);
        return g;
    }

    /** Latar membulat + efek riak saat disentuh. */
    static Drawable ripple(int fill, float radiusPx) {
        return new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), round(fill, radiusPx),
                round(0xFFFFFFFF, radiusPx));
    }

    static TextView text(Context c, CharSequence s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    /** Teks keterangan kecil. */
    static TextView hint(Context c, CharSequence s) {
        TextView t = text(c, s, 12.5f, MUTED, false);
        t.setLineSpacing(0f, 1.12f);
        return t;
    }

    static TextView button(Context c, CharSequence s, int bg) {
        TextView t = text(c, s, 14, 0xFFFFFFFF, true);
        t.setGravity(Gravity.CENTER);
        t.setMinHeight(dp(c, 46));
        t.setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10));
        t.setBackground(ripple(bg, dp(c, 12)));
        t.setClickable(true);
        return t;
    }

    /** Label kecil membulat (mis. "Baru"). */
    static TextView chip(Context c, CharSequence s, int bg, int fg) {
        TextView t = text(c, s, 10.5f, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 7), dp(c, 2), dp(c, 7), dp(c, 2));
        t.setBackground(round(bg, dp(c, 20)));
        return t;
    }

    static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(LINE);
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, Math.max(1, dp(c, 1))));
        return v;
    }

    static void styleSwitch(Switch s) {
        int[][] st = {{android.R.attr.state_checked}, {}};
        s.setThumbTintList(new ColorStateList(st, new int[]{0xFFFFFFFF, 0xFFC9CBE3}));
        s.setTrackTintList(new ColorStateList(st, new int[]{ACCENT, 0xFF4A4D78}));
    }

    /** Kontrol pilihan bergaya segmented (2-4 pilihan sejajar). */
    static final class Seg extends LinearLayout {
        interface OnPick { void pick(int index); }

        private final TextView[] tabs;
        private final Context ctx;

        Seg(Context c, String[] labels, boolean compact, final OnPick cb) {
            super(c);
            ctx = c;
            setOrientation(HORIZONTAL);
            int pad = dp(c, 3);
            setPadding(pad, pad, pad, pad);
            setBackground(round(compact ? 0x00000000 : INSET, dp(c, compact ? 10 : 14)));
            tabs = new TextView[labels.length];
            for (int i = 0; i < labels.length; i++) {
                final int idx = i;
                TextView t = text(c, labels[i], compact ? 12 : 13.5f, TEXT, true);
                t.setGravity(Gravity.CENTER);
                t.setSingleLine(true);
                t.setClickable(true);
                t.setMinHeight(dp(c, compact ? 32 : 40));
                t.setPadding(dp(c, compact ? 10 : 8), 0, dp(c, compact ? 10 : 8), 0);
                t.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        select(idx);
                        if (cb != null) cb.pick(idx);
                    }
                });
                LayoutParams lp = new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
                if (i > 0) lp.leftMargin = dp(c, 3);
                tabs[i] = t;
                addView(t, lp);
            }
        }

        void select(int sel) {
            for (int i = 0; i < tabs.length; i++) {
                boolean on = i == sel;
                tabs[i].setBackground(on ? ripple(ACCENT, dp(ctx, 11)) : ripple(0x00000000, dp(ctx, 11)));
                tabs[i].setTextColor(on ? 0xFFFFFFFF : MUTED);
            }
        }
    }
}
