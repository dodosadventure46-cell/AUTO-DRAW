package com.autodraw;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.TextView;

/** Helper kecil untuk membangun UI lewat kode (tanpa file layout). */
final class Ui {
    static final int BG = 0xFF12132A;
    static final int CARD = 0xFF1E2040;
    static final int ACCENT = 0xFF7C5CFF;
    static final int BTN = 0xFF3B3D66;
    static final int TEXT = 0xFFF2F2F8;
    static final int MUTED = 0xFFA3A6C4;
    static final int DANGER = 0xFFE5484D;

    private Ui() {}

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable round(int color, float radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        return g;
    }

    static TextView text(Context c, CharSequence s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static TextView button(Context c, CharSequence s, int bg) {
        TextView t = text(c, s, 14, 0xFFFFFFFF, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10));
        t.setBackground(round(bg, dp(c, 12)));
        t.setClickable(true);
        return t;
    }
}
