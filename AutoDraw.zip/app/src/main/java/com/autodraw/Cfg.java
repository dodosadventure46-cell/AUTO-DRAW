package com.autodraw;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;

/** Pengaturan aplikasi + gambar referensi yang dipakai bersama MainActivity dan DrawService. */
public final class Cfg {
    public static final int MODE_CONTOUR = 0, MODE_SCAN = 1, MODE_TWO = 2, MODE_HUMAN = 3;
    public static final int VIEW_FULL = 0, VIEW_LINES = 1;
    private static final int MAX_DOWNLOAD = 25 * 1024 * 1024;

    public interface RefListener {
        void onRef();
    }

    /** Dipanggil saat sebuah pengaturan berubah (key = nama pengaturan). */
    public interface SettingsListener {
        void onSetting(String key);
    }

    /** Hasil muat gambar dari URL: error == null berarti berhasil. */
    public interface LoadCb {
        void onResult(String error);
    }

    private static SharedPreferences sp;
    private static final ArrayList<RefListener> listeners = new ArrayList<>();
    private static final ArrayList<SettingsListener> setListeners = new ArrayList<>();

    /** Gambar referensi (sisi terpanjang maks 1600 px). null = belum dipilih. */
    public static Bitmap ref;
    /** Keterangan asal gambar, mis. "galeri" atau "example.com". */
    public static String refSource = "";

    private Cfg() {}

    public static void init(Context c) {
        if (sp == null) {
            sp = c.getApplicationContext().getSharedPreferences("autodraw", Context.MODE_PRIVATE);
        }
    }

    public static int geti(String k, int d) { return sp == null ? d : sp.getInt(k, d); }
    public static void puti(String k, int v) {
        if (sp != null) { sp.edit().putInt(k, v).apply(); notifySetting(k); }
    }
    public static boolean getb(String k, boolean d) { return sp == null ? d : sp.getBoolean(k, d); }
    public static void putb(String k, boolean v) {
        if (sp != null) { sp.edit().putBoolean(k, v).apply(); notifySetting(k); }
    }

    public static int mode() { return geti("mode", MODE_CONTOUR); }
    public static int grid() { return geti("grid", 8); }
    public static int threshold() { return geti("thr", 110); }
    public static int speed() { return geti("speed", 5); }
    public static int brush() { return geti("brush", 6); }
    /** Seberapa "kasar" gaya tangan di mode Manusiawi (1..10). */
    public static int human() { return geti("human", 5); }
    /** Tampilan di kotak gambar: VIEW_FULL (gambar asli) atau VIEW_LINES (garis hitam terdeteksi). */
    public static int viewMode() { return geti("viewmode", VIEW_FULL); }
    public static boolean fillThick() { return getb("fill", true); }
    public static boolean anim() { return getb("anim", true); }
    public static boolean noZoom() { return getb("nozoom", true); }
    /** Panel pengaturan lengkap melayang (false = mode jangan ganggu). */
    public static boolean overlayFull() { return getb("ovfull", false); }
    /** BARU: tombol "Gambar" di layar mengambang untuk memasukkan gambar referensi. */
    public static boolean overlayPick() { return getb("ovpick", false); }

    public static void addListener(RefListener l) {
        if (!listeners.contains(l)) listeners.add(l);
    }

    public static void removeListener(RefListener l) {
        listeners.remove(l);
    }

    public static void addSettingsListener(SettingsListener l) {
        if (!setListeners.contains(l)) setListeners.add(l);
    }

    public static void removeSettingsListener(SettingsListener l) {
        setListeners.remove(l);
    }

    private static void notifySetting(String k) {
        for (SettingsListener l : new ArrayList<>(setListeners)) l.onSetting(k);
    }

    private static void notifyRef() {
        for (RefListener l : new ArrayList<>(listeners)) l.onRef();
    }

    /** Muat gambar dari Uri di thread terpisah, lalu panggil listener + done di main thread. */
    public static void load(Context ctx, final Uri uri, final Runnable done) {
        final Context app = ctx.getApplicationContext();
        final Handler h = new Handler(Looper.getMainLooper());
        new Thread(new Runnable() {
            @Override public void run() {
                Bitmap b = null;
                try {
                    InputStream in = app.getContentResolver().openInputStream(uri);
                    b = decode(readAll(in, MAX_DOWNLOAD));
                } catch (Throwable t) {
                    b = null;
                }
                final Bitmap fb = b;
                h.post(new Runnable() {
                    @Override public void run() {
                        if (fb != null) {
                            ref = fb;
                            refSource = "galeri";
                            notifyRef();
                        }
                        if (done != null) done.run();
                    }
                });
            }
        }).start();
    }

    /** Unduh gambar dari URL (http/https) lalu jadikan gambar referensi. cb dipanggil di main thread. */
    public static void loadUrl(final String raw, final LoadCb cb) {
        final Handler h = new Handler(Looper.getMainLooper());
        new Thread(new Runnable() {
            @Override public void run() {
                Bitmap b = null;
                String err = null;
                String host = "";
                try {
                    String u = raw == null ? "" : raw.trim();
                    if (u.isEmpty()) throw new IllegalArgumentException("URL masih kosong");
                    if (!u.contains("://")) u = "https://" + u;
                    URL url = new URL(u);
                    String proto = url.getProtocol();
                    if (!proto.equals("http") && !proto.equals("https")) {
                        throw new IllegalArgumentException("Hanya URL http atau https yang didukung");
                    }
                    host = url.getHost();
                    byte[] data = download(url);
                    b = decode(data);
                    if (b == null) {
                        err = looksLikeHtml(data)
                                ? "Link ini halaman web, bukan file gambar. Pakai link langsung ke gambar (berakhiran .jpg, .png, .webp)."
                                : "Format gambar tidak didukung atau file rusak.";
                    }
                } catch (UnknownHostException e) {
                    err = "Alamat tidak ditemukan. Periksa link dan koneksi internet.";
                } catch (SocketTimeoutException e) {
                    err = "Waktu habis. Server terlalu lama membalas.";
                } catch (IllegalArgumentException e) {
                    err = e.getMessage();
                } catch (java.net.MalformedURLException e) {
                    err = "Format link tidak valid.";
                } catch (OutOfMemoryError e) {
                    err = "Gambar terlalu besar untuk dimuat.";
                } catch (Throwable t) {
                    String m = t.getMessage();
                    err = "Gagal mengunduh" + (m == null || m.isEmpty() ? "." : ": " + m);
                }
                final Bitmap fb = err == null ? b : null;
                final String fe = fb == null && err == null ? "Gagal membaca gambar." : err;
                final String fh = host;
                h.post(new Runnable() {
                    @Override public void run() {
                        if (fb != null) {
                            ref = fb;
                            refSource = fh;
                            notifyRef();
                        }
                        if (cb != null) cb.onResult(fe);
                    }
                });
            }
        }).start();
    }

    // ------------------------------------------------------------------ util muat gambar

    private static byte[] download(URL start) throws Exception {
        URL url = start;
        for (int hop = 0; hop < 6; hop++) {
            HttpURLConnection c = (HttpURLConnection) url.openConnection();
            try {
                c.setInstanceFollowRedirects(false);   // redirect diikuti manual (termasuk http -> https)
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AutoDraw/2.3");
                c.setRequestProperty("Accept", "image/*,*/*;q=0.8");
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) {
                    String loc = c.getHeaderField("Location");
                    if (loc == null) throw new IllegalArgumentException("Redirect tanpa tujuan");
                    url = new URL(url, loc);
                    String p = url.getProtocol();
                    if (!p.equals("http") && !p.equals("https")) {
                        throw new IllegalArgumentException("Redirect ke alamat yang tidak didukung");
                    }
                    continue;
                }
                if (code != 200) {
                    throw new IllegalArgumentException("Server membalas HTTP " + code
                            + (code == 403 || code == 401 ? " (akses ditolak)" : code == 404 ? " (tidak ditemukan)" : ""));
                }
                if (c.getContentLength() > MAX_DOWNLOAD) {
                    throw new IllegalArgumentException("File terlalu besar (maks 25 MB)");
                }
                InputStream in = c.getInputStream();
                try {
                    return readAll(in, MAX_DOWNLOAD);
                } finally {
                    in.close();
                }
            } finally {
                c.disconnect();
            }
        }
        throw new IllegalArgumentException("Terlalu banyak pengalihan (redirect)");
    }

    private static byte[] readAll(InputStream in, int limit) throws Exception {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream(64 * 1024);
            byte[] buf = new byte[16 * 1024];
            int n, total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > limit) throw new IllegalArgumentException("File terlalu besar (maks 25 MB)");
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        } finally {
            in.close();
        }
    }

    private static boolean looksLikeHtml(byte[] d) {
        if (d == null) return false;
        String head = new String(d, 0, Math.min(d.length, 300)).trim().toLowerCase();
        return head.startsWith("<!doctype") || head.startsWith("<html") || head.startsWith("<head")
                || head.startsWith("<?xml") && head.contains("<html");
    }

    /** Decode byte[] jadi Bitmap (sisi terpanjang maks 1600 px). null bila bukan gambar. */
    private static Bitmap decode(byte[] data) {
        if (data == null || data.length == 0) return null;
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, o);
            if (o.outWidth <= 0 || o.outHeight <= 0) return null;
            int s = 1;
            int max = Math.max(o.outWidth, o.outHeight);
            while (max / s > 1600) s *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = s;
            o2.inPreferredConfig = Bitmap.Config.ARGB_8888;
            return BitmapFactory.decodeByteArray(data, 0, data.length, o2);
        } catch (Throwable t) {
            return null;
        }
    }
}
