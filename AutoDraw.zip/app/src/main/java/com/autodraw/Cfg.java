package com.autodraw;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import java.io.InputStream;
import java.util.ArrayList;

/** Pengaturan aplikasi + gambar referensi yang dipakai bersama MainActivity dan DrawService. */
public final class Cfg {
    public static final int MODE_CONTOUR = 0, MODE_SCAN = 1, MODE_TWO = 2;

    public interface RefListener {
        void onRef();
    }

    private static SharedPreferences sp;
    private static final ArrayList<RefListener> listeners = new ArrayList<>();

    /** Gambar referensi (sisi terpanjang maks 1600 px). null = belum dipilih. */
    public static Bitmap ref;

    private Cfg() {}

    public static void init(Context c) {
        if (sp == null) {
            sp = c.getApplicationContext().getSharedPreferences("autodraw", Context.MODE_PRIVATE);
        }
    }

    public static int geti(String k, int d) { return sp == null ? d : sp.getInt(k, d); }
    public static void puti(String k, int v) { if (sp != null) sp.edit().putInt(k, v).apply(); }
    public static boolean getb(String k, boolean d) { return sp == null ? d : sp.getBoolean(k, d); }
    public static void putb(String k, boolean v) { if (sp != null) sp.edit().putBoolean(k, v).apply(); }

    public static int mode() { return geti("mode", MODE_CONTOUR); }
    public static int grid() { return geti("grid", 8); }
    public static int threshold() { return geti("thr", 110); }
    public static int speed() { return geti("speed", 5); }
    public static int brush() { return geti("brush", 6); }
    public static boolean fillThick() { return getb("fill", true); }
    public static boolean anim() { return getb("anim", true); }
    public static boolean noZoom() { return getb("nozoom", true); }
    /** Panel pengaturan lengkap melayang (false = mode jangan ganggu). */
    public static boolean overlayFull() { return getb("ovfull", false); }
    /** BARU: tombol "Gambar" di layar mengambang untuk memasukkan gambar referensi. */
    public static boolean overlayPick() { return getb("ovpick", false); }

    public static void addListener(RefListener l) {
        if (!listeners.contains(l)) listeners.add(l);
    }

    public static void removeListener(RefListener l) {
        listeners.remove(l);
    }

    private static void notifyRef() {
        for (RefListener l : new ArrayList<>(listeners)) l.onRef();
    }

    /** Muat gambar dari Uri di thread terpisah, lalu panggil listener + done di main thread. */
    public static void load(Context ctx, final Uri uri, final Runnable done) {
        final Context app = ctx.getApplicationContext();
        final Handler h = new Handler(Looper.getMainLooper());
        new Thread(new Runnable() {
            @Override public void run() {
                Bitmap b = null;
                try {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    InputStream in = app.getContentResolver().openInputStream(uri);
                    BitmapFactory.decodeStream(in, null, o);
                    in.close();

                    int s = 1;
                    int max = Math.max(o.outWidth, o.outHeight);
                    while (max / s > 1600) s *= 2;

                    BitmapFactory.Options o2 = new BitmapFactory.Options();
                    o2.inSampleSize = s;
                    o2.inPreferredConfig = Bitmap.Config.ARGB_8888;
                    in = app.getContentResolver().openInputStream(uri);
                    b = BitmapFactory.decodeStream(in, null, o2);
                    in.close();
                } catch (Throwable t) {
                    b = null;
                }
                final Bitmap fb = b;
                h.post(new Runnable() {
                    @Override public void run() {
                        if (fb != null) {
                            ref = fb;
                            notifyRef();
                        }
                        if (done != null) done.run();
                    }
                });
            }
        }).start();
    }
}
