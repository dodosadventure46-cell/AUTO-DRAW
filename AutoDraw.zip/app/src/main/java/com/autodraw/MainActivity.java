package com.autodraw;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView accStatus, imgStatus, btnToggle;
    private ImageView preview;

    private final Cfg.RefListener refL = new Cfg.RefListener() {
        @Override public void onRef() { updateImage(); }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Cfg.init(this);
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Cfg.addListener(refL);
        refreshStatus();
        updateImage();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Cfg.removeListener(refL);
    }

    // ------------------------------------------------------------------ UI

    private void build() {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        root.setPadding(p, Ui.dp(this, 20), p, Ui.dp(this, 28));
        sv.addView(root);

        TextView title = Ui.text(this, "AutoDraw", 28, Ui.TEXT, true);
        root.addView(title);
        TextView sub = Ui.text(this, "Auto-gambar line art di aplikasi gambar apa pun.", 14, Ui.MUTED, false);
        sub.setPadding(0, Ui.dp(this, 2), 0, 0);
        root.addView(sub);
        TextView by = Ui.text(this, "dibuat oleh @dodosadventure", 12, Ui.ACCENT, false);
        by.setPadding(0, Ui.dp(this, 2), 0, Ui.dp(this, 14));
        root.addView(by);

        // --- kartu izin aksesibilitas
        LinearLayout c1 = card(root);
        c1.addView(Ui.text(this, "Izin aksesibilitas", 16, Ui.ACCENT, true));
        accStatus = Ui.text(this, "", 14, Ui.TEXT, false);
        accStatus.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 2));
        c1.addView(accStatus);
        c1.addView(Ui.text(this, "Dibutuhkan agar AutoDraw bisa menyentuh layar.", 12, Ui.MUTED, false));
        TextView t13 = Ui.text(this,
                "Android 13+: bila aksesibilitas abu-abu, buka Info Aplikasi > menu > Izinkan setelan terbatas.",
                12, Ui.MUTED, false);
        t13.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 8));
        c1.addView(t13);
        TextView openAcc = Ui.button(this, "Buka pengaturan aksesibilitas", Ui.BTN);
        openAcc.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openAccessibility(); }
        });
        c1.addView(openAcc, match());

        // --- kartu gambar referensi
        LinearLayout c2 = card(root);
        c2.addView(Ui.text(this, "Gambar referensi", 16, Ui.ACCENT, true));
        c2.addView(Ui.text(this, "Bagian hitam gambar diambil sebagai garis.", 12, Ui.MUTED, false));
        c2.addView(Ui.text(this, "Pakai kuas pensil kecil, warna hitam.", 12, Ui.MUTED, false));
        preview = new ImageView(this);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setBackgroundColor(0xFFFFFFFF);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 160));
        plp.topMargin = Ui.dp(this, 10);
        c2.addView(preview, plp);
        imgStatus = Ui.text(this, "", 13, Ui.MUTED, false);
        imgStatus.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 8));
        c2.addView(imgStatus);
        TextView pick = Ui.button(this, "Pilih gambar", Ui.ACCENT);
        pick.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, PickActivity.class));
            }
        });
        c2.addView(pick, match());

        // --- kartu pengaturan
        LinearLayout c3 = card(root);
        c3.addView(Ui.text(this, "Pengaturan", 18, Ui.TEXT, true));
        c3.addView(Ui.text(this, "Perubahan langsung dipakai oleh kotak gambar.", 12, Ui.MUTED, false));
        c3.addView(SettingsUi.build(this, false));

        // --- tombol layar mengambang
        btnToggle = Ui.button(this, "", Ui.ACCENT);
        btnToggle.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { onToggleOverlay(); }
        });
        root.addView(btnToggle, match());

        TextView tip = Ui.text(this,
                "Setelah kotak muncul, buka aplikasi gambar, geser kotak ke atas kanvas, lalu tekan Mulai. "
                        + "Tombol Stop merah di pojok kanan atas layar akan muncul saat menggambar.",
                12, Ui.MUTED, false);
        tip.setPadding(0, Ui.dp(this, 10), 0, 0);
        root.addView(tip);

        setContentView(sv);
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 14);
        l.setPadding(p, p, p, p);
        l.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 16)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = Ui.dp(this, 12);
        parent.addView(l, lp);
        return l;
    }

    private LinearLayout.LayoutParams match() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    // ------------------------------------------------------------------ aksi

    private void openAccessibility() {
        try {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        } catch (Exception e) {
            Toast.makeText(this, "Buka pengaturan aksesibilitas secara manual", Toast.LENGTH_LONG).show();
        }
    }

    private void onToggleOverlay() {
        if (!DrawService.isRunning()) {
            Toast.makeText(this, "Aktifkan AutoDraw di Aksesibilitas dulu", Toast.LENGTH_LONG).show();
            openAccessibility();
            return;
        }
        DrawService.toggleOverlay();
        refreshStatus();
    }

    private void refreshStatus() {
        boolean on = DrawService.isRunning();
        accStatus.setText(on ? "Status: aktif" : "Status: belum aktif");
        accStatus.setTextColor(on ? 0xFF3DD68C : Ui.DANGER);
        btnToggle.setText(DrawService.isShown() ? "Tutup layar mengambang" : "Tampilkan kotak gambar");
    }

    private void updateImage() {
        Bitmap b = Cfg.ref;
        preview.setImageBitmap(b);
        imgStatus.setText(b == null ? "Pilih gambar dulu"
                : "Gambar dimuat (" + b.getWidth() + " x " + b.getHeight() + ")");
    }
}
