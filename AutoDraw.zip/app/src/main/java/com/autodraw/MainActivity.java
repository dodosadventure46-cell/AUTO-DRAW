package com.autodraw;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Outline;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView accPill, imgStatus, imgEmpty, btnToggle;
    private LinearLayout accDetail;
    private ImageView preview;
    private Ui.Seg viewSeg;

    private final Handler h = new Handler(Looper.getMainLooper());
    private int previewGen;
    private final Runnable previewJob = new Runnable() {
        @Override public void run() { renderPreview(); }
    };

    private final Cfg.RefListener refL = new Cfg.RefListener() {
        @Override public void onRef() { updateImage(); }
    };

    private final Cfg.SettingsListener setL = new Cfg.SettingsListener() {
        @Override public void onSetting(String key) {
            if ("viewmode".equals(key)) {
                if (viewSeg != null) viewSeg.select(Cfg.viewMode());
                schedulePreview(0);
            } else if ("thr".equals(key) || "grid".equals(key)) {
                if (Cfg.viewMode() == Cfg.VIEW_LINES) schedulePreview(140);
            }
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Cfg.init(this);
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Cfg.addListener(refL);
        Cfg.addSettingsListener(setL);
        viewSeg.select(Cfg.viewMode());
        refreshStatus();
        updateImage();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Cfg.removeListener(refL);
        Cfg.removeSettingsListener(setL);
        h.removeCallbacks(previewJob);
    }

    // ------------------------------------------------------------------ UI

    private void build() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        root.setPadding(p, Ui.dp(this, 20), p, Ui.dp(this, 12));
        sv.addView(root);
        page.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        buildHeader(root);
        buildAccessCard(root);
        buildImageCard(root);
        buildModeCard(root);
        buildTuneCard(root);
        buildOverlayCard(root);
        buildHowTo(root);

        // tombol utama dibuat tetap di bawah layar
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setBackgroundColor(Ui.BG);
        bottom.addView(Ui.divider(this));
        LinearLayout inner = new LinearLayout(this);
        inner.setPadding(p, Ui.dp(this, 10), p, Ui.dp(this, 12));
        btnToggle = Ui.button(this, "", Ui.ACCENT);
        btnToggle.setTextSize(15);
        btnToggle.setMinHeight(Ui.dp(this, 52));
        btnToggle.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { onToggleOverlay(); }
        });
        inner.addView(btnToggle, new LinearLayout.LayoutParams(-1, -2));
        bottom.addView(inner);
        page.addView(bottom, new LinearLayout.LayoutParams(-1, -2));

        setContentView(page);
    }

    private void buildHeader(LinearLayout root) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(Ui.text(this, "AutoDraw", 28, Ui.TEXT, true));
        TextView sub = Ui.text(this, "Auto-gambar line art di aplikasi gambar apa pun", 13, Ui.MUTED, false);
        sub.setPadding(0, Ui.dp(this, 2), 0, 0);
        col.addView(sub);
        TextView by = Ui.text(this, "oleh @dodosadventure  ·  v2.3.2", 12, Ui.ACCENT, false);
        by.setPadding(0, Ui.dp(this, 3), 0, 0);
        col.addView(by);
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = Ui.dp(this, 16);
        root.addView(row, lp);
    }

    private void buildAccessCard(LinearLayout root) {
        LinearLayout c = card(root);
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(Ui.text(this, "Izin aksesibilitas", 16, Ui.TEXT, true),
                new LinearLayout.LayoutParams(0, -2, 1f));
        accPill = Ui.text(this, "", 12.5f, Ui.TEXT, true);
        accPill.setPadding(Ui.dp(this, 10), Ui.dp(this, 4), Ui.dp(this, 10), Ui.dp(this, 4));
        head.addView(accPill);
        c.addView(head);

        accDetail = new LinearLayout(this);
        accDetail.setOrientation(LinearLayout.VERTICAL);
        TextView why = Ui.hint(this, "Dibutuhkan agar AutoDraw bisa menyentuh layar dan menggambar untukmu.");
        why.setPadding(0, Ui.dp(this, 8), 0, 0);
        accDetail.addView(why);
        TextView t13 = Ui.hint(this,
                "Android 13+: bila pilihan aksesibilitas abu-abu, buka Info Aplikasi > menu titik tiga > Izinkan setelan terbatas.");
        t13.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 10));
        accDetail.addView(t13);
        TextView openAcc = Ui.button(this, "Buka pengaturan aksesibilitas", Ui.BTN);
        openAcc.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openAccessibility(); }
        });
        accDetail.addView(openAcc, new LinearLayout.LayoutParams(-1, -2));
        c.addView(accDetail);
    }

    private void buildImageCard(LinearLayout root) {
        LinearLayout c = card(root);
        c.addView(Ui.text(this, "Gambar referensi", 16, Ui.TEXT, true));
        TextView sub = Ui.hint(this, "Bagian gelap gambar diambil sebagai garis. Pakai kuas pensil kecil warna hitam.");
        sub.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 12));
        c.addView(sub);

        // bingkai pratinjau dengan sudut membulat
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(0xFFF1F2F8);
        final float rad = Ui.dp(this, 14);
        frame.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), rad);
            }
        });
        frame.setClipToOutline(true);
        preview = new ImageView(this);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setPadding(Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6));
        frame.addView(preview, new FrameLayout.LayoutParams(-1, -1));
        imgEmpty = Ui.text(this, "Belum ada gambar", 13, 0xFF7A7DA0, false);
        imgEmpty.setGravity(Gravity.CENTER);
        frame.addView(imgEmpty, new FrameLayout.LayoutParams(-1, -1));
        c.addView(frame, new LinearLayout.LayoutParams(-1, Ui.dp(this, 190)));

        imgStatus = Ui.hint(this, "");
        imgStatus.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 10));
        c.addView(imgStatus);

        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        TextView gallery = Ui.button(this, "Dari galeri", Ui.ACCENT);
        gallery.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, PickActivity.class));
            }
        });
        btns.addView(gallery, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView url = Ui.button(this, "Dari URL", Ui.BTN);
        url.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, PickActivity.class)
                        .putExtra(PickActivity.EXTRA_URL, true));
            }
        });
        LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(0, -2, 1f);
        ulp.leftMargin = Ui.dp(this, 8);
        btns.addView(url, ulp);
        c.addView(btns, new LinearLayout.LayoutParams(-1, -2));

        // tampilan kotak: gambar penuh / hanya garis hitam
        TextView vt = Ui.text(this, "Tampilan di kotak gambar", 14, Ui.TEXT, true);
        vt.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 6));
        c.addView(vt);
        viewSeg = SettingsUi.viewSeg(this, false);
        c.addView(viewSeg, new LinearLayout.LayoutParams(-1, -2));
        TextView vh = Ui.hint(this,
                "Garis hitam menampilkan persis bagian gelap yang akan digambar, jadi bisa dicek dulu sebelum mulai. Hasilnya ikut Batas gelap dan Ukuran grid.");
        vh.setPadding(0, Ui.dp(this, 6), 0, 0);
        c.addView(vh);
    }

    private void buildModeCard(LinearLayout root) {
        LinearLayout c = card(root);
        c.addView(Ui.text(this, "Mode menggambar", 16, Ui.TEXT, true));
        TextView sub = Ui.hint(this, "Pilih cara AutoDraw menggambar.");
        sub.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 12));
        c.addView(sub);
        c.addView(SettingsUi.modeSection(this, false));
    }

    private void buildTuneCard(LinearLayout root) {
        LinearLayout c = card(root);
        c.addView(Ui.text(this, "Penyesuaian", 16, Ui.TEXT, true));
        TextView sub = Ui.hint(this, "Perubahan langsung dipakai oleh kotak gambar.");
        sub.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 2));
        c.addView(sub);
        c.addView(SettingsUi.tuneSection(this, false));
    }

    private void buildOverlayCard(LinearLayout root) {
        LinearLayout c = card(root);
        c.addView(Ui.text(this, "Layar mengambang", 16, Ui.TEXT, true));
        c.addView(SettingsUi.overlaySection(this));
    }

    private void buildHowTo(LinearLayout root) {
        LinearLayout c = card(root);
        c.addView(Ui.text(this, "Cara pakai", 16, Ui.TEXT, true));
        String[] steps = {
                "Aktifkan AutoDraw di pengaturan Aksesibilitas.",
                "Pilih gambar dari galeri atau URL, lalu tekan Tampilkan kotak gambar.",
                "Buka aplikasi gambar, geser dan ubah ukuran kotak ke atas kanvas.",
                "Pilih tampilan Garis hitam untuk mengecek hasil deteksi, lalu tekan Mulai.",
                "Tombol STOP merah di pojok kanan atas muncul saat menggambar."
        };
        for (int i = 0; i < steps.length; i++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, Ui.dp(this, i == 0 ? 10 : 6), 0, 0);
            TextView n = Ui.text(this, String.valueOf(i + 1), 12, 0xFFFFFFFF, true);
            n.setGravity(Gravity.CENTER);
            n.setBackground(Ui.round(Ui.ACCENT, Ui.dp(this, 20)));
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(Ui.dp(this, 22), Ui.dp(this, 22));
            nlp.rightMargin = Ui.dp(this, 10);
            row.addView(n, nlp);
            TextView t = Ui.text(this, steps[i], 13, Ui.MUTED, false);
            t.setLineSpacing(0f, 1.1f);
            row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            c.addView(row);
        }
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        l.setPadding(p, p, p, p);
        l.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 18)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = Ui.dp(this, 12);
        parent.addView(l, lp);
        return l;
    }

    // ------------------------------------------------------------------ aksi

    private void openAccessibility() {
        try {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        } catch (Exception e) {
            Toast.makeText(this, "Buka pengaturan aksesibilitas secara manual", Toast.LENGTH_LONG).show();
        }
    }

    private void onToggleOverlay() {
        if (!DrawService.isRunning()) {
            Toast.makeText(this, "Aktifkan AutoDraw di Aksesibilitas dulu", Toast.LENGTH_LONG).show();
            openAccessibility();
            return;
        }
        DrawService.toggleOverlay();
        refreshStatus();
    }

    private void refreshStatus() {
        boolean on = DrawService.isRunning();
        accPill.setText(on ? "●  Aktif" : "●  Belum aktif");
        accPill.setTextColor(on ? Ui.OK : 0xFFFF8A8E);
        accPill.setBackground(Ui.round(on ? 0x223DD68C : 0x22E5484D, Ui.dp(this, 20)));
        accDetail.setVisibility(on ? View.GONE : View.VISIBLE);
        boolean shown = DrawService.isShown();
        btnToggle.setText(shown ? "Tutup layar mengambang" : "Tampilkan kotak gambar");
        btnToggle.setBackground(Ui.ripple(shown ? Ui.BTN : Ui.ACCENT, Ui.dp(this, 12)));
    }

    private void updateImage() {
        Bitmap b = Cfg.ref;
        imgEmpty.setVisibility(b == null ? View.VISIBLE : View.GONE);
        if (b == null) {
            preview.setImageDrawable(null);
            imgStatus.setText("Pilih gambar dari galeri atau URL.");
            return;
        }
        String src = Cfg.refSource == null || Cfg.refSource.isEmpty() ? "" : "  ·  dari " + Cfg.refSource;
        imgStatus.setText(b.getWidth() + " × " + b.getHeight() + " px" + src);
        schedulePreview(0);
    }

    // ------------------------------------------------------------------ pratinjau

    private void schedulePreview(long delay) {
        h.removeCallbacks(previewJob);
        h.postDelayed(previewJob, delay);
    }

    /** Tampilkan gambar penuh, atau hitung ulang garis hitam yang terdeteksi (di thread terpisah). */
    private void renderPreview() {
        final Bitmap ref = Cfg.ref;
        if (ref == null || preview == null) return;
        if (Cfg.viewMode() != Cfg.VIEW_LINES) {
            previewGen++;
            preview.setImageBitmap(ref);
            return;
        }
        // perkiraan ukuran kotak di layar, sama seperti yang dipakai layar mengambang
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = Math.round(Math.min(dm.widthPixels, dm.heightPixels) * 0.7f);
        int hh = Math.round(w * (float) ref.getHeight() / ref.getWidth());
        int maxH = Math.round(dm.heightPixels * 0.85f);
        if (hh > maxH) {
            hh = maxH;
            w = Math.round(hh * (float) ref.getWidth() / ref.getHeight());
        }
        final int bw = w, bh = hh, grid = Cfg.grid(), thr = Cfg.threshold();
        final int gen = ++previewGen;
        new Thread(new Runnable() {
            @Override public void run() {
                Bitmap out = null;
                try { out = Tracer.preview(ref, bw, bh, grid, thr); } catch (Throwable ignored) {}
                final Bitmap fb = out;
                h.post(new Runnable() {
                    @Override public void run() {
                        if (gen != previewGen || fb == null || isFinishing()) return;
                        BitmapDrawable d = new BitmapDrawable(getResources(), fb);
                        d.setFilterBitmap(false);
                        preview.setImageDrawable(d);
                    }
                });
            }
        }).start();
    }
}
