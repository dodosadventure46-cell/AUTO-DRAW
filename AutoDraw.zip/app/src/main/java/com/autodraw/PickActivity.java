package com.autodraw;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

/**
 * Activity transparan untuk memasukkan gambar referensi, dipakai MainActivity dan tombol di
 * layar mengambang sehingga aplikasi gambar di belakang tidak perlu ditinggalkan.
 *
 *  - default            : membuka pemilih gambar sistem (galeri / file)
 *  - EXTRA_URL = true   : menampilkan kartu untuk menempel link gambar lalu mengunduhnya
 */
public class PickActivity extends Activity {
    static final String EXTRA_URL = "url";
    private static final int REQ = 77;

    /** Dipakai DrawService untuk tahu apakah pemilih benar-benar terbuka. */
    static volatile boolean alive;

    private boolean loading;
    private EditText input;
    private TextView status, loadBtn, pasteBtn;
    private ProgressBar bar;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        alive = true;
        Cfg.init(this);
        if (getIntent().getBooleanExtra(EXTRA_URL, false)) {
            buildUrlUi();
            return;
        }
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(Intent.createChooser(i, "Pilih gambar"), REQ);
        } catch (Exception e) {
            finish();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ && res == RESULT_OK && data != null && data.getData() != null) {
            // tutup setelah gambar selesai dibaca (izin Uri masih berlaku selama activity hidup)
            Cfg.load(this, data.getData(), new Runnable() {
                @Override public void run() { finish(); }
            });
        } else {
            finish();
        }
    }

    // ------------------------------------------------------------------ kartu URL

    private void buildUrlUi() {
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
                | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        FrameLayout scrim = new FrameLayout(this);
        scrim.setBackgroundColor(0xB3000000);
        scrim.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (!loading) finish(); }
        });

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 18);
        card.setPadding(p, p, p, p);
        card.setBackground(Ui.round(Ui.CARD, Ui.dp(this, 20)));
        card.setClickable(true); // sentuhan di kartu tidak menutup

        card.addView(Ui.text(this, "Gambar dari URL", 18, Ui.TEXT, true));
        TextView sub = Ui.hint(this, "Tempel link langsung ke file gambar (.jpg, .png, .webp). Link halaman web biasa tidak bisa dipakai.");
        sub.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 12));
        card.addView(sub);

        input = new EditText(this);
        input.setHint("https://contoh.com/gambar.png");
        input.setHintTextColor(0xFF6E7194);
        input.setTextColor(Ui.TEXT);
        input.setTextSize(14);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setImeOptions(EditorInfo.IME_ACTION_GO);
        input.setBackground(Ui.stroke(Ui.INSET, Ui.LINE, Ui.dp(this, 12), Ui.dp(this, 1)));
        input.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12));
        input.setHighlightColor(0x557C5CFF);
        card.addView(input, new LinearLayout.LayoutParams(-1, -2));
        input.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, android.view.KeyEvent e) {
                if (actionId == EditorInfo.IME_ACTION_GO) { startLoad(); return true; }
                return false;
            }
        });

        LinearLayout stat = new LinearLayout(this);
        stat.setOrientation(LinearLayout.HORIZONTAL);
        stat.setGravity(Gravity.CENTER_VERTICAL);
        stat.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 2));
        bar = new ProgressBar(this);
        bar.setIndeterminate(true);
        bar.setIndeterminateTintList(ColorStateList.valueOf(Ui.ACCENT));
        bar.setVisibility(View.GONE);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(Ui.dp(this, 18), Ui.dp(this, 18));
        blp.rightMargin = Ui.dp(this, 8);
        stat.addView(bar, blp);
        status = Ui.hint(this, "");
        status.setVisibility(View.GONE);
        stat.addView(status, new LinearLayout.LayoutParams(0, -2, 1f));
        card.addView(stat, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setPadding(0, Ui.dp(this, 10), 0, 0);

        pasteBtn = Ui.button(this, "Tempel", Ui.BTN);
        pasteBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String clip = clipboardText();
                if (clip == null) {
                    showStatus("Clipboard kosong", true);
                } else {
                    input.setText(clip);
                    input.setSelection(input.getText().length());
                    showStatus(null, false);
                }
            }
        });
        btns.addView(pasteBtn, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView cancel = Ui.button(this, "Batal", Ui.BTN);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (!loading) finish(); }
        });
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, -2, 1f);
        clp.leftMargin = Ui.dp(this, 8);
        btns.addView(cancel, clp);

        loadBtn = Ui.button(this, "Muat", Ui.ACCENT);
        loadBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startLoad(); }
        });
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(0, -2, 1.2f);
        llp.leftMargin = Ui.dp(this, 8);
        btns.addView(loadBtn, llp);
        card.addView(btns, new LinearLayout.LayoutParams(-1, -2));

        FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        int m = Ui.dp(this, 16);
        flp.setMargins(m, Ui.dp(this, 72), m, m);
        // lebar maksimum di layar besar
        int maxW = Ui.dp(this, 460);
        int sw = getResources().getDisplayMetrics().widthPixels;
        if (sw - 2 * m > maxW) flp.width = maxW;
        scrim.addView(card, flp);
        setContentView(scrim);

        // isi otomatis bila clipboard berisi link
        String clip = clipboardText();
        if (clip != null && (clip.startsWith("http://") || clip.startsWith("https://"))) {
            input.setText(clip);
            input.setSelection(input.getText().length());
        }
        input.requestFocus();
    }

    private String clipboardText() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip()) return null;
            ClipData d = cm.getPrimaryClip();
            if (d == null || d.getItemCount() == 0) return null;
            CharSequence t = d.getItemAt(0).coerceToText(this);
            if (t == null) return null;
            String s = t.toString().trim();
            return s.isEmpty() ? null : s;
        } catch (Throwable e) {
            return null;
        }
    }

    private void showStatus(String s, boolean error) {
        if (s == null) {
            status.setVisibility(View.GONE);
            return;
        }
        status.setText(s);
        status.setTextColor(error ? 0xFFFF8A8E : Ui.MUTED);
        status.setVisibility(View.VISIBLE);
    }

    private void setLoading(boolean on) {
        loading = on;
        bar.setVisibility(on ? View.VISIBLE : View.GONE);
        input.setEnabled(!on);
        loadBtn.setEnabled(!on);
        pasteBtn.setEnabled(!on);
        loadBtn.setAlpha(on ? 0.5f : 1f);
        pasteBtn.setAlpha(on ? 0.5f : 1f);
        if (on) showStatus("Mengunduh gambar...", false);
    }

    private void startLoad() {
        if (loading) return;
        String u = input.getText().toString().trim();
        if (u.isEmpty()) {
            showStatus("Tempel link gambar dulu", true);
            return;
        }
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
        setLoading(true);
        Cfg.loadUrl(u, new Cfg.LoadCb() {
            @Override public void onResult(String error) {
                if (isFinishing() || isDestroyed()) return;
                if (error == null) {
                    finish();
                } else {
                    setLoading(false);
                    showStatus(error, true);
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        alive = false;
        DrawService.pickFinished();
    }
}
