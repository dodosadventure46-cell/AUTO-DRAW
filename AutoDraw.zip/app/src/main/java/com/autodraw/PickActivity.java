package com.autodraw;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/**
 * Activity transparan yang hanya membuka pemilih gambar lalu menutup diri.
 * Dipakai oleh MainActivity dan oleh tombol "Gambar" di layar mengambang,
 * sehingga aplikasi gambar di belakang tidak perlu ditinggalkan.
 */
public class PickActivity extends Activity {
    private static final int REQ = 77;

    /** Dipakai DrawService untuk tahu apakah pemilih benar-benar terbuka. */
    static volatile boolean alive;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        alive = true;
        Cfg.init(this);
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(Intent.createChooser(i, "Pilih gambar"), REQ);
        } catch (Exception e) {
            finish();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ && res == RESULT_OK && data != null && data.getData() != null) {
            // tutup setelah gambar selesai dibaca (izin Uri masih berlaku selama activity hidup)
            Cfg.load(this, data.getData(), new Runnable() {
                @Override public void run() { finish(); }
            });
        } else {
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        alive = false;
        DrawService.pickFinished();
    }
}
