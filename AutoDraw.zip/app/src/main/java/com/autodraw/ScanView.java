package com.autodraw;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;
import android.view.animation.LinearInterpolator;

/**
 * Animasi pemindaian sebelum menggambar.
 *
 * Kenapa lebih smooth dari versi lama:
 *  - Berbasis waktu (ValueAnimator yang sinkron vsync), bukan hitungan frame -> tidak patah.
 *  - Garis pemindai memakai easing sinus (pelan-cepat-pelan) + glow gradasi.
 *  - Kotak kecil muncul bertahap dengan alpha + skala (smoothstep), bukan tiba-tiba.
 *  - Tidak ada alokasi objek di onDraw (Paint/RectF/Shader dipakai ulang).
 */
public class ScanView extends View {
    private static final float SCAN_MS = 1500f;
    private static final float HOLD_MS = 100f;
    private static final float FADE_MS = 600f;
    private static final float TOTAL_MS = SCAN_MS + HOLD_MS + FADE_MS;

    private final Paint cellP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint coreP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowP = new Paint();
    private final RectF rf = new RectF();

    private boolean[] cells;
    private int cols, rows;
    private float elapsed;
    private ValueAnimator anim;
    private final float density;
    private float glowH, coreH;

    public ScanView(Context c) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
        coreH = 2.5f * density;
        glowH = 28f * density;
        cellP.setColor(0xFFB9A8FF);
        coreP.setColor(0xFFFFFFFF);
    }

    public void setCells(boolean[] cells, int cols, int rows) {
        this.cells = cells;
        this.cols = cols;
        this.rows = rows;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        glowH = Math.max(22f * density, h * 0.10f);
        // gradasi dibuat sekali; digeser dengan canvas.translate saat menggambar
        glowP.setShader(new LinearGradient(0, -glowH, 0, 0, 0x007C5CFF, 0xCC9B85FF,
                Shader.TileMode.CLAMP));
    }

    public void play(final Runnable end) {
        stop();
        elapsed = 0f;
        setVisibility(VISIBLE);
        anim = ValueAnimator.ofFloat(0f, TOTAL_MS);
        anim.setDuration((long) TOTAL_MS);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                elapsed = (Float) a.getAnimatedValue();
                invalidate();
            }
        });
        anim.addListener(new AnimatorListenerAdapter() {
            boolean cancelled;
            @Override public void onAnimationCancel(Animator a) { cancelled = true; }
            @Override public void onAnimationEnd(Animator a) {
                setVisibility(GONE);
                if (!cancelled && end != null) end.run();
            }
        });
        anim.start();
    }

    public void stop() {
        if (anim != null) {
            ValueAnimator a = anim;
            anim = null;
            a.cancel();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stop();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        final float w = getWidth(), h = getHeight();
        if (w <= 0f || h <= 0f) return;

        final float band = glowH * 1.8f;          // lebar zona "muncul" di belakang garis
        final float travel = h + band * 1.3f;     // garis jalan sampai semua baris tampil penuh
        final float e = elapsed;

        float lineY;
        float lineA = 0f;
        float fade = 1f;

        if (e < SCAN_MS) {
            float p = e / SCAN_MS;
            float s = 0.5f - 0.5f * (float) Math.cos(Math.PI * p); // easeInOutSine
            lineY = s * travel;
            lineA = 1f;
        } else if (e < SCAN_MS + HOLD_MS) {
            lineY = travel;
        } else {
            float f = (e - SCAN_MS - HOLD_MS) / FADE_MS;
            if (f > 1f) f = 1f;
            float inv = 1f - f;
            fade = inv * inv * inv;                // easeOutCubic
            lineY = travel;
        }

        if (cells != null) drawCells(canvas, w, h, lineY, band, fade);

        if (lineA > 0f && lineY < h + glowH) {
            canvas.save();
            canvas.translate(0f, lineY);
            glowP.setAlpha((int) (255f * lineA));
            canvas.drawRect(0f, -glowH, w, 0f, glowP);
            coreP.setAlpha((int) (255f * lineA));
            canvas.drawRect(0f, -coreH * 0.5f, w, coreH * 0.5f, coreP);
            canvas.restore();
        }
    }

    private void drawCells(Canvas canvas, float w, float h, float lineY, float band, float fade) {
        final float cw = w / cols, ch = h / rows;
        final float gap = Math.max(0.8f, Math.min(cw, ch) * 0.14f);

        for (int r = 0; r < rows; r++) {
            final float cy = (r + 0.5f) * ch;
            final float d = lineY - cy;
            if (d <= 0f) break;                    // baris di bawah belum tersentuh garis
            final float base = d / band;
            final boolean full = base >= 1.3f;
            final int rowBase = r * cols;

            for (int c = 0; c < cols; c++) {
                if (!cells[rowBase + c]) continue;
                float a;
                if (full) {
                    a = 1f;
                } else {
                    float jitter = (((r * 31 + c * 17) & 7) / 7f) * 0.3f; // muncul tidak serempak
                    a = base - jitter;
                    if (a <= 0f) continue;
                    if (a > 1f) a = 1f;
                    a = a * a * (3f - 2f * a);     // smoothstep
                }
                a *= fade;
                if (a <= 0.01f) continue;

                final float sc = 0.45f + 0.55f * a;
                final float hw = (cw - gap) * 0.5f * sc;
                final float hh = (ch - gap) * 0.5f * sc;
                final float cx = (c + 0.5f) * cw;
                rf.set(cx - hw, cy - hh, cx + hw, cy + hh);
                cellP.setAlpha((int) (a * 235f));
                final float rad = Math.min(hw, hh) * 0.35f;
                canvas.drawRoundRect(rf, rad, rad, cellP);
            }
        }
    }
}
