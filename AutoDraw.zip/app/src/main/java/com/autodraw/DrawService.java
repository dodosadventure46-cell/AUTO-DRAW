package com.autodraw;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class DrawService extends AccessibilityService {
    static DrawService inst;

    private static final long GAP_MS = 8;          // jeda antar goresan dalam satu gesture
    private static final long BATCH_MS = 2000;     // durasi maksimum satu gesture (stop tetap responsif)

    private final Handler main = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private Context ui;
    private int sw, sh;

    // ---- overlay
    private boolean shown;
    private boolean picking;

    private BoxView box;
    private WindowManager.LayoutParams boxLp;
    private boolean boxAttached;

    private View ctrl;
    private WindowManager.LayoutParams ctrlLp;
    private boolean ctrlAttached;
    private int ctrlX = -1, ctrlY = -1;

    private TextView stopBtn;
    private WindowManager.LayoutParams stopLp;
    private boolean stopAttached;

    // ---- proses menggambar
    private boolean busy;
    private volatile boolean stopFlag;
    private int runId;
    private ArrayList<Unit> units;
    private int cursor, fails, maxStrokes;
    private long maxDur;

    private static final class Unit {
        float[] a, b;
        long da, db, dur;
        long gap = GAP_MS;   // jeda sebelum unit berikutnya
    }

    private final Cfg.RefListener refL = new Cfg.RefListener() {
        @Override public void onRef() { applyRef(); }
    };

    private final Cfg.SettingsListener setL = new Cfg.SettingsListener() {
        @Override public void onSetting(String key) {
            if ("viewmode".equals(key)) {
                if (box != null) box.applyMode();
                schedulePreview(0);
            } else if ("thr".equals(key) || "grid".equals(key)) {
                if (Cfg.viewMode() == Cfg.VIEW_LINES) schedulePreview(150);
            }
        }
    };

    // ---- pratinjau "garis hitam"
    private int previewGen;
    private final Runnable previewJob = new Runnable() {
        @Override public void run() { renderPreview(); }
    };

    // =====================================================================
    // siklus hidup service
    // =====================================================================

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        inst = this;
        Cfg.init(this);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        ui = new ContextThemeWrapper(this, R.style.AppTheme);
        Cfg.addListener(refL);
        Cfg.addSettingsListener(setL);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override public void onInterrupt() { stopDrawing(); }

    @Override
    public boolean onUnbind(Intent intent) {
        hideOverlay();
        Cfg.removeListener(refL);
        Cfg.removeSettingsListener(setL);
        if (inst == this) inst = null;
        return super.onUnbind(intent);
    }

    // =====================================================================
    // API untuk MainActivity / PickActivity
    // =====================================================================

    static boolean isRunning() { return inst != null; }

    static boolean isShown() { return inst != null && inst.shown; }

    static void toggleOverlay() {
        if (inst == null) return;
        if (inst.shown) inst.hideOverlay(); else inst.showOverlay();
    }

    /** Dipanggil saat toggle overlay di pengaturan berubah. */
    static void cfgChanged() {
        final DrawService s = inst;
        if (s == null) return;
        s.main.post(new Runnable() {
            @Override public void run() { s.rebuildCtrl(); }
        });
    }

    /** Dipanggil PickActivity.onDestroy. */
    static void pickFinished() {
        final DrawService s = inst;
        if (s == null) return;
        s.main.post(new Runnable() {
            @Override public void run() { s.restoreAfterPick(); }
        });
    }

    // =====================================================================
    // tampil / sembunyi overlay
    // =====================================================================

    void showOverlay() {
        if (shown) return;
        sw = getResources().getDisplayMetrics().widthPixels;
        sh = getResources().getDisplayMetrics().heightPixels;
        shown = true;
        picking = false;
        buildBox();
        attachBox();
        buildCtrl();
        attachCtrl();
    }

    void hideOverlay() {
        runId++;                // batalkan callback yang masih tertunda
        previewGen++;
        main.removeCallbacks(previewJob);
        stopFlag = true;
        busy = false;
        picking = false;
        if (box != null) box.scan.stop();
        detachStop();
        detachCtrl();
        detachBox();
        shown = false;
    }

    private WindowManager.LayoutParams newLp(int w, int h) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        // penting: tanpa ini jendela overlay digambar tanpa akselerasi GPU -> animasi patah
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        return lp;
    }

    private void safeUpdate(View v, WindowManager.LayoutParams lp) {
        try { wm.updateViewLayout(v, lp); } catch (Exception ignored) {}
    }

    // =====================================================================
    // kotak gambar
    // =====================================================================

    private void buildBox() {
        int base = Math.round(Math.min(sw, sh) * 0.7f);
        box = new BoxView(ui);
        boxLp = newLp(base, base);
        applyRef();
        boxLp.x = Math.max(0, (sw - boxLp.width) / 2);
        boxLp.y = Math.max(0, (sh - boxLp.height) / 3);
    }

    private void attachBox() {
        if (!shown || boxAttached || box == null) return;
        try { wm.addView(box, boxLp); boxAttached = true; } catch (Exception ignored) {}
    }

    private void detachBox() {
        if (box != null && boxAttached) {
            try { wm.removeViewImmediate(box); } catch (Exception ignored) {}
        }
        boxAttached = false;
    }

    /** Pasang gambar referensi ke kotak & sesuaikan rasio. */
    private void applyRef() {
        if (box == null) return;
        Bitmap b = Cfg.ref;
        box.lineBmp = null;
        box.hint.setVisibility(b == null ? View.VISIBLE : View.GONE);
        box.pill.setVisibility(b == null ? View.GONE : View.VISIBLE);
        if (b != null) {
            float asp = (float) b.getWidth() / b.getHeight();
            int w = boxLp.width;
            int h = Math.round(w / asp);
            int maxH = Math.round(sh * 0.85f);
            if (h > maxH) {
                h = maxH;
                w = Math.round(h * asp);
            }
            boxLp.width = w;
            boxLp.height = h;
            if (boxAttached) safeUpdate(box, boxLp);
        }
        box.applyMode();
        schedulePreview(0);
    }

    // ---- pratinjau garis hitam: mask yang sama persis dengan proses menggambar ----

    private void schedulePreview(long delay) {
        main.removeCallbacks(previewJob);
        main.postDelayed(previewJob, delay);
    }

    private void renderPreview() {
        final Bitmap ref = Cfg.ref;
        if (!shown || box == null || ref == null || Cfg.viewMode() != Cfg.VIEW_LINES) return;
        final int bw = Math.max(2, boxLp.width), bh = Math.max(2, boxLp.height);
        final int grid = Cfg.grid(), thr = Cfg.threshold();
        final int gen = ++previewGen;
        new Thread(new Runnable() {
            @Override public void run() {
                Bitmap out = null;
                try { out = Tracer.preview(ref, bw, bh, grid, thr); } catch (Throwable ignored) {}
                final Bitmap fb = out;
                main.post(new Runnable() {
                    @Override public void run() {
                        if (gen != previewGen || fb == null || box == null || ref != Cfg.ref) return;
                        box.lineBmp = fb;
                        box.applyMode();
                    }
                });
            }
        }).start();
    }

    private final class BoxView extends FrameLayout {
        final ImageView img;
        final ScanView scan;
        final TextView hint;
        final Ui.Seg pill;
        Bitmap lineBmp;

        BoxView(Context c) {
            super(c);
            setBackgroundColor(0x227C5CFF);

            img = new ImageView(c);
            img.setScaleType(ImageView.ScaleType.FIT_XY);
            img.setAlpha(0.6f);
            addView(img, new FrameLayout.LayoutParams(-1, -1));

            scan = new ScanView(c);
            scan.setVisibility(View.GONE);
            addView(scan, new FrameLayout.LayoutParams(-1, -1));

            View frame = new View(c);
            GradientDrawable g = new GradientDrawable();
            g.setColor(0x00000000);
            g.setStroke(Ui.dp(c, 2), Ui.ACCENT);
            frame.setBackground(g);
            addView(frame, new FrameLayout.LayoutParams(-1, -1));

            hint = Ui.text(c, "Pilih gambar dulu", 14, 0xFFFFFFFF, true);
            hint.setGravity(Gravity.CENTER);
            addView(hint, new FrameLayout.LayoutParams(-1, -1));

            // pilihan tampilan: gambar penuh / garis hitam (pojok kiri atas)
            pill = new Ui.Seg(c, new String[]{"Penuh", "Garis"}, true, new Ui.Seg.OnPick() {
                @Override public void pick(int i) {
                    Cfg.puti("viewmode", i == 1 ? Cfg.VIEW_LINES : Cfg.VIEW_FULL);
                }
            });
            pill.setBackground(Ui.round(0xE61B1C36, Ui.dp(c, 12)));
            pill.select(Cfg.viewMode());
            FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
            plp.setMargins(Ui.dp(c, 6), Ui.dp(c, 6), 0, 0);
            addView(pill, plp);

            // pegangan ubah ukuran (pojok kanan bawah)
            View handle = new View(c);
            GradientDrawable hg = new GradientDrawable();
            hg.setShape(GradientDrawable.OVAL);
            hg.setColor(Ui.ACCENT);
            hg.setStroke(Ui.dp(c, 2), 0xFFFFFFFF);
            handle.setBackground(hg);
            int hs = Ui.dp(c, 34);
            FrameLayout.LayoutParams hlp = new FrameLayout.LayoutParams(hs, hs,
                    Gravity.BOTTOM | Gravity.RIGHT);
            addView(handle, hlp);

            // seret kotak untuk memindah
            setOnTouchListener(new View.OnTouchListener() {
                float dx, dy;
                int sx, sy;
                @Override public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            dx = e.getRawX(); dy = e.getRawY();
                            sx = boxLp.x; sy = boxLp.y;
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            boxLp.x = clampI(sx + Math.round(e.getRawX() - dx),
                                    -boxLp.width + Ui.dp(ui, 40), sw - Ui.dp(ui, 40));
                            boxLp.y = clampI(sy + Math.round(e.getRawY() - dy),
                                    0, sh - Ui.dp(ui, 40));
                            safeUpdate(box, boxLp);
                            return true;
                        default:
                            return true;
                    }
                }
            });

            // seret sudut untuk mengubah ukuran (rasio gambar tetap)
            handle.setOnTouchListener(new View.OnTouchListener() {
                float dx, dy, asp;
                int startW;
                @Override public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            dx = e.getRawX(); dy = e.getRawY();
                            startW = boxLp.width;
                            asp = (float) boxLp.width / Math.max(1, boxLp.height);
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            float delta = ((e.getRawX() - dx) + (e.getRawY() - dy) * asp) / 2f;
                            int nw = clampI(Math.round(startW + delta), Ui.dp(ui, 120), sw);
                            int nh = Math.round(nw / asp);
                            if (nh > sh) { nh = sh; nw = Math.round(nh * asp); }
                            boxLp.width = nw;
                            boxLp.height = nh;
                            safeUpdate(box, boxLp);
                            return true;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            schedulePreview(60);   // ukuran berubah -> hitung ulang garis hitam
                            return true;
                        default:
                            return true;
                    }
                }
            });
        }

        /** Sesuaikan isi kotak dengan mode tampilan (gambar penuh / garis hitam). */
        void applyMode() {
            pill.select(Cfg.viewMode());
            // saat menggambar kotak harus tembus pandang, jangan diubah
            if ((boxLp.flags & WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE) != 0) return;
            Bitmap ref = Cfg.ref;
            if (ref != null && Cfg.viewMode() == Cfg.VIEW_LINES) {
                setBackgroundColor(0xE6FFFFFF);       // latar putih supaya garis hitam jelas terbaca
                img.setAlpha(1f);
                if (lineBmp != null) {
                    BitmapDrawable d = new BitmapDrawable(getResources(), lineBmp);
                    d.setFilterBitmap(false);          // sel tampil tegas sesuai grid
                    img.setImageDrawable(d);
                } else {
                    img.setImageDrawable(null);        // menunggu hasil hitung
                }
            } else {
                setBackgroundColor(0x227C5CFF);
                img.setAlpha(0.6f);
                img.setImageBitmap(ref);
            }
        }
    }

    // =====================================================================
    // kontrol (bar kecil "jangan ganggu" atau panel pengaturan lengkap)
    // =====================================================================

    private void buildCtrl() {
        final boolean full = Cfg.overlayFull();

        LinearLayout root = new LinearLayout(ui);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(Ui.round(0xEE1B1C36, Ui.dp(ui, 16)));
        int pad = Ui.dp(ui, 8);
        root.setPadding(pad, pad, pad, pad);

        LinearLayout bar = new LinearLayout(ui);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        TextView grip = Ui.text(ui, full ? "\u2261  AutoDraw" : "\u2261", 15, Ui.MUTED, true);
        grip.setPadding(Ui.dp(ui, 6), Ui.dp(ui, 6), Ui.dp(ui, 12), Ui.dp(ui, 6));
        bar.addView(grip);

        TextView start = Ui.button(ui, "Mulai", Ui.ACCENT);
        start.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { onStartClicked(); }
        });
        bar.addView(start, barLp());

        if (Cfg.overlayPick()) {   // tombol pilih gambar dari layar mengambang
            TextView pic = Ui.button(ui, "Gambar", Ui.BTN);
            pic.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { openPicker(false); }
            });
            bar.addView(pic, barLp());

            TextView url = Ui.button(ui, "URL", Ui.BTN);
            url.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { openPicker(true); }
            });
            bar.addView(url, barLp());
        }

        TextView close = Ui.button(ui, "Tutup", Ui.BTN);
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { hideOverlay(); }
        });
        bar.addView(close, barLp());

        root.addView(bar);

        if (full) {
            ScrollView sv = new ScrollView(ui);
            sv.addView(SettingsUi.build(ui));
            root.addView(sv, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, Math.round(sh * 0.38f)));
        }

        ctrl = root;
        ctrlLp = newLp(full ? Math.min(sw - Ui.dp(ui, 16), Ui.dp(ui, 340))
                : WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT);

        root.measure(View.MeasureSpec.makeMeasureSpec(sw, View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(sh, View.MeasureSpec.AT_MOST));
        int mw = full ? ctrlLp.width : root.getMeasuredWidth();
        int mh = root.getMeasuredHeight();
        if (ctrlX < 0) {
            ctrlX = Math.max(0, (sw - mw) / 2);
            ctrlY = Math.max(0, sh - mh - Ui.dp(ui, 110));
        }
        ctrlLp.x = ctrlX;
        ctrlLp.y = ctrlY;

        attachDrag(grip);
        attachDrag(bar);
    }

    private LinearLayout.LayoutParams barLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = Ui.dp(ui, 4);
        return lp;
    }

    private void attachDrag(View handle) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy;
            int sx, sy;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = e.getRawX(); dy = e.getRawY();
                        sx = ctrlLp.x; sy = ctrlLp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        ctrlX = clampI(sx + Math.round(e.getRawX() - dx), 0, sw - Ui.dp(ui, 60));
                        ctrlY = clampI(sy + Math.round(e.getRawY() - dy), 0, sh - Ui.dp(ui, 60));
                        ctrlLp.x = ctrlX;
                        ctrlLp.y = ctrlY;
                        safeUpdate(ctrl, ctrlLp);
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    private void attachCtrl() {
        if (!shown || ctrlAttached || ctrl == null || picking) return;
        try { wm.addView(ctrl, ctrlLp); ctrlAttached = true; } catch (Exception ignored) {}
    }

    private void detachCtrl() {
        if (ctrl != null && ctrlAttached) {
            try { wm.removeViewImmediate(ctrl); } catch (Exception ignored) {}
        }
        ctrlAttached = false;
    }

    private void rebuildCtrl() {
        if (!shown) return;
        boolean was = ctrlAttached;
        detachCtrl();
        buildCtrl();
        if (was && !busy) attachCtrl();
    }

    // =====================================================================
    // pilih gambar / URL saat layar mengambang tampil
    // =====================================================================

    private void openPicker(boolean url) {
        if (!shown || busy) return;
        picking = true;
        // sembunyikan overlay supaya tidak menutupi pemilih gambar
        detachCtrl();
        detachBox();
        try {
            Intent i = new Intent(this, PickActivity.class);
            i.putExtra(PickActivity.EXTRA_URL, url);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Throwable t) {
            toast("Gagal membuka pemilih gambar");
            restoreAfterPick();
            return;
        }
        // jaga-jaga bila Android memblokir pembukaan activity dari latar belakang
        main.postDelayed(new Runnable() {
            @Override public void run() {
                if (picking && !PickActivity.alive) {
                    toast("Android memblokir jendela ini dari layar mengambang. Masukkan gambar lewat aplikasi AutoDraw.");
                    restoreAfterPick();
                }
            }
        }, 3500);
    }

    private void restoreAfterPick() {
        if (!picking) return;
        picking = false;
        if (!shown) return;
        applyRef();
        attachBox();
        attachCtrl();
    }

    // =====================================================================
    // mulai menggambar
    // =====================================================================

    private void onStartClicked() {
        if (busy || !shown) return;
        if (Cfg.ref == null) {
            toast(Cfg.overlayPick() ? "Pilih gambar dulu (tombol Gambar atau URL)" : "Pilih gambar dulu");
            return;
        }
        busy = true;
        stopFlag = false;
        final int run = ++runId;

        final int[] loc = new int[2];
        box.getLocationOnScreen(loc);
        final int bw = Math.max(1, box.getWidth());
        final int bh = Math.max(1, box.getHeight());
        final Bitmap ref = Cfg.ref;
        final int mode = Cfg.mode(), grid = Cfg.grid(), thr = Cfg.threshold();
        final int brush = Cfg.brush();
        final boolean fill = Cfg.fillThick(), anim = Cfg.anim();
        final int vc = clampI(Math.round(bw / (float) Ui.dp(ui, 7)), 8, 64);
        final int vr = clampI(Math.round(vc * (float) bh / bw), 8, 96);

        toast("Menghitung goresan...");
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    final ArrayList<float[]> strokes =
                            Tracer.trace(ref, bw, bh, mode, grid, thr, brush, fill);
                    final boolean[] cells = anim ? Tracer.mask(ref, vc, vr, thr) : null;
                    main.post(new Runnable() {
                        @Override public void run() {
                            afterTrace(run, strokes, cells, vc, vr, loc[0], loc[1]);
                        }
                    });
                } catch (final Throwable t) {
                    main.post(new Runnable() {
                        @Override public void run() {
                            if (run != runId) return;
                            busy = false;
                            toast("Gagal: " + t);
                        }
                    });
                }
            }
        }).start();
    }

    private void afterTrace(final int run, final ArrayList<float[]> strokes, boolean[] cells,
                            int vc, int vr, final int ox, final int oy) {
        if (run != runId || !shown) return;
        if (strokes.isEmpty()) {
            busy = false;
            toast("Tidak ada garis hitam terdeteksi");
            return;
        }
        if (cells != null) {
            box.scan.setCells(cells, vc, vr);
            box.scan.play(new Runnable() {
                @Override public void run() { beginDraw(run, strokes, ox, oy); }
            });
        } else {
            beginDraw(run, strokes, ox, oy);
        }
    }

    private void beginDraw(int run, ArrayList<float[]> strokes, int ox, int oy) {
        if (run != runId || !shown) return;

        // buat kotak "tembus sentuhan" & sembunyikan kontrol supaya gesture sampai ke kanvas
        detachCtrl();
        boxLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        safeUpdate(box, boxLp);
        box.img.setVisibility(View.INVISIBLE);
        box.hint.setVisibility(View.GONE);
        box.pill.setVisibility(View.GONE);
        box.setBackgroundColor(0x227C5CFF);
        attachStop();

        units = makeUnits(strokes, ox, oy, Cfg.mode(), Cfg.noZoom());
        cursor = 0;
        fails = 0;
        maxStrokes = Math.max(2, GestureDescription.getMaxStrokeCount());
        maxDur = Math.min(GestureDescription.getMaxGestureDuration(), BATCH_MS);

        final int r = run;
        main.postDelayed(new Runnable() {
            @Override public void run() { dispatchBatch(r); }
        }, 200);
    }

    // =====================================================================
    // goresan -> gesture
    // =====================================================================

    private ArrayList<Unit> makeUnits(ArrayList<float[]> strokes, int ox, int oy, int mode,
                                      boolean noZoom) {
        final float pxPerMs = (float) (0.2 * Math.pow(1.35, Cfg.speed() - 1));

        ArrayList<float[]> sc = new ArrayList<>(strokes.size());
        for (float[] s : strokes) {
            float[] t = new float[s.length];
            for (int i = 0; i < s.length; i += 2) {
                t[i] = clampF(s[i] + ox, 0f, sw - 1f);
                t[i + 1] = clampF(s[i + 1] + oy, 0f, sh - 1f);
            }
            sc.add(t);
        }

        ArrayList<Unit> out = new ArrayList<>();
        if (mode == Cfg.MODE_HUMAN) {
            // gaya tangan: goresan diperhalus + bergetar, kecepatan & jeda bervariasi
            float density = getResources().getDisplayMetrics().density;
            Human.Plan plan = Human.make(sc, density, Cfg.human());
            for (int i = 0; i < plan.strokes.size(); i++) {
                Unit u = single(plan.strokes.get(i), pxPerMs * plan.speed[i]);
                u.gap = plan.pause[i];
                out.add(u);
            }
            return out;
        }
        if (mode != Cfg.MODE_TWO) {
            for (float[] s : sc) out.add(single(s, pxPerMs));
            return out;
        }

        // Dua jari: bagi goresan jadi bagian atas & bawah (median y), lalu jalankan berpasangan
        int n = sc.size();
        float[] cy = new float[n];
        for (int i = 0; i < n; i++) {
            float[] s = sc.get(i);
            float sum = 0f;
            for (int j = 1; j < s.length; j += 2) sum += s[j];
            cy[i] = sum / (s.length / 2);
        }
        float[] sorted = cy.clone();
        Arrays.sort(sorted);
        float med = sorted[n / 2];
        ArrayList<float[]> top = new ArrayList<>(), bottom = new ArrayList<>();
        for (int i = 0; i < n; i++) (cy[i] < med ? top : bottom).add(sc.get(i));

        int m = Math.min(top.size(), bottom.size());
        for (int i = 0; i < m; i++) {
            Unit u = new Unit();
            u.a = top.get(i);
            u.b = bottom.get(i);
            long d1 = durOf(u.a, pxPerMs), d2 = durOf(u.b, pxPerMs);
            if (noZoom) { d1 = Math.max(d1, d2); d2 = d1; } // mulai & selesai bersamaan
            u.da = d1;
            u.db = d2;
            u.dur = Math.max(d1, d2);
            out.add(u);
        }
        for (int i = m; i < top.size(); i++) out.add(single(top.get(i), pxPerMs));
        for (int i = m; i < bottom.size(); i++) out.add(single(bottom.get(i), pxPerMs));
        return out;
    }

    private Unit single(float[] s, float pxPerMs) {
        Unit u = new Unit();
        u.a = s;
        u.da = durOf(s, pxPerMs);
        u.dur = u.da;
        return u;
    }

    private long durOf(float[] s, float pxPerMs) {
        float len = 0f;
        for (int i = 2; i < s.length; i += 2) {
            len += (float) Math.hypot(s[i] - s[i - 2], s[i + 1] - s[i - 1]);
        }
        long d = Math.round(len / pxPerMs);
        return Math.max(6, Math.min(4000, d));
    }

    private GestureDescription.StrokeDescription stroke(float[] p, long start, long dur) {
        Path path = new Path();
        path.moveTo(p[0], p[1]);
        for (int i = 2; i < p.length; i += 2) path.lineTo(p[i], p[i + 1]);
        return new GestureDescription.StrokeDescription(path, start, dur);
    }

    private void dispatchBatch(final int run) {
        if (run != runId) return;
        if (stopFlag || cursor >= units.size()) {
            finishDraw(run, !stopFlag);
            return;
        }

        final int startCursor = cursor;
        GestureDescription.Builder gb = new GestureDescription.Builder();
        long t = 0;
        int cnt = 0;
        try {
            while (cursor < units.size()) {
                Unit u = units.get(cursor);
                int need = (u.b == null) ? 1 : 2;
                if (cnt > 0 && (cnt + need > maxStrokes || t + u.dur > maxDur)) break;
                gb.addStroke(stroke(u.a, t, u.da));
                if (u.b != null) gb.addStroke(stroke(u.b, t, u.db));
                t += u.dur + u.gap;
                cnt += need;
                cursor++;
                if (cnt >= maxStrokes) break;
            }
        } catch (Throwable e) {
            toast("Gagal: " + e.getMessage());
            finishDraw(run, false);
            return;
        }

        updateProgress();

        boolean ok = dispatchGesture(gb.build(), new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) {
                if (run != runId) return;
                fails = 0;
                dispatchBatch(run);
            }
            @Override public void onCancelled(GestureDescription g) {
                if (run != runId) return;
                if (++fails > 3) {
                    toast("Berhenti: gesture dibatalkan sistem");
                    finishDraw(run, false);
                } else {
                    cursor = startCursor;   // ulangi batch yang sama
                    main.postDelayed(new Runnable() {
                        @Override public void run() { dispatchBatch(run); }
                    }, 150);
                }
            }
        }, main);

        if (!ok) {
            toast("Gagal mengirim gesture");
            finishDraw(run, false);
        }
    }

    private void updateProgress() {
        if (stopBtn != null && units != null && !units.isEmpty()) {
            stopBtn.setText("STOP\n" + (cursor * 100 / units.size()) + "%");
        }
    }

    private void finishDraw(int run, boolean completed) {
        if (run != runId) return;
        busy = false;
        detachStop();
        if (!shown) return;
        boxLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        safeUpdate(box, boxLp);
        box.img.setVisibility(View.VISIBLE);
        box.hint.setVisibility(Cfg.ref == null ? View.VISIBLE : View.GONE);
        box.pill.setVisibility(Cfg.ref == null ? View.GONE : View.VISIBLE);
        box.applyMode();
        attachCtrl();
        toast(completed ? "Selesai" : "Dihentikan");
    }

    private void stopDrawing() {
        if (!busy) return;
        stopFlag = true;
        finishDraw(runId, false);
        runId++;    // callback gesture yang masih berjalan jadi tidak berlaku
    }

    // =====================================================================
    // tombol STOP merah (pojok kanan atas)
    // =====================================================================

    private void attachStop() {
        if (stopAttached) return;
        stopBtn = Ui.text(ui, "STOP\n0%", 12, 0xFFFFFFFF, true);
        stopBtn.setGravity(Gravity.CENTER);
        stopBtn.setBackground(Ui.round(Ui.DANGER, Ui.dp(ui, 30)));
        stopBtn.setClickable(true);
        stopBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { stopDrawing(); }
        });
        int s = Ui.dp(ui, 60);
        stopLp = newLp(s, s);
        stopLp.gravity = Gravity.TOP | Gravity.RIGHT;
        stopLp.x = Ui.dp(ui, 12);
        stopLp.y = Ui.dp(ui, 40);
        try { wm.addView(stopBtn, stopLp); stopAttached = true; } catch (Exception ignored) {}
    }

    private void detachStop() {
        if (stopBtn != null && stopAttached) {
            try { wm.removeViewImmediate(stopBtn); } catch (Exception ignored) {}
        }
        stopAttached = false;
    }

    // =====================================================================
    // util
    // =====================================================================

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private static int clampI(int v, int lo, int hi) {
        if (hi < lo) return lo;
        return Math.max(lo, Math.min(hi, v));
    }

    private static float clampF(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
