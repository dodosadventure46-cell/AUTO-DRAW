package com.autodraw;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;

/**
 * Gaya menggambar "Manusiawi" untuk lineart. Tujuannya meniru cara orang menggambar garis:
 *
 *  1. Potongan skeleton disambung menjadi goresan panjang yang mengalir (lewat percabangan
 *     dipilih arah paling lurus), bukan ratusan potongan pendek.
 *  2. Garis dihaluskan menjadi kurva (spline Hermite). Sudut tajam tetap tajam.
 *  3. Getar tangan halus + sedikit lengkung busur, ujung goresan kadang melewati batas.
 *  4. Urutan: bentuk besar/kontur dulu, detail kecil belakangan, mulai dari ujung terdekat
 *     dengan posisi pena.
 *  5. Satu goresan panjang dipecah jadi beberapa bagian bersambung dengan kecepatan berbeda:
 *     pelan di awal dan akhir, cepat di tengah, melambat di tikungan.
 *  6. Jeda antar goresan seperti mengangkat tangan dan memindahkannya, sesekali berhenti lama.
 *
 * Semua koordinat dalam piksel layar. level 1..10 = seberapa kasar gaya tangannya.
 */
final class Human {
    private Human() {}

    static final class Plan {
        final ArrayList<float[]> strokes = new ArrayList<>();
        final ArrayList<Float> speed = new ArrayList<>();
        final ArrayList<Long> pause = new ArrayList<>();
    }

    /** join = jarak maksimum (px) antar ujung goresan yang boleh disambung. */
    static Plan make(ArrayList<float[]> in, float density, int level, float join) {
        level = Math.max(1, Math.min(10, level));
        final Random rnd = new Random(System.nanoTime());
        final float lv = level / 10f;
        final Plan plan = new Plan();
        if (in.isEmpty()) return plan;

        final float step = Math.max(3f, 3.5f * density);
        final float ampMax = (0.2f + 1.3f * lv) * density;

        ArrayList<float[]> paths = new ArrayList<>();
        for (float[] c : chain(in, join)) {
            float[] sp = c.length >= 4 ? shape(c, rnd, ampMax, step, density, lv) : c;
            if (finite(sp)) paths.add(sp);
        }
        paths = order(paths, density);

        for (float[] p : paths) emit(plan, p, rnd, density, lv);
        return plan;
    }

    // ------------------------------------------------------------------ 1. sambung goresan

    private static ArrayList<float[]> chain(ArrayList<float[]> in, float join) {
        final int n = in.size();
        if (n < 2 || n > 20000) return in;
        final float cell = Math.max(2f, join);
        final HashMap<Long, ArrayList<Integer>> map = new HashMap<>();
        for (int i = 0; i < n; i++) {
            float[] s = in.get(i);
            if (s.length < 4) continue;
            put(map, cell, s[0], s[1], i * 2);
            put(map, cell, s[s.length - 2], s[s.length - 1], i * 2 + 1);
        }
        Integer[] idx = new Integer[n];
        for (int i = 0; i < n; i++) idx[i] = i;
        final float[] len = new float[n];
        for (int i = 0; i < n; i++) len[i] = length(in.get(i));
        Arrays.sort(idx, (a, b) -> Float.compare(len[b], len[a]));

        boolean[] used = new boolean[n];
        ArrayList<float[]> out = new ArrayList<>();
        for (int k = 0; k < n; k++) {
            int i = idx[k];
            if (used[i]) continue;
            used[i] = true;
            float[] cur = in.get(i);
            if (cur.length >= 4) {
                cur = extend(cur, in, map, used, cell, join);
                cur = Tracer.reverse(cur);
                cur = extend(cur, in, map, used, cell, join);
            }
            out.add(cur);
        }
        return out;
    }

    private static void put(HashMap<Long, ArrayList<Integer>> map, float cell, float x, float y, int id) {
        long key = key((int) Math.floor(x / cell), (int) Math.floor(y / cell));
        ArrayList<Integer> l = map.get(key);
        if (l == null) { l = new ArrayList<>(2); map.put(key, l); }
        l.add(id);
    }

    private static long key(int cx, int cy) { return ((long) cx << 32) ^ (cy & 0xffffffffL); }

    /** Sambungkan ujung akhir 'cur' dengan goresan lain yang arahnya paling menerus. */
    private static float[] extend(float[] cur, ArrayList<float[]> in, HashMap<Long, ArrayList<Integer>> map,
                                  boolean[] used, float cell, float join) {
        float[] buf = Arrays.copyOf(cur, Math.max(cur.length * 2, 64));
        int len = cur.length;
        final float minD = Math.max(4f, join);
        for (int guard = 0; guard < 5000; guard++) {
            float tx = buf[len - 2], ty = buf[len - 1];
            float[] hv = into(buf, len, false, minD);          // dari ujung masuk ke goresan
            float hx = -hv[0], hy = -hv[1];                     // arah gerak saat tiba di ujung
            int cx = (int) Math.floor(tx / cell), cy = (int) Math.floor(ty / cell);
            int best = -1;
            float bestScore = Float.MAX_VALUE;
            for (int ox = -1; ox <= 1; ox++) {
                for (int oy = -1; oy <= 1; oy++) {
                    ArrayList<Integer> l = map.get(key(cx + ox, cy + oy));
                    if (l == null) continue;
                    for (int id : l) {
                        int t = id >> 1;
                        if (used[t]) continue;
                        float[] s = in.get(t);
                        boolean atStart = (id & 1) == 0;
                        float ex = atStart ? s[0] : s[s.length - 2], ey = atStart ? s[1] : s[s.length - 1];
                        float d = (float) Math.hypot(ex - tx, ey - ty);
                        if (d > join) continue;
                        float[] cv = into(s, s.length, atStart, minD);
                        float dot = hx * cv[0] + hy * cv[1];
                        if (dot < 0.55f) continue;               // belokan > ~57 derajat bukan lanjutan
                        float score = d / join + (1f - dot) * 1.5f;
                        if (score < bestScore) { bestScore = score; best = id; }
                    }
                }
            }
            if (best < 0) break;
            int t = best >> 1;
            used[t] = true;
            float[] s = in.get(t);
            if ((best & 1) == 1) s = Tracer.reverse(s);          // masuk dari ujung awal
            int add = s.length;
            if (len + add > buf.length) buf = Arrays.copyOf(buf, Math.max(buf.length * 2, len + add));
            System.arraycopy(s, 0, buf, len, add);
            len += add;
        }
        return len == cur.length ? cur : Arrays.copyOf(buf, len);
    }

    /** Vektor satuan dari ujung (awal/akhir) menuju bagian dalam goresan, minimal sejauh minD. */
    private static float[] into(float[] s, int len, boolean atStart, float minD) {
        int m = len / 2;
        int e = atStart ? 0 : m - 1;
        float ex = s[e * 2], ey = s[e * 2 + 1];
        float vx = 0f, vy = 0f;
        for (int k = 1; k < m; k++) {
            int i = atStart ? k : m - 1 - k;
            vx = s[i * 2] - ex;
            vy = s[i * 2 + 1] - ey;
            if (vx * vx + vy * vy >= minD * minD) break;
        }
        float l = (float) Math.hypot(vx, vy);
        if (l < 1e-4f) return new float[]{1f, 0f};
        return new float[]{vx / l, vy / l};
    }

    // ------------------------------------------------------------------ 2-3. bentuk goresan

    private static float[] shape(float[] s, Random rnd, float ampMax, float step, float density, float lv) {
        float[] p = hermite(s, step);
        int m = p.length / 2;
        if (m < 3) return p;

        float[] cum = new float[m];
        for (int i = 1; i < m; i++) {
            cum[i] = cum[i - 1] + (float) Math.hypot(p[i * 2] - p[i * 2 - 2], p[i * 2 + 1] - p[i * 2 - 1]);
        }
        float total = cum[m - 1];
        if (total < 1f) return p;

        float amp = ampMax * Math.min(1f, total / (50f * density));
        float lam1 = (40f + rnd.nextFloat() * 60f) * density;
        float lam2 = (12f + rnd.nextFloat() * 14f) * density;
        float ph1 = rnd.nextFloat() * 6.2832f, ph2 = rnd.nextFloat() * 6.2832f;
        float bowMax = Math.min(3f * density, total * 0.010f * (0.4f + 1.6f * lv));
        float bow = (rnd.nextFloat() * 2f - 1f) * bowMax;

        float[] r = new float[p.length + 2];
        for (int k = 0; k < m; k++) {
            int a = Math.max(0, k - 1), b = Math.min(m - 1, k + 1);
            float tx = p[b * 2] - p[a * 2], ty = p[b * 2 + 1] - p[a * 2 + 1];
            float tl = (float) Math.hypot(tx, ty);
            float x = p[k * 2], y = p[k * 2 + 1];
            if (tl > 1e-4f) {
                tx /= tl;
                ty /= tl;
                float d = cum[k], u = d / total;
                float env = (float) Math.sqrt(Math.max(0f, Math.sin(Math.PI * u)));
                float w = 0.6f * (float) Math.sin(6.2832f * d / lam1 + ph1)
                        + 0.4f * (float) Math.sin(6.2832f * d / lam2 + ph2);
                float off = (amp * w + bow * (float) Math.sin(Math.PI * u)) * env;
                x += -ty * off;
                y += tx * off;
            }
            r[k * 2] = x;
            r[k * 2 + 1] = y;
        }

        // ujung goresan kadang sedikit melewati batas, seperti tangan yang tidak berhenti tepat
        float[] res = Arrays.copyOf(r, p.length);
        boolean open = Math.hypot(res[0] - res[res.length - 2], res[1] - res[res.length - 1]) > 3f * step;
        if (open && total > 35f * density && rnd.nextFloat() < 0.55f) {
            float over = (0.4f + rnd.nextFloat() * 1.6f) * density * (0.5f + lv);
            float ex = res[res.length - 2] - res[res.length - 4];
            float ey = res[res.length - 1] - res[res.length - 3];
            float el = (float) Math.hypot(ex, ey);
            if (el > 1e-4f) {
                res = Arrays.copyOf(res, res.length + 2);
                res[res.length - 2] = res[res.length - 4] + ex / el * over;
                res[res.length - 1] = res[res.length - 3] + ey / el * over;
            }
        }
        return res;
    }

    /** Spline Hermite lewat titik-titik goresan. Belokan tajam (> ~70 derajat) dibiarkan tajam. */
    private static float[] hermite(float[] s, float step) {
        int m = s.length / 2;
        if (m < 2) return s;
        float[] dx = new float[m], dy = new float[m];
        for (int k = 0; k < m; k++) {
            int a = Math.max(0, k - 1), b = Math.min(m - 1, k + 1);
            float vx = s[b * 2] - s[a * 2], vy = s[b * 2 + 1] - s[a * 2 + 1];
            float l = (float) Math.hypot(vx, vy);
            if (l > 1e-4f) { dx[k] = vx / l; dy[k] = vy / l; }
            if (k > 0 && k < m - 1) {
                float ax = s[k * 2] - s[k * 2 - 2], ay = s[k * 2 + 1] - s[k * 2 - 1];
                float bx = s[k * 2 + 2] - s[k * 2], by = s[k * 2 + 3] - s[k * 2 + 1];
                float la = (float) Math.hypot(ax, ay), lb = (float) Math.hypot(bx, by);
                if (la > 1e-4f && lb > 1e-4f && (ax * bx + ay * by) / (la * lb) < 0.35f) {
                    dx[k] = 0f; dy[k] = 0f;
                }
            }
        }
        int[] cnt = new int[m - 1];
        int total = 1;
        for (int i = 0; i < m - 1; i++) {
            float L = (float) Math.hypot(s[i * 2 + 2] - s[i * 2], s[i * 2 + 3] - s[i * 2 + 1]);
            cnt[i] = Math.max(1, (int) Math.ceil(L / step));
            total += cnt[i];
        }
        float[] out = new float[total * 2];
        int o = 0;
        out[o++] = s[0];
        out[o++] = s[1];
        for (int i = 0; i < m - 1; i++) {
            float x0 = s[i * 2], y0 = s[i * 2 + 1], x1 = s[i * 2 + 2], y1 = s[i * 2 + 3];
            float L = (float) Math.hypot(x1 - x0, y1 - y0);
            for (int j = 1; j <= cnt[i]; j++) {
                float t = (float) j / cnt[i], t2 = t * t, t3 = t2 * t;
                float h00 = 2 * t3 - 3 * t2 + 1, h10 = t3 - 2 * t2 + t;
                float h01 = -2 * t3 + 3 * t2, h11 = t3 - t2;
                out[o++] = h00 * x0 + h10 * L * dx[i] + h01 * x1 + h11 * L * dx[i + 1];
                out[o++] = h00 * y0 + h10 * L * dy[i] + h01 * y1 + h11 * L * dy[i + 1];
            }
        }
        return out;
    }

    // ------------------------------------------------------------------ 4. urutan

    /** Goresan terpanjang (kontur) dulu, lalu menengah, lalu detail. Di tiap tahap: ujung terdekat dari pena. */
    private static ArrayList<float[]> order(ArrayList<float[]> in, float density) {
        int n = in.size();
        if (n < 2) return in;
        Integer[] idx = new Integer[n];
        final float[] len = new float[n];
        for (int i = 0; i < n; i++) { idx[i] = i; len[i] = length(in.get(i)); }
        Arrays.sort(idx, (a, b) -> Float.compare(len[b], len[a]));

        int a = Math.max(1, Math.round(n * 0.2f)), b = Math.max(a, Math.round(n * 0.5f));
        ArrayList<float[]> out = new ArrayList<>(n);
        float cx = 0f, cy = 0f;
        int[] bounds = {0, a, b, n};
        for (int t = 0; t < 3; t++) {
            int from = bounds[t], to = bounds[t + 1];
            int cnt = to - from;
            if (cnt <= 0) continue;
            ArrayList<float[]> grp = new ArrayList<>(cnt);
            for (int k = from; k < to; k++) grp.add(in.get(idx[k]));
            if (cnt > 6000) { out.addAll(grp); continue; }
            boolean[] used = new boolean[cnt];
            for (int step = 0; step < cnt; step++) {
                int best = -1;
                boolean flip = false;
                float bd = Float.MAX_VALUE;
                for (int i = 0; i < cnt; i++) {
                    if (used[i]) continue;
                    float[] s = grp.get(i);
                    int L = s.length;
                    float d1 = sq(s[0] - cx, s[1] - cy), d2 = sq(s[L - 2] - cx, s[L - 1] - cy);
                    // tangan kanan lebih suka memulai dari kiri / atas
                    boolean startPreferred = prefersStart(s);
                    if (startPreferred) d1 *= 0.7f; else d2 *= 0.7f;
                    if (d1 < bd) { bd = d1; best = i; flip = false; }
                    if (d2 < bd) { bd = d2; best = i; flip = true; }
                }
                used[best] = true;
                float[] s = grp.get(best);
                if (flip) s = Tracer.reverse(s);
                out.add(s);
                cx = s[s.length - 2];
                cy = s[s.length - 1];
            }
        }
        return out;
    }

    private static boolean prefersStart(float[] s) {
        float dx = s[s.length - 2] - s[0], dy = s[s.length - 1] - s[1];
        return Math.abs(dx) >= Math.abs(dy) ? dx >= 0 : dy >= 0;
    }

    // ------------------------------------------------------------------ 5-6. kecepatan & jeda

    /** Pecah goresan panjang jadi bagian bersambung dengan kecepatan berbeda, lalu beri jeda di akhir. */
    private static void emit(Plan plan, float[] p, Random rnd, float density, float lv) {
        int m = p.length / 2;
        float total = length(p);
        float base = 0.8f + (rnd.nextFloat() - 0.5f) * 0.5f * lv;
        base *= 1f + Math.min(0.25f, total / (600f * density));

        long pause = 50 + Math.round(rnd.nextFloat() * (90 + 120 * lv));
        if (rnd.nextFloat() < 0.03f + 0.05f * lv) pause += 200 + Math.round(rnd.nextFloat() * 500 * lv);

        if (m < 3 || total < 60f * density) {
            plan.strokes.add(p);
            plan.speed.add(clamp(base, 0.4f, 1.8f));
            plan.pause.add(pause);
            return;
        }

        float[] cum = new float[m];
        for (int i = 1; i < m; i++) {
            cum[i] = cum[i - 1] + (float) Math.hypot(p[i * 2] - p[i * 2 - 2], p[i * 2 + 1] - p[i * 2 - 1]);
        }
        int nseg = Math.max(2, Math.min(5, Math.round(total / ((60f + rnd.nextFloat() * 40f) * density))));
        float[] cut = new float[nseg + 1];
        for (int j = 1; j < nseg; j++) {
            cut[j] = total * j / nseg + (rnd.nextFloat() - 0.5f) * 0.3f * total / nseg;
        }
        cut[nseg] = total;

        for (int j = 0; j < nseg; j++) {
            float[] seg = slice(p, cum, cut[j], cut[j + 1]);
            if (j < nseg - 1 && length(seg) < 2f) continue;     // potongan terlalu pendek dilewati
            float u = (j + 0.5f) / nseg;
            // pelan di awal & akhir, cepat di tengah
            float ease = 0.6f + 0.6f * (float) Math.sin(Math.PI * u);
            // melambat di tikungan
            float segLen = Math.max(1f, cut[j + 1] - cut[j]);
            float turn = turning(seg) / segLen * 10f * density;
            float curv = clamp(1.25f - 0.9f * turn, 0.55f, 1.25f);
            float sp = base * ease * curv * (0.92f + 0.16f * rnd.nextFloat());
            plan.strokes.add(seg);
            plan.speed.add(clamp(sp, 0.35f, 1.9f));
            plan.pause.add(j == nseg - 1 ? pause : 0L);
        }
    }

    /** Potongan polyline dari panjang kumulatif a sampai b (titik ujung diinterpolasi). */
    private static float[] slice(float[] p, float[] cum, float a, float b) {
        int m = cum.length;
        ArrayList<Float> pts = new ArrayList<>();
        float[] s = at(p, cum, a);
        pts.add(s[0]);
        pts.add(s[1]);
        for (int i = 0; i < m; i++) {
            if (cum[i] > a + 1e-3f && cum[i] < b - 1e-3f) {
                pts.add(p[i * 2]);
                pts.add(p[i * 2 + 1]);
            }
        }
        float[] e = at(p, cum, b);
        pts.add(e[0]);
        pts.add(e[1]);
        float[] r = new float[pts.size()];
        for (int i = 0; i < r.length; i++) r[i] = pts.get(i);
        return r;
    }

    private static float[] at(float[] p, float[] cum, float d) {
        int m = cum.length;
        if (d <= 0f) return new float[]{p[0], p[1]};
        if (d >= cum[m - 1]) return new float[]{p[(m - 1) * 2], p[(m - 1) * 2 + 1]};
        int i = 1;
        while (i < m - 1 && cum[i] < d) i++;
        float seg = cum[i] - cum[i - 1];
        float t = seg < 1e-4f ? 0f : (d - cum[i - 1]) / seg;
        return new float[]{p[(i - 1) * 2] + (p[i * 2] - p[(i - 1) * 2]) * t,
                p[(i - 1) * 2 + 1] + (p[i * 2 + 1] - p[(i - 1) * 2 + 1]) * t};
    }

    /** Total perubahan arah (radian) sepanjang polyline. */
    private static float turning(float[] s) {
        int m = s.length / 2;
        float sum = 0f;
        for (int i = 1; i < m - 1; i++) {
            float ax = s[i * 2] - s[i * 2 - 2], ay = s[i * 2 + 1] - s[i * 2 - 1];
            float bx = s[i * 2 + 2] - s[i * 2], by = s[i * 2 + 3] - s[i * 2 + 1];
            float la = (float) Math.hypot(ax, ay), lb = (float) Math.hypot(bx, by);
            if (la < 1e-4f || lb < 1e-4f) continue;
            float c = Math.max(-1f, Math.min(1f, (ax * bx + ay * by) / (la * lb)));
            sum += (float) Math.acos(c);
        }
        return sum;
    }

    // ------------------------------------------------------------------ util

    private static float length(float[] s) {
        float len = 0f;
        for (int i = 2; i < s.length; i += 2) {
            len += (float) Math.hypot(s[i] - s[i - 2], s[i + 1] - s[i - 1]);
        }
        return len;
    }

    private static boolean finite(float[] s) {
        for (float v : s) if (Float.isNaN(v) || Float.isInfinite(v)) return false;
        return true;
    }

    private static float sq(float x, float y) { return x * x + y * y; }

    private static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }
}
