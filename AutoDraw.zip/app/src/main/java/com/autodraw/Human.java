package com.autodraw;

import java.util.ArrayList;
import java.util.Random;

/**
 * Gaya menggambar "Manusiawi": mengubah goresan mesin yang kaku menjadi goresan yang terlihat
 * digambar tangan.
 *
 *  - sudut diperhalus (Chaikin) dan garis lurus diberi sedikit lengkung
 *  - getaran halus tangan: simpangan tegak lurus arah goresan, kecil di ujung, terbesar di tengah
 *  - arah goresan mengikuti kebiasaan tangan kanan (kiri ke kanan, atas ke bawah)
 *  - kecepatan tiap goresan berbeda-beda, ada jeda singkat antar goresan dan sesekali jeda "mikir"
 *
 * Semua koordinat dalam piksel layar. level 1..10 mengatur seberapa kasar gayanya.
 */
final class Human {
    private Human() {}

    static final class Plan {
        ArrayList<float[]> strokes = new ArrayList<>();
        /** Pengali kecepatan per goresan (1 = normal). */
        float[] speed;
        /** Jeda setelah tiap goresan, ms. */
        long[] pause;
    }

    static Plan make(ArrayList<float[]> in, float density, int level) {
        level = Math.max(1, Math.min(10, level));
        final Random rnd = new Random(System.nanoTime());
        final Plan plan = new Plan();
        final int n = in.size();
        plan.speed = new float[n];
        plan.pause = new long[n];

        final float lv = level / 10f;
        final float ampMax = (0.25f + 1.6f * lv) * density;       // simpangan getaran maksimum (px)
        final float step = Math.max(3f, 4f * density);           // jarak antar titik hasil resample

        for (int i = 0; i < n; i++) {
            float[] s = in.get(i);
            float[] out = s.length >= 4 ? humanize(s, rnd, ampMax, step, density, lv) : s;
            out = orient(out);
            plan.strokes.add(out);

            // kecepatan: acak per goresan, goresan panjang cenderung disapu lebih cepat
            float len = length(out);
            float f = 1f + (rnd.nextFloat() - 0.5f) * 1.1f * lv;
            f *= 1f + Math.min(0.3f, len / (500f * density));
            plan.speed[i] = Math.max(0.5f, Math.min(1.7f, f));

            // jeda singkat antar goresan; sesekali jeda lebih lama seperti berhenti berpikir
            long p = 15 + Math.round(rnd.nextFloat() * (20 + 55 * lv));
            if (rnd.nextFloat() < 0.02f + 0.04f * lv) p += 120 + Math.round(rnd.nextFloat() * 380 * lv);
            plan.pause[i] = p;
        }
        return plan;
    }

    // ------------------------------------------------------------------

    private static float[] humanize(float[] s, Random rnd, float ampMax, float step,
                                    float density, float lv) {
        float[] p = s;
        // sudut dibulatkan dulu, ujung goresan tetap
        p = chaikin(p);
        if (length(p) > 40f * density) p = chaikin(p);

        float total = length(p);
        if (total < 1f) return s;

        int cnt = Math.max(3, (int) Math.ceil(total / step) + 1);
        float[] res = new float[cnt * 2];

        // panjang kumulatif untuk resample
        int m = p.length / 2;
        float[] cum = new float[m];
        for (int i = 1; i < m; i++) {
            cum[i] = cum[i - 1] + (float) Math.hypot(p[i * 2] - p[i * 2 - 2], p[i * 2 + 1] - p[i * 2 - 1]);
        }

        // amplitudo mengecil untuk goresan pendek supaya detail kecil tidak rusak
        float amp = ampMax * Math.min(1f, total / (45f * density));
        float lam1 = (35f + rnd.nextFloat() * 55f) * density;
        float lam2 = (11f + rnd.nextFloat() * 14f) * density;
        float ph1 = rnd.nextFloat() * 6.2832f, ph2 = rnd.nextFloat() * 6.2832f;
        // lengkung busur halus pada goresan panjang (arah acak)
        float bowMax = Math.min(3.2f * density, total * 0.012f * (0.4f + 1.6f * lv));
        float bow = (rnd.nextFloat() * 2f - 1f) * bowMax;

        int seg = 1;
        for (int k = 0; k < cnt; k++) {
            float d = total * k / (cnt - 1);
            while (seg < m - 1 && cum[seg] < d) seg++;
            float segLen = cum[seg] - cum[seg - 1];
            float t = segLen < 1e-4f ? 0f : (d - cum[seg - 1]) / segLen;
            float x = p[(seg - 1) * 2] + (p[seg * 2] - p[(seg - 1) * 2]) * t;
            float y = p[(seg - 1) * 2 + 1] + (p[seg * 2 + 1] - p[(seg - 1) * 2 + 1]) * t;

            // arah singgung lokal
            float tx = p[seg * 2] - p[(seg - 1) * 2], ty = p[seg * 2 + 1] - p[(seg - 1) * 2 + 1];
            float tl = (float) Math.hypot(tx, ty);
            if (tl > 1e-4f) {
                tx /= tl;
                ty /= tl;
                float u = d / total;                                   // 0..1 sepanjang goresan
                float env = (float) Math.sqrt(Math.max(0f, Math.sin(Math.PI * u)));
                float w = 0.6f * (float) Math.sin(6.2832f * d / lam1 + ph1)
                        + 0.4f * (float) Math.sin(6.2832f * d / lam2 + ph2);
                float off = (amp * w + bow * (float) Math.sin(Math.PI * u)) * env;
                x += -ty * off;
                y += tx * off;
            }
            res[k * 2] = x;
            res[k * 2 + 1] = y;
        }
        // ujung awal & akhir tepat di titik asli
        res[0] = s[0];
        res[1] = s[1];
        res[res.length - 2] = s[s.length - 2];
        res[res.length - 1] = s[s.length - 1];
        return res;
    }

    /** Satu putaran Chaikin; titik awal dan akhir dipertahankan. */
    private static float[] chaikin(float[] p) {
        int m = p.length / 2;
        if (m < 3) return p;
        float[] o = new float[(2 * (m - 1) + 2) * 2];
        int j = 0;
        o[j++] = p[0];
        o[j++] = p[1];
        for (int i = 0; i < m - 1; i++) {
            float ax = p[i * 2], ay = p[i * 2 + 1], bx = p[i * 2 + 2], by = p[i * 2 + 3];
            if (i > 0) { // Q hanya bila bukan segmen pertama (supaya ujung tetap)
                o[j++] = 0.75f * ax + 0.25f * bx;
                o[j++] = 0.75f * ay + 0.25f * by;
            }
            if (i < m - 2) {
                o[j++] = 0.25f * ax + 0.75f * bx;
                o[j++] = 0.25f * ay + 0.75f * by;
            }
        }
        o[j++] = p[(m - 1) * 2];
        o[j++] = p[(m - 1) * 2 + 1];
        float[] r = new float[j];
        System.arraycopy(o, 0, r, 0, j);
        return r;
    }

    /** Tangan kanan: goresan mendatar dari kiri ke kanan, tegak dari atas ke bawah. Loop tertutup dibiarkan. */
    private static float[] orient(float[] s) {
        int m = s.length / 2;
        if (m < 2) return s;
        float dx = s[s.length - 2] - s[0], dy = s[s.length - 1] - s[1];
        if (Math.abs(dx) < 1f && Math.abs(dy) < 1f) return s; // loop tertutup / titik
        boolean flip = Math.abs(dx) >= Math.abs(dy) ? dx < 0 : dy < 0;
        return flip ? Tracer.reverse(s) : s;
    }

    private static float length(float[] s) {
        float len = 0f;
        for (int i = 2; i < s.length; i += 2) {
            len += (float) Math.hypot(s[i] - s[i - 2], s[i + 1] - s[i - 1]);
        }
        return len;
    }
}
