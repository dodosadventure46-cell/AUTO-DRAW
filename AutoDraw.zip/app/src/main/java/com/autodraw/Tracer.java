package com.autodraw;

import android.graphics.Bitmap;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;

/**
 * Mengubah gambar referensi menjadi goresan (polyline) dalam koordinat piksel lokal kotak.
 * Setiap goresan = float[] {x0,y0,x1,y1,...}. Satu titik = titik/tap.
 */
final class Tracer {
    private Tracer() {}

    // 8 tetangga searah jarum jam mulai dari atas
    private static final int[] DX = {0, 1, 1, 1, 0, -1, -1, -1};
    private static final int[] DY = {-1, -1, 0, 1, 1, 1, 0, -1};

    /**
     * Mask gelap pada grid cols x rows. Sebuah sel dianggap gelap bila >= 25% piksel
     * sumber di dalamnya lebih gelap dari threshold (garis tipis tidak hilang saat diperkecil).
     */
    static boolean[] mask(Bitmap ref, int cols, int rows, int thr) {
        final int sw = ref.getWidth(), sh = ref.getHeight();
        int[] px = new int[sw * sh];
        ref.getPixels(px, 0, sw, 0, 0, sw, sh);

        int[] cxMap = new int[sw];
        for (int x = 0; x < sw; x++) cxMap[x] = (int) ((long) x * cols / sw);

        int[] dark = new int[cols * rows];
        int[] total = new int[cols * rows];
        for (int y = 0; y < sh; y++) {
            int rowBase = (int) ((long) y * rows / sh) * cols;
            int off = y * sw;
            for (int x = 0; x < sw; x++) {
                int p = px[off + x];
                int a = p >>> 24;
                int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
                float lum = 0.299f * r + 0.587f * g + 0.114f * b;
                float v = lum * a / 255f + 255f * (1f - a / 255f); // komposit di atas putih
                int idx = rowBase + cxMap[x];
                total[idx]++;
                if (v < thr) dark[idx]++;
            }
        }
        boolean[] m = new boolean[cols * rows];
        for (int i = 0; i < m.length; i++) {
            m[i] = total[i] > 0 && dark[i] * 4 >= total[i];
        }
        return m;
    }

    static ArrayList<float[]> trace(Bitmap ref, int boxW, int boxH, int mode, int grid,
                                    int thr, int brushPx, boolean fillThick) {
        grid = Math.max(2, grid);
        int cols = Math.max(2, boxW / grid);
        int rows = Math.max(2, boxH / grid);
        // batasi jumlah sel supaya tidak terlalu berat
        while ((long) cols * rows > 250000L) {
            grid++;
            cols = Math.max(2, boxW / grid);
            rows = Math.max(2, boxH / grid);
        }
        final float cw = (float) boxW / cols, ch = (float) boxH / rows;
        boolean[] m = mask(ref, cols, rows, thr);

        ArrayList<float[]> out = new ArrayList<>();
        if (mode == Cfg.MODE_SCAN) {
            scanRows(m, cols, rows, cw, ch, out);
            return out;
        }
        contour(m, cols, rows, cw, ch, brushPx, fillThick, boxW, boxH, out);
        return order(out);
    }

    // ------------------------------------------------------------------ pemindaian baris

    private static void scanRows(boolean[] m, int cols, int rows, float cw, float ch,
                                 ArrayList<float[]> out) {
        for (int r = 0; r < rows; r++) {
            ArrayList<float[]> runs = new ArrayList<>();
            float y = (r + 0.5f) * ch;
            int c = 0;
            while (c < cols) {
                if (!m[r * cols + c]) { c++; continue; }
                int s = c;
                while (c < cols && m[r * cols + c]) c++;
                int e = c - 1;
                if (s == e) runs.add(new float[]{(s + 0.5f) * cw, y});
                else runs.add(new float[]{(s + 0.5f) * cw, y, (e + 0.5f) * cw, y});
            }
            if ((r & 1) == 1) { // zig-zag supaya perpindahan jari pendek
                Collections.reverse(runs);
                for (int i = 0; i < runs.size(); i++) runs.set(i, reverse(runs.get(i)));
            }
            out.addAll(runs);
        }
    }

    // ------------------------------------------------------------------ kontur

    private static void contour(boolean[] m, int cols, int rows, float cw, float ch, int brushPx,
                                boolean fillThick, int boxW, int boxH, ArrayList<float[]> out) {
        boolean[] remaining = m;

        if (fillThick) {
            int k = Math.round(brushPx / 2f / Math.max(cw, ch));
            if (k >= 1) {
                boolean[] core = erode(m, cols, rows, k);
                boolean any = false;
                for (boolean b : core) { if (b) { any = true; break; } }
                if (any) {
                    int step = Math.max(1, Math.round(brushPx / ch));
                    int dir = 0;
                    for (int r = 0; r < rows; r += step) {
                        ArrayList<float[]> runs = new ArrayList<>();
                        float y = (r + 0.5f) * ch;
                        int c = 0;
                        while (c < cols) {
                            if (!core[r * cols + c]) { c++; continue; }
                            int s = c;
                            while (c < cols && core[r * cols + c]) c++;
                            int e = c - 1;
                            float x0 = Math.max(0f, (s + 0.5f - k) * cw);
                            float x1 = Math.min(boxW, (e + 0.5f + k) * cw);
                            runs.add(new float[]{x0, y, x1, y});
                        }
                        if ((dir++ & 1) == 1) {
                            Collections.reverse(runs);
                            for (int i = 0; i < runs.size(); i++) runs.set(i, reverse(runs.get(i)));
                        }
                        out.addAll(runs);
                    }
                    // bagian yang sudah tertutup isi tidak perlu di-skeleton lagi
                    boolean[] covered = dilate(core, cols, rows, k);
                    remaining = new boolean[m.length];
                    for (int i = 0; i < m.length; i++) remaining[i] = m[i] && !covered[i];
                }
            }
        }

        // skeleton pada grid ber-padding 1 sel
        final int W = cols + 2, H = rows + 2;
        boolean[] g = new boolean[W * H];
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                g[(r + 1) * W + (c + 1)] = remaining[r * cols + c];
            }
        }
        thin(g, W, H);
        skeletonStrokes(g, W, H, cw, ch, out);
    }

    private static boolean[] erode(boolean[] m, int w, int h, int k) {
        boolean[] t = new boolean[m.length];
        boolean[] o = new boolean[m.length];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                boolean all = true;
                for (int dx = -k; dx <= k && all; dx++) {
                    int xx = x + dx;
                    if (xx < 0 || xx >= w) continue; // di luar kotak dianggap gelap
                    if (!m[y * w + xx]) all = false;
                }
                t[y * w + x] = all;
            }
        }
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                boolean all = true;
                for (int dy = -k; dy <= k && all; dy++) {
                    int yy = y + dy;
                    if (yy < 0 || yy >= h) continue;
                    if (!t[yy * w + x]) all = false;
                }
                o[y * w + x] = all;
            }
        }
        return o;
    }

    private static boolean[] dilate(boolean[] m, int w, int h, int k) {
        boolean[] t = new boolean[m.length];
        boolean[] o = new boolean[m.length];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                boolean any = false;
                for (int dx = -k; dx <= k && !any; dx++) {
                    int xx = x + dx;
                    if (xx >= 0 && xx < w && m[y * w + xx]) any = true;
                }
                t[y * w + x] = any;
            }
        }
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                boolean any = false;
                for (int dy = -k; dy <= k && !any; dy++) {
                    int yy = y + dy;
                    if (yy >= 0 && yy < h && t[yy * w + x]) any = true;
                }
                o[y * w + x] = any;
            }
        }
        return o;
    }

    /** Zhang-Suen thinning. Tepi grid (padding) harus false. */
    private static void thin(boolean[] g, int w, int h) {
        int[] del = new int[g.length];
        boolean changed = true;
        while (changed) {
            changed = false;
            for (int pass = 0; pass < 2; pass++) {
                int n = 0;
                for (int y = 1; y < h - 1; y++) {
                    for (int x = 1; x < w - 1; x++) {
                        int i = y * w + x;
                        if (!g[i]) continue;
                        boolean p2 = g[i - w], p3 = g[i - w + 1], p4 = g[i + 1], p5 = g[i + w + 1];
                        boolean p6 = g[i + w], p7 = g[i + w - 1], p8 = g[i - 1], p9 = g[i - w - 1];
                        int b = (p2 ? 1 : 0) + (p3 ? 1 : 0) + (p4 ? 1 : 0) + (p5 ? 1 : 0)
                                + (p6 ? 1 : 0) + (p7 ? 1 : 0) + (p8 ? 1 : 0) + (p9 ? 1 : 0);
                        if (b < 2 || b > 6) continue;
                        int a = 0;
                        if (!p2 && p3) a++;
                        if (!p3 && p4) a++;
                        if (!p4 && p5) a++;
                        if (!p5 && p6) a++;
                        if (!p6 && p7) a++;
                        if (!p7 && p8) a++;
                        if (!p8 && p9) a++;
                        if (!p9 && p2) a++;
                        if (a != 1) continue;
                        if (pass == 0) {
                            if (p2 && p4 && p6) continue;
                            if (p4 && p6 && p8) continue;
                        } else {
                            if (p2 && p4 && p8) continue;
                            if (p2 && p6 && p8) continue;
                        }
                        del[n++] = i;
                    }
                }
                for (int j = 0; j < n; j++) g[del[j]] = false;
                if (n > 0) changed = true;
            }
        }
    }

    private static int nbrMask(boolean[] g, int w, int idx) {
        int m = 0;
        for (int d = 0; d < 8; d++) {
            if (g[idx + DY[d] * w + DX[d]]) m |= (1 << d);
        }
        return m;
    }

    /** 0=terpencil, 1=ujung, 2=biasa, 3=percabangan. */
    private static byte[] classify(boolean[] g, int w, int h) {
        byte[] type = new byte[g.length];
        for (int y = 1; y < h - 1; y++) {
            for (int x = 1; x < w - 1; x++) {
                int i = y * w + x;
                if (!g[i]) continue;
                int mk = nbrMask(g, w, i);
                int cnt = Integer.bitCount(mk);
                if (cnt == 0) { type[i] = 0; continue; }
                if (cnt == 1) { type[i] = 1; continue; }
                int a = 0;
                for (int d = 0; d < 8; d++) {
                    boolean cur = (mk & (1 << d)) != 0;
                    boolean nxt = (mk & (1 << ((d + 1) & 7))) != 0;
                    if (!cur && nxt) a++;
                }
                type[i] = (byte) (a >= 3 ? 3 : 2);
            }
        }
        return type;
    }

    private static int pickNext(boolean[] g, boolean[] vis, int w, int cur, int prev) {
        int best = -1;
        int px = prev < 0 ? -100 : prev % w, py = prev < 0 ? -100 : prev / w;
        for (int d = 0; d < 8; d++) {
            int n = cur + DY[d] * w + DX[d];
            if (!g[n] || n == prev || vis[n]) continue;
            int nx = n % w, ny = n / w;
            boolean adjPrev = Math.max(Math.abs(nx - px), Math.abs(ny - py)) <= 1;
            if (!adjPrev) return n;      // utamakan tetangga yang bukan "sudut tangga"
            if (best < 0) best = n;
        }
        return best;
    }

    private static void skeletonStrokes(boolean[] g, int w, int h, float cw, float ch,
                                        ArrayList<float[]> out) {
        byte[] type = classify(g, w, h);
        boolean[] vis = new boolean[g.length];
        int[] path = new int[g.length + 2];
        final float eps = Math.min(0.7f * Math.max(cw, ch), 2.5f);

        // 1) jalan dari ujung & percabangan
        for (int idx = 0; idx < g.length; idx++) {
            if (!g[idx]) continue;
            byte t = type[idx];
            if (t == 0) {
                out.add(new float[]{((idx % w) - 0.5f) * cw, ((idx / w) - 0.5f) * ch});
                continue;
            }
            if (t != 1 && t != 3) continue;
            for (int d = 0; d < 8; d++) {
                int n = idx + DY[d] * w + DX[d];
                if (!g[n]) continue;
                boolean nSpecial = type[n] == 1 || type[n] == 3;
                if (nSpecial) {
                    // dua ujung yang saling menempel = satu goresan pendek utuh
                    if (t == 1 && type[n] == 1 && idx < n) {
                        emit(new int[]{idx, n}, 2, w, cw, ch, eps, out);
                    }
                    continue;
                }
                if (vis[n]) continue;
                int len = 0;
                path[len++] = idx;
                int prev = idx, cur = n;
                while (len < path.length - 1) {
                    path[len++] = cur;
                    if (type[cur] == 1 || type[cur] == 3) break;
                    vis[cur] = true;
                    int nxt = pickNext(g, vis, w, cur, prev);
                    if (nxt < 0) break;
                    prev = cur;
                    cur = nxt;
                }
                emit(path, len, w, cw, ch, eps, out);
            }
        }

        // 2) loop tertutup yang tidak punya ujung/percabangan
        for (int idx = 0; idx < g.length; idx++) {
            if (!g[idx] || vis[idx] || type[idx] != 2) continue;
            boolean skip = false;
            for (int d = 0; d < 8 && !skip; d++) {
                int n = idx + DY[d] * w + DX[d];
                if (g[n] && (vis[n] || type[n] == 1 || type[n] == 3)) skip = true;
            }
            if (skip) continue;
            int len = 0;
            path[len++] = idx;
            vis[idx] = true;
            int prev = idx;
            int cur = pickNext(g, vis, w, idx, -1);
            while (cur >= 0 && len < path.length - 2) {
                path[len++] = cur;
                vis[cur] = true;
                int nxt = pickNext(g, vis, w, cur, prev);
                prev = cur;
                cur = nxt;
            }
            int lx = path[len - 1] % w, ly = path[len - 1] / w;
            if (len > 2 && Math.max(Math.abs(lx - idx % w), Math.abs(ly - idx / w)) <= 1) {
                path[len++] = idx; // tutup loop
            }
            emit(path, len, w, cw, ch, eps, out);
        }
    }

    private static void emit(int[] path, int len, int w, float cw, float ch, float eps,
                             ArrayList<float[]> out) {
        float[] pts = new float[len * 2];
        for (int i = 0; i < len; i++) {
            pts[i * 2] = ((path[i] % w) - 0.5f) * cw;
            pts[i * 2 + 1] = ((path[i] / w) - 0.5f) * ch;
        }
        out.add(simplify(pts, eps));
    }

    // ------------------------------------------------------------------ util

    /** Douglas-Peucker iteratif. */
    private static float[] simplify(float[] pts, float eps) {
        int n = pts.length / 2;
        if (n <= 2) return pts;
        boolean[] keep = new boolean[n];
        keep[0] = true;
        keep[n - 1] = true;
        ArrayDeque<int[]> st = new ArrayDeque<>();
        st.push(new int[]{0, n - 1});
        while (!st.isEmpty()) {
            int[] s = st.pop();
            int a = s[0], b = s[1];
            if (b <= a + 1) continue;
            float ax = pts[a * 2], ay = pts[a * 2 + 1], bx = pts[b * 2], by = pts[b * 2 + 1];
            float dx = bx - ax, dy = by - ay;
            float len2 = dx * dx + dy * dy;
            float maxD = -1f;
            int mi = -1;
            for (int i = a + 1; i < b; i++) {
                float px = pts[i * 2], py = pts[i * 2 + 1];
                float d;
                if (len2 < 1e-6f) {
                    d = (float) Math.hypot(px - ax, py - ay);
                } else {
                    float tt = ((px - ax) * dx + (py - ay) * dy) / len2;
                    tt = Math.max(0f, Math.min(1f, tt));
                    d = (float) Math.hypot(px - (ax + tt * dx), py - (ay + tt * dy));
                }
                if (d > maxD) { maxD = d; mi = i; }
            }
            if (maxD > eps && mi > 0) {
                keep[mi] = true;
                st.push(new int[]{a, mi});
                st.push(new int[]{mi, b});
            }
        }
        int cnt = 0;
        for (boolean k : keep) if (k) cnt++;
        float[] res = new float[cnt * 2];
        int j = 0;
        for (int i = 0; i < n; i++) {
            if (keep[i]) {
                res[j++] = pts[i * 2];
                res[j++] = pts[i * 2 + 1];
            }
        }
        return res;
    }

    static float[] reverse(float[] s) {
        int n = s.length / 2;
        float[] r = new float[s.length];
        for (int i = 0; i < n; i++) {
            r[i * 2] = s[(n - 1 - i) * 2];
            r[i * 2 + 1] = s[(n - 1 - i) * 2 + 1];
        }
        return r;
    }

    /** Urutan goresan: tetangga terdekat (lewati bila terlalu banyak goresan). */
    private static ArrayList<float[]> order(ArrayList<float[]> in) {
        int n = in.size();
        if (n < 3 || n > 4000) return in;
        boolean[] used = new boolean[n];
        ArrayList<float[]> out = new ArrayList<>(n);
        float cx = 0f, cy = 0f;
        for (int step = 0; step < n; step++) {
            int best = -1;
            boolean flip = false;
            float bd = Float.MAX_VALUE;
            for (int i = 0; i < n; i++) {
                if (used[i]) continue;
                float[] s = in.get(i);
                int L = s.length;
                float dx = s[0] - cx, dy = s[1] - cy;
                float d1 = dx * dx + dy * dy;
                float ex = s[L - 2] - cx, ey = s[L - 1] - cy;
                float d2 = ex * ex + ey * ey;
                if (d1 < bd) { bd = d1; best = i; flip = false; }
                if (d2 < bd) { bd = d2; best = i; flip = true; }
            }
            used[best] = true;
            float[] s = in.get(best);
            if (flip) s = reverse(s);
            out.add(s);
            cx = s[s.length - 2];
            cy = s[s.length - 1];
        }
        return out;
    }
}
