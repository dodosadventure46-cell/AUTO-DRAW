package com.autodraw;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** Panel pengaturan yang dipakai di MainActivity (compact=false) dan panel melayang (compact=true). */
final class SettingsUi {
    private SettingsUi() {}

    static LinearLayout build(final Context c, final boolean compact) {
        final LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);

        // ---------------- Mode menggambar
        root.addView(title(c, "Mode menggambar"));
        if (!compact) root.addView(hint(c, "Pilih cara AutoDraw menggambar."));

        final String[] names = {"Kontur", "Pemindaian baris", "Dua jari"};
        final String[] hints = {
                "Garis tengah presisi + isi area tebal. Lebih cepat dan akurat.",
                "Pemindaian baris. Paling setia ke area hitam, lebih lambat.",
                "Atas dan bawah bersamaan. Eksperimen, bisa memicu zoom."
        };
        final LinearLayout[] rows = new LinearLayout[3];
        final Runnable refresh = new Runnable() {
            @Override public void run() {
                int m = Cfg.mode();
                for (int i = 0; i < 3; i++) {
                    rows[i].setBackground(Ui.round(i == m ? 0x557C5CFF : 0x22FFFFFF, Ui.dp(c, 10)));
                }
            }
        };
        for (int i = 0; i < 3; i++) {
            final int mi = i;
            LinearLayout r = new LinearLayout(c);
            r.setOrientation(LinearLayout.VERTICAL);
            int p = Ui.dp(c, 10);
            r.setPadding(p, p, p, p);
            r.addView(Ui.text(c, names[i], 14, Ui.TEXT, true));
            if (!compact) r.addView(hint(c, hints[i]));
            r.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Cfg.puti("mode", mi);
                    refresh.run();
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = Ui.dp(c, 6);
            rows[i] = r;
            root.addView(r, lp);
        }
        refresh.run();

        // ---------------- Penyesuaian
        root.addView(title(c, "Penyesuaian"));
        seek(c, root, "Ukuran grid (tingkat detail)", " px", "grid", 2, 24, 8,
                "Makin kecil makin detail dan akurat, tapi makin lama.", compact);
        seek(c, root, "Batas gelap", "", "thr", 20, 235, 110,
                "Makin besar, makin banyak warna abu-abu dihitung sebagai garis hitam.", compact);
        seek(c, root, "Kecepatan menggambar", "", "speed", 1, 10, 5,
                "Kecil = lambat tapi aman. Besar = cepat, tapi aplikasi gambar bisa melewatkan goresan.", compact);
        seek(c, root, "Tebal kuas di aplikasi gambar", " px", "brush", 1, 40, 6,
                "Samakan dengan ukuran kuas di aplikasi gambar (piksel layar). Dipakai Kontur untuk mengisi area tebal.", compact);
        toggle(c, root, "Isi area hitam tebal", "fill", true,
                "Berlaku untuk Kontur dan Dua jari. Matikan jika gambarmu hanya garis tipis.", compact, null);
        toggle(c, root, "Animasi pemindaian", "anim", true,
                "Garis pemindai menyapu kotak, kotak-kotak kecil muncul mengikuti garis, lalu memudar dan menggambar dimulai. Menambah sekitar 2 detik.",
                compact, null);
        toggle(c, root, "Cegah zoom kanvas (Dua jari)", "nozoom", true,
                "Jangan ubah zoom kanvas saat menggambar.", compact, null);

        // ---------------- Layar mengambang (hanya di aplikasi, bukan di panel melayang)
        if (!compact) {
            root.addView(title(c, "Layar mengambang"));
            final TextView modeHint = hint(c, "");
            final Runnable upd = new Runnable() {
                @Override public void run() {
                    modeHint.setText(Cfg.overlayFull()
                            ? "Aktif: panel pengaturan lengkap melayang di atas aplikasi gambar. Praktis, tapi bisa menutupi kanvas (panel bisa digeser)."
                            : "Aktif: mode jangan ganggu. Layar hanya menampilkan kotak gambar dan tombol Mulai/Tutup kecil. Semua pengaturan diubah dari aplikasi ini.");
                }
            };
            toggle(c, root, "Letakkan pengaturan di layar mengambang", "ovfull", false, null, true,
                    new Runnable() {
                        @Override public void run() {
                            upd.run();
                            DrawService.cfgChanged();
                        }
                    });
            root.addView(modeHint);
            upd.run();

            // BARU: gambar referensi bisa dimasukkan saat layar mengambang tampil
            toggle(c, root, "Pilih gambar dari layar mengambang", "ovpick", false,
                    "Tambah tombol Gambar di layar mengambang, jadi gambar referensi bisa dimasukkan atau diganti tanpa kembali ke aplikasi ini.",
                    false, new Runnable() {
                        @Override public void run() { DrawService.cfgChanged(); }
                    });
        }
        return root;
    }

    // ------------------------------------------------------------------ komponen

    private static TextView title(Context c, String s) {
        TextView t = Ui.text(c, s, 16, Ui.ACCENT, true);
        t.setPadding(0, Ui.dp(c, 14), 0, Ui.dp(c, 6));
        return t;
    }

    private static TextView hint(Context c, String s) {
        TextView t = Ui.text(c, s, 12, Ui.MUTED, false);
        t.setPadding(0, Ui.dp(c, 2), 0, Ui.dp(c, 6));
        return t;
    }

    private static void seek(final Context c, LinearLayout parent, final String title,
                             final String unit, final String key, final int min, final int max,
                             final int def, String hintText, boolean compact) {
        final TextView label = Ui.text(c, "", 14, Ui.TEXT, false);
        label.setPadding(0, Ui.dp(c, 8), 0, 0);
        final SeekBar sb = new SeekBar(c);
        sb.setMax(max - min);
        int v = Math.max(min, Math.min(max, Cfg.geti(key, def)));
        sb.setProgress(v - min);
        label.setText(title + ": " + v + unit);
        sb.setProgressTintList(ColorStateList.valueOf(Ui.ACCENT));
        sb.setThumbTintList(ColorStateList.valueOf(Ui.ACCENT));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                int val = p + min;
                label.setText(title + ": " + val + unit);
                if (fromUser) Cfg.puti(key, val);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        parent.addView(label);
        parent.addView(sb);
        if (!compact && hintText != null) parent.addView(hint(c, hintText));
    }

    private static void toggle(Context c, LinearLayout parent, String title, final String key,
                               boolean def, String hintText, boolean compact, final Runnable onChange) {
        Switch s = new Switch(c);
        s.setText(title);
        s.setTextSize(14);
        s.setTextColor(Ui.TEXT);
        s.setPadding(0, Ui.dp(c, 8), 0, Ui.dp(c, 4));
        s.setChecked(Cfg.getb(key, def));
        s.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                Cfg.putb(key, on);
                if (onChange != null) onChange.run();
            }
        });
        parent.addView(s);
        if (!compact && hintText != null) parent.addView(hint(c, hintText));
    }
}
