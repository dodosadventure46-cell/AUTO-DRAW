package com.autodraw;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/**
 * Bagian-bagian panel pengaturan. MainActivity menyusunnya menjadi kartu,
 * sedangkan panel melayang memakai build() (versi ringkas).
 */
final class SettingsUi {
    private SettingsUi() {}

    /** Urutan tampil mode (nilai = konstanta Cfg.MODE_*). */
    private static final int[] ORDER = {Cfg.MODE_CONTOUR, Cfg.MODE_HUMAN, Cfg.MODE_SCAN, Cfg.MODE_TWO};

    /** Panel ringkas untuk layar mengambang. */
    static LinearLayout build(final Context c) {
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.addView(title(c, "Tampilan kotak"));
        root.addView(viewSeg(c, true), matchW());
        root.addView(title(c, "Mode menggambar"));
        root.addView(modeSection(c, true));
        root.addView(title(c, "Penyesuaian"));
        root.addView(tuneSection(c, true));
        return root;
    }

    // ------------------------------------------------------------------ tampilan kotak

    /** Pilihan tampilan isi kotak: gambar penuh atau hanya garis hitam yang terdeteksi. */
    static Ui.Seg viewSeg(final Context c, boolean compact) {
        Ui.Seg seg = new Ui.Seg(c, new String[]{"Gambar penuh", "Garis hitam"}, false,
                new Ui.Seg.OnPick() {
                    @Override public void pick(int i) {
                        Cfg.puti("viewmode", i == 1 ? Cfg.VIEW_LINES : Cfg.VIEW_FULL);
                    }
                });
        seg.select(Cfg.viewMode());
        return seg;
    }

    // ------------------------------------------------------------------ mode menggambar

    static LinearLayout modeSection(final Context c, final boolean compact) {
        final LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);

        final String[] names = new String[4];
        final String[] hints = new String[4];
        names[Cfg.MODE_CONTOUR] = "Kontur";
        hints[Cfg.MODE_CONTOUR] = "Garis tengah presisi + isi area tebal. Cepat dan akurat.";
        names[Cfg.MODE_HUMAN] = "Manusiawi";
        hints[Cfg.MODE_HUMAN] = "Goresan sedikit bergetar dan melengkung, kecepatan berbeda-beda, ada jeda singkat. Terlihat digambar tangan.";
        names[Cfg.MODE_SCAN] = "Pemindaian baris";
        hints[Cfg.MODE_SCAN] = "Paling setia ke area hitam, tapi lebih lambat.";
        names[Cfg.MODE_TWO] = "Dua jari";
        hints[Cfg.MODE_TWO] = "Atas dan bawah bersamaan. Eksperimen, bisa memicu zoom.";

        final LinearLayout[] rows = new LinearLayout[4];
        final View[] dots = new View[4];
        final int r10 = Ui.dp(c, 12);

        // slider tingkat gaya tangan: hanya tampil saat mode Manusiawi dipilih
        final LinearLayout humanBox = new LinearLayout(c);
        humanBox.setOrientation(LinearLayout.VERTICAL);
        seek(c, humanBox, "Tingkat gaya tangan", "", "human", 1, 10, 5,
                "Kecil = rapi dan cepat. Besar = lebih goyang, lebih banyak jeda, lebih lambat.", compact);

        final Runnable refresh = new Runnable() {
            @Override public void run() {
                int m = Cfg.mode();
                for (int k = 0; k < ORDER.length; k++) {
                    boolean on = ORDER[k] == m;
                    rows[k].setBackground(Ui.stroke(on ? Ui.ACCENT_SOFT : Ui.INSET,
                            on ? Ui.ACCENT : Ui.LINE, r10, Ui.dp(c, on ? 2 : 1)));
                    GradientDrawable d = new GradientDrawable();
                    d.setShape(GradientDrawable.OVAL);
                    d.setColor(on ? Ui.ACCENT : 0x00000000);
                    d.setStroke(Ui.dp(c, 2), on ? 0xFFFFFFFF : Ui.MUTED);
                    dots[k].setBackground(d);
                }
                humanBox.setVisibility(m == Cfg.MODE_HUMAN ? View.VISIBLE : View.GONE);
            }
        };

        for (int k = 0; k < ORDER.length; k++) {
            final int mode = ORDER[k];
            LinearLayout r = new LinearLayout(c);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            int p = Ui.dp(c, 12);
            r.setPadding(p, p, p, p);

            View dot = new View(c);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(Ui.dp(c, 20), Ui.dp(c, 20));
            dlp.rightMargin = Ui.dp(c, 12);
            r.addView(dot, dlp);
            dots[k] = dot;

            LinearLayout col = new LinearLayout(c);
            col.setOrientation(LinearLayout.VERTICAL);
            LinearLayout head = new LinearLayout(c);
            head.setOrientation(LinearLayout.HORIZONTAL);
            head.setGravity(Gravity.CENTER_VERTICAL);
            head.addView(Ui.text(c, names[mode], 15, Ui.TEXT, true));
            if (mode == Cfg.MODE_HUMAN) {
                TextView chip = Ui.chip(c, "BARU", Ui.ACCENT, 0xFFFFFFFF);
                LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-2, -2);
                clp.leftMargin = Ui.dp(c, 8);
                head.addView(chip, clp);
            }
            col.addView(head);
            if (!compact) {
                TextView h = Ui.hint(c, hints[mode]);
                h.setPadding(0, Ui.dp(c, 3), 0, 0);
                col.addView(h);
            }
            r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));

            r.setClickable(true);
            r.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Cfg.puti("mode", mode);
                    refresh.run();
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.bottomMargin = Ui.dp(c, 8);
            rows[k] = r;
            root.addView(r, lp);
        }
        root.addView(humanBox);
        refresh.run();
        return root;
    }

    // ------------------------------------------------------------------ penyesuaian

    static LinearLayout tuneSection(Context c, boolean compact) {
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        seek(c, root, "Ukuran grid (detail)", " px", "grid", 2, 24, 8,
                "Makin kecil makin detail dan akurat, tapi makin lama.", compact);
        seek(c, root, "Batas gelap", "", "thr", 20, 235, 110,
                "Makin besar, makin banyak warna abu-abu dihitung sebagai garis hitam. Cek hasilnya lewat tampilan Garis hitam.", compact);
        seek(c, root, "Kecepatan menggambar", "", "speed", 1, 10, 5,
                "Kecil = lambat tapi aman. Besar = cepat, tapi aplikasi gambar bisa melewatkan goresan.", compact);
        seek(c, root, "Tebal kuas", " px", "brush", 1, 40, 6,
                "Samakan dengan ukuran kuas di aplikasi gambar (piksel layar). Dipakai untuk mengisi area tebal.", compact);
        toggle(c, root, "Isi area hitam tebal", "fill", true,
                "Berlaku untuk Kontur, Manusiawi, dan Dua jari. Matikan jika gambarmu hanya garis tipis.", compact, null);
        toggle(c, root, "Animasi pemindaian", "anim", true,
                "Garis pemindai menyapu kotak sebelum menggambar. Menambah sekitar 2 detik.", compact, null);
        toggle(c, root, "Cegah zoom kanvas (Dua jari)", "nozoom", true,
                "Jangan ubah zoom kanvas saat menggambar.", compact, null);
        return root;
    }

    // ------------------------------------------------------------------ layar mengambang

    static LinearLayout overlaySection(Context c) {
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);

        final TextView modeHint = toggle(c, root, "Pengaturan di layar mengambang", "ovfull", false,
                "", false, new Runnable() {
                    @Override public void run() { DrawService.cfgChanged(); }
                });
        final Runnable upd = new Runnable() {
            @Override public void run() {
                modeHint.setText(Cfg.overlayFull()
                        ? "Panel pengaturan lengkap melayang di atas aplikasi gambar. Praktis, tapi bisa menutupi kanvas (panel bisa digeser)."
                        : "Mode jangan ganggu: hanya kotak gambar dan tombol kecil. Semua pengaturan diubah dari aplikasi ini.");
            }
        };
        upd.run();
        // perbarui keterangan saat saklar diubah
        Cfg.addSettingsListener(new Cfg.SettingsListener() {
            @Override public void onSetting(String key) { if ("ovfull".equals(key)) upd.run(); }
        });

        toggle(c, root, "Pilih gambar dari layar mengambang", "ovpick", false,
                "Tambah tombol Gambar dan URL di layar mengambang, jadi gambar referensi bisa diganti tanpa kembali ke aplikasi ini.",
                false, new Runnable() {
                    @Override public void run() { DrawService.cfgChanged(); }
                });
        return root;
    }

    // ------------------------------------------------------------------ komponen

    private static LinearLayout.LayoutParams matchW() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private static TextView title(Context c, String s) {
        TextView t = Ui.text(c, s, 14, Ui.ACCENT, true);
        t.setPadding(0, Ui.dp(c, 14), 0, Ui.dp(c, 6));
        return t;
    }

    private static void seek(final Context c, LinearLayout parent, final String title,
                             final String unit, final String key, final int min, final int max,
                             final int def, String hintText, boolean compact) {
        LinearLayout head = new LinearLayout(c);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(0, Ui.dp(c, 10), 0, 0);
        TextView label = Ui.text(c, title, 14, Ui.TEXT, false);
        head.addView(label, new LinearLayout.LayoutParams(0, -2, 1f));
        final TextView val = Ui.text(c, "", 13, Ui.TEXT, true);
        val.setGravity(Gravity.CENTER);
        val.setPadding(Ui.dp(c, 10), Ui.dp(c, 3), Ui.dp(c, 10), Ui.dp(c, 3));
        val.setBackground(Ui.round(Ui.ACCENT_SOFT, Ui.dp(c, 20)));
        head.addView(val);
        parent.addView(head);

        final SeekBar sb = new SeekBar(c);
        sb.setMax(max - min);
        int v = Math.max(min, Math.min(max, Cfg.geti(key, def)));
        sb.setProgress(v - min);
        val.setText(v + unit);
        sb.setProgressTintList(ColorStateList.valueOf(Ui.ACCENT));
        sb.setThumbTintList(ColorStateList.valueOf(Ui.ACCENT));
        sb.setProgressBackgroundTintList(ColorStateList.valueOf(0xFF4A4D78));
        sb.setPadding(Ui.dp(c, 4), Ui.dp(c, 8), Ui.dp(c, 4), Ui.dp(c, 8));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                int value = p + min;
                val.setText(value + unit);
                if (fromUser) Cfg.puti(key, value);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        parent.addView(sb, matchW());
        if (!compact && hintText != null) parent.addView(Ui.hint(c, hintText));
    }

    /** Baris saklar: judul + keterangan di kiri, saklar di kanan. Mengembalikan TextView keterangan (bisa null). */
    private static TextView toggle(Context c, LinearLayout parent, String title, final String key,
                                   boolean def, String hintText, boolean compact, final Runnable onChange) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, Ui.dp(c, 8), 0, Ui.dp(c, 8));

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(Ui.text(c, title, 14, Ui.TEXT, false));
        TextView h = null;
        if (!compact && hintText != null) {
            h = Ui.hint(c, hintText);
            h.setPadding(0, Ui.dp(c, 2), 0, 0);
            col.addView(h);
        }
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, -2, 1f);
        clp.rightMargin = Ui.dp(c, 12);
        row.addView(col, clp);

        final Switch s = new Switch(c);
        Ui.styleSwitch(s);
        s.setChecked(Cfg.getb(key, def));
        s.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(android.widget.CompoundButton b, boolean on) {
                Cfg.putb(key, on);
                if (onChange != null) onChange.run();
            }
        });
        row.addView(s);
        row.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { s.toggle(); }
        });
        parent.addView(row, matchW());
        return h;
    }
}
