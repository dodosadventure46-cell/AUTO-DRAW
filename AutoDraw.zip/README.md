# AutoDraw

Auto-gambar line art di aplikasi gambar apa pun. Dibuat oleh @dodosadventure.

Layar mengambang berisi kotak gambar yang bisa digeser dan diubah ukurannya. AutoDraw lalu
menggambar sendiri di atas kanvas aplikasi gambar lewat Accessibility Service.

## Yang baru di versi 2.3.0

1. **Mode menggambar "Manusiawi"** (khusus lineart): potongan garis disambung jadi goresan panjang yang mengalir, dihaluskan jadi kurva, bentuk besar digambar dulu baru detail, kecepatan berubah di tiap bagian goresan (pelan di awal, akhir, dan tikungan), jeda antar goresan, ujung kadang melewati batas. Tanpa isi bolak-balik. Slider **Tingkat gaya tangan** (1-10).
2. **Gambar dari URL**: tombol **Dari URL** di aplikasi, dan tombol **URL** di layar mengambang
   (aktifkan "Pilih gambar dari layar mengambang"). Mendukung http/https, redirect, dan memberi
   pesan error yang jelas (link halaman web, 404, timeout, format tidak didukung). Memerlukan izin
   INTERNET.
3. **Tampilan kotak: Gambar penuh / Garis hitam**. Di kotak gambar ada pilihan **Penuh | Garis**
   (juga di aplikasi dan panel pengaturan). Mode Garis menampilkan persis bagian gelap yang akan
   digambar (memakai mask dan grid yang sama dengan proses menggambar), ikut berubah saat
   *Batas gelap*, *Ukuran grid*, atau ukuran kotak diubah. Jadi hasilnya bisa dicek sebelum Mulai.
4. **UI dirapikan**: tombol utama tetap di bawah, kartu per bagian, status izin berupa pill,
   pilihan mode dengan radio, slider dengan nilai di kanan, saklar rapi, efek ripple, dan
   pratinjau gambar di aplikasi yang ikut tampilan Garis hitam.

Catatan mode Manusiawi: Android mengirim tiap goresan dengan kecepatan tetap sepanjang goresan,
jadi variasi kecepatan terjadi antar goresan (bukan di dalam satu goresan).

## Build lewat GitHub

1. Upload seluruh isi folder ini ke repo (folder `.github` harus ikut).
2. Buka tab **Actions** > workflow **Build APK** (otomatis jalan setiap push, atau tekan *Run workflow*).
3. Setelah hijau, unduh artifact **AutoDraw-debug-apk**.

Catatan: APK debug ditandatangani dengan key acak milik runner GitHub, jadi tiap build bisa
berbeda tanda tangan. Kalau pemasangan sebagai update gagal, uninstall versi lama dulu.

## Struktur

- `DrawService`   : layar mengambang, tombol pilih gambar / URL, tampilan kotak, scan, kirim gesture
- `Tracer`        : gambar -> goresan (Kontur / Pemindaian baris) + pratinjau garis hitam
- `Human`         : gaya tangan untuk mode Manusiawi (haluskan, getar, kecepatan, jeda)
- `ScanView`      : animasi pemindaian
- `SettingsUi`    : panel pengaturan (dipakai di aplikasi dan di panel melayang)
- `PickActivity`  : pemilih gambar transparan + kartu input URL
- `MainActivity`, `Cfg` (pengaturan + unduh gambar), `Ui`
