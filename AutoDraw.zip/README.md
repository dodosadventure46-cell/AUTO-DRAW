# AutoDraw

Auto-gambar line art di aplikasi gambar apa pun. Dibuat oleh @dodosadventure.

Layar mengambang berisi kotak gambar yang bisa digeser dan diubah ukurannya. AutoDraw lalu
menggambar sendiri di atas kanvas aplikasi gambar lewat Accessibility Service.

## Yang baru di versi 2.2.0

1. **Pilih gambar dari layar mengambang** (bisa dihidup/matikan).
   Aplikasi > Pengaturan > Layar mengambang > "Pilih gambar dari layar mengambang".
   Kalau aktif, di layar mengambang muncul tombol **Gambar** untuk memasukkan atau mengganti
   gambar referensi tanpa kembali ke aplikasi AutoDraw.
2. **Animasi scan lebih smooth**: berbasis waktu (sinkron vsync), easing sinus, kotak muncul
   bertahap, tanpa alokasi per frame, dan jendela overlay kini memakai akselerasi GPU.

## Build lewat GitHub

1. Upload seluruh isi folder ini ke repo (folder `.github` harus ikut).
2. Buka tab **Actions** > workflow **Build APK** (otomatis jalan setiap push, atau tekan *Run workflow*).
3. Setelah hijau, unduh artifact **AutoDraw-debug-apk**.

Catatan: APK debug ditandatangani dengan key acak milik runner GitHub, jadi tiap build bisa
berbeda tanda tangan. Kalau pemasangan sebagai update gagal, uninstall versi lama dulu.

## Struktur

- `DrawService`   : layar mengambang, tombol pilih gambar, scan, kirim gesture
- `Tracer`        : gambar -> goresan (Kontur / Pemindaian baris)
- `ScanView`      : animasi pemindaian
- `SettingsUi`    : panel pengaturan (dipakai di aplikasi dan di panel melayang)
- `PickActivity`  : pemilih gambar transparan
- `MainActivity`, `Cfg`, `Ui`
