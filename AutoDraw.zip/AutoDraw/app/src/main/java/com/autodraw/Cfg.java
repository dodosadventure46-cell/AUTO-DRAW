package com.autodraw;

import android.content.Context;
import android.content.SharedPreferences;

/** Pengaturan bersama antara aplikasi dan layar mengambang (disimpan permanen). */
public class Cfg {
    static int mode = 0;      // 0 Klasik, 1 Kontur, 2 Dua Jari
    static int speed = 5;     // 1..10
    static int thr = 140;     // batas gelap 20..250
    static int step = 4;      // ukuran grid px 1..20
    static int brush = 3;     // tebal kuas px 1..30
    static boolean fill = true;
    static boolean floatCtl = false; // false = pengaturan di aplikasi (jangan ganggu), true = di layar mengambang

    static void load(Context c) {
        SharedPreferences p = c.getSharedPreferences("cfg", Context.MODE_PRIVATE);
        mode = p.getInt("mode", 0); speed = p.getInt("speed", 5); thr = p.getInt("thr", 140);
        step = p.getInt("step", 4); brush = p.getInt("brush", 3);
        fill = p.getBoolean("fill", true); floatCtl = p.getBoolean("floatCtl", false);
    }

    static void save(Context c) {
        c.getSharedPreferences("cfg", Context.MODE_PRIVATE).edit()
            .putInt("mode", mode).putInt("speed", speed).putInt("thr", thr)
            .putInt("step", step).putInt("brush", brush)
            .putBoolean("fill", fill).putBoolean("floatCtl", floatCtl).apply();
    }
}
