package com.autodraw;

import android.app.Activity;
import android.content.Intent;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    TextView status; ImageView prev;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    Button btn(String t, int c1, int c2, View.OnClickListener c) {
        Button b = new Button(this);
        b.setText(t); b.setAllCaps(false); b.setTextColor(0xFFFFFFFF); b.setTextSize(15);
        b.setTypeface(null, Typeface.BOLD);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c1, c2});
        g.setCornerRadius(dp(16)); b.setBackground(g); b.setOnClickListener(c);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(52)); p.topMargin = dp(12);
        b.setLayoutParams(p); return b;
    }

    LinearLayout card(String title, String desc, int accent) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable(); g.setColor(0x22FFFFFF); g.setCornerRadius(dp(22)); g.setStroke(dp(1), 0x44FFFFFF);
        c.setBackground(g); c.setPadding(dp(18), dp(16), dp(18), dp(18));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(14); c.setLayoutParams(p);
        TextView t = tv(title, 18, accent, true); c.addView(t);
        if (desc != null) { TextView d = tv(desc, 13, 0xFFC7D2FE, false); d.setPadding(0, dp(4), 0, 0); c.addView(d); }
        return c;
    }

    TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD); return t;
    }

    @Override protected void onCreate(Bundle sv) {
        super.onCreate(sv);
        getWindow().setStatusBarColor(0xFF1E1B4B); getWindow().setNavigationBarColor(0xFF0F172A);
        ScrollView sc = new ScrollView(this);
        sc.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF1E1B4B, 0xFF4C1D95, 0xFF0F172A}));
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(44), dp(20), dp(28)); sc.addView(l);

        TextView title = tv("🎨 AutoDraw", 38, 0xFFFFFFFF, true);
        title.getPaint().setShader(new LinearGradient(0, 0, dp(250), 0,
            new int[]{0xFFF472B6, 0xFFFBBF24, 0xFF34D399, 0xFF60A5FA}, null, Shader.TileMode.CLAMP));
        l.addView(title);
        TextView sub = tv("Gambar line art otomatis di layar aplikasi apa pun", 14, 0xFFC7D2FE, false);
        sub.setPadding(0, dp(2), 0, dp(8)); l.addView(sub);

        status = tv("", 14, 0xFFFFFFFF, true);
        GradientDrawable sg = new GradientDrawable(); sg.setColor(0x33000000); sg.setCornerRadius(dp(30));
        status.setBackground(sg); status.setPadding(dp(16), dp(8), dp(16), dp(8));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2); sp.topMargin = dp(8); status.setLayoutParams(sp);
        l.addView(status);

        LinearLayout c1 = card("① Izin Aksesibilitas", "Aktifkan AutoDraw agar bisa menyentuh layar untuk menggambar.", 0xFFF472B6);
        c1.addView(btn("⚙️  Buka Pengaturan Aksesibilitas", 0xFFEC4899, 0xFFF97316,
            v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        l.addView(c1);

        LinearLayout c2 = card("② Pilih Gambar", "Bagian hitam gambar akan dijadikan garis (line art).", 0xFF67E8F9);
        c2.addView(btn("🖼️  Pilih Gambar Referensi", 0xFF06B6D4, 0xFF3B82F6, v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT); i.setType("image/*"); startActivityForResult(i, 1);
        }));
        prev = new ImageView(this); prev.setScaleType(ImageView.ScaleType.FIT_CENTER); prev.setBackgroundColor(0xFFFFFFFF);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(150)); pp.topMargin = dp(12);
        prev.setLayoutParams(pp); prev.setVisibility(View.GONE); c2.addView(prev);
        l.addView(c2);

        LinearLayout c3 = card("③ Mulai Menggambar", "Kotak mengambang muncul di atas aplikasi mana pun.", 0xFF86EFAC);
        c3.addView(btn("🚀  Tampilkan Kotak Mengambang", 0xFF22C55E, 0xFF14B8A6, v -> {
            if (DrawService.inst == null) toast("Aktifkan dulu AutoDraw di Aksesibilitas");
            else if (DrawService.src == null) toast("Pilih gambar dulu");
            else { DrawService.inst.show(); toast("Buka aplikasi gambar, atur kotaknya, tekan ▶"); }
        }));
        l.addView(c3);

        LinearLayout c4 = card("💡 Tips & Tombol", null, 0xFFFDE68A);
        c4.addView(tv("▶ mulai   ✕ tutup   ■ STOP berhenti\nS+/S-  kecepatan\nT+/T-  ketebalan garis yang diambil\nD+/D-  tingkat detail\n◢ sudut kotak = resize, seret gambar = pindah\n\n" +
            "• Pakai kuas pensil kecil & warna hitam.\n• Jangan ubah zoom kanvas saat menggambar.\n" +
            "• Android 13+: jika aksesibilitas abu-abu, buka Info Aplikasi → ⋮ → Izinkan setelan terbatas.", 13, 0xFFE0E7FF, false));
        ((TextView) c4.getChildAt(0)).setPadding(0, 0, 0, dp(6));
        l.addView(c4);

        LinearLayout f = new LinearLayout(this); f.setOrientation(LinearLayout.VERTICAL); f.setGravity(Gravity.CENTER_HORIZONTAL);
        f.setPadding(0, dp(26), 0, 0);
        TextView a = tv("Dibuat dengan ❤️ oleh", 12, 0xFFA5B4FC, false);
        TextView b = tv("@dodosadventure", 20, 0xFFFFFFFF, true);
        b.getPaint().setShader(new LinearGradient(0, 0, dp(190), 0,
            new int[]{0xFFF472B6, 0xFFFBBF24, 0xFF34D399}, null, Shader.TileMode.CLAMP));
        f.addView(a); f.addView(b); l.addView(f);
        setContentView(sc);
    }

    @Override protected void onResume() {
        super.onResume();
        boolean on = DrawService.inst != null;
        status.setText(on ? "●  Aksesibilitas AKTIF" : "●  Aksesibilitas belum aktif");
        status.setTextColor(on ? 0xFF4ADE80 : 0xFFF87171);
        if (DrawService.src != null) { prev.setImageBitmap(DrawService.src); prev.setVisibility(View.VISIBLE); }
    }

    void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    @Override protected void onActivityResult(int rq, int rs, Intent d) {
        if (rq != 1 || rs != RESULT_OK || d == null) return;
        try {
            Uri u = d.getData();
            BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(getContentResolver().openInputStream(u), null, o);
            int s = 1; while (Math.max(o.outWidth, o.outHeight) / s > 2400) s *= 2;
            o = new BitmapFactory.Options(); o.inSampleSize = s;
            DrawService.src = BitmapFactory.decodeStream(getContentResolver().openInputStream(u), null, o);
            prev.setImageBitmap(DrawService.src); prev.setVisibility(View.VISIBLE);
            toast("Gambar dimuat ✅");
            if (DrawService.inst != null) DrawService.inst.refresh();
        } catch (Exception e) { toast("Gagal: " + e.getMessage()); }
    }
}
