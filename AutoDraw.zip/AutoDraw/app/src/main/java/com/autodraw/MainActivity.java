package com.autodraw;

import android.app.Activity;
import android.content.Intent;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.*;
import android.view.animation.DecelerateInterpolator;
import android.widget.*;

public class MainActivity extends Activity {
    TextView status; ImageView prev;
    LinearLayout[] mc = new LinearLayout[3]; TextView[] chk = new TextView[3];
    static final int[] ACC = {0xFF60A5FA, 0xFFF472B6, 0xFFFBBF24};

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    void press(View v) {
        v.setOnTouchListener((x, e) -> {
            int a = e.getAction();
            if (a == MotionEvent.ACTION_DOWN) x.animate().scaleX(.96f).scaleY(.96f).setDuration(80).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) x.animate().scaleX(1f).scaleY(1f).setDuration(140).start();
            return false;
        });
    }

    Button btn(String t, int c1, int c2, View.OnClickListener c) {
        Button b = new Button(this);
        b.setText(t); b.setAllCaps(false); b.setTextColor(0xFFFFFFFF); b.setTextSize(15);
        b.setTypeface(null, Typeface.BOLD);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c1, c2});
        g.setCornerRadius(dp(16)); b.setBackground(g); b.setOnClickListener(c); press(b);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(52)); p.topMargin = dp(12);
        b.setLayoutParams(p); return b;
    }

    LinearLayout card(String title, String desc, int accent) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable(); g.setColor(0x22FFFFFF); g.setCornerRadius(dp(22)); g.setStroke(dp(1), 0x44FFFFFF);
        c.setBackground(g); c.setPadding(dp(18), dp(16), dp(18), dp(18));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(14); c.setLayoutParams(p);
        c.addView(tv(title, 18, accent, true));
        if (desc != null) { TextView d = tv(desc, 13, 0xFFC7D2FE, false); d.setPadding(0, dp(4), 0, 0); c.addView(d); }
        return c;
    }

    TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD); return t;
    }

    LinearLayout modeRow(final int idx, String emoji, String name, String desc) {
        LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(10); r.setLayoutParams(p);
        TextView e = tv(emoji, 26, 0xFFFFFFFF, false); e.setPadding(0, 0, dp(12), 0); r.addView(e);
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL);
        col.addView(tv(name, 15, 0xFFFFFFFF, true));
        TextView d = tv(desc, 12, 0xFFC7D2FE, false); col.addView(d);
        r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView ck = tv("✓", 20, ACC[idx], true); ck.setAlpha(0f); r.addView(ck); chk[idx] = ck;
        r.setOnClickListener(v -> selectMode(idx, true)); press(r);
        mc[idx] = r; return r;
    }

    void selectMode(int m, boolean anim) {
        DrawService.mode = m;
        for (int i = 0; i < 3; i++) {
            GradientDrawable g = new GradientDrawable(); g.setCornerRadius(dp(16));
            if (i == m) { g.setColor(0x44FFFFFF); g.setStroke(dp(2), ACC[i]); } else { g.setColor(0x12FFFFFF); g.setStroke(dp(1), 0x33FFFFFF); }
            mc[i].setBackground(g);
            float a = i == m ? 1f : 0f;
            if (anim) chk[i].animate().alpha(a).setDuration(200).start(); else chk[i].setAlpha(a);
        }
        if (DrawService.inst != null) DrawService.inst.refresh();
    }

    @Override protected void onCreate(Bundle sv) {
        super.onCreate(sv);
        getWindow().setStatusBarColor(0xFF1E1B4B); getWindow().setNavigationBarColor(0xFF0F172A);
        ScrollView sc = new ScrollView(this); sc.setVerticalScrollBarEnabled(false);
        sc.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF1E1B4B, 0xFF4C1D95, 0xFF0F172A}));
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(44), dp(20), dp(28)); sc.addView(l);

        TextView title = tv("🎨 AutoDraw", 38, 0xFFFFFFFF, true);
        title.getPaint().setShader(new LinearGradient(0, 0, dp(250), 0,
            new int[]{0xFFF472B6, 0xFFFBBF24, 0xFF34D399, 0xFF60A5FA}, null, Shader.TileMode.CLAMP));
        l.addView(title);
        TextView sub = tv("Gambar line art otomatis di layar aplikasi apa pun", 14, 0xFFC7D2FE, false);
        sub.setPadding(0, dp(2), 0, dp(8)); l.addView(sub);

        status = tv("", 14, 0xFFFFFFFF, true);
        GradientDrawable sg = new GradientDrawable(); sg.setColor(0x33000000); sg.setCornerRadius(dp(30));
        status.setBackground(sg); status.setPadding(dp(16), dp(8), dp(16), dp(8));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2); sp.topMargin = dp(8); status.setLayoutParams(sp);
        l.addView(status);

        LinearLayout cm = card("⚡ Mode Menggambar", "Pilih cara AutoDraw menggambar. Bisa diganti kapan saja.", 0xFFFDE68A);
        cm.addView(modeRow(0, "🖌️", "Klasik (Pemindaian)", "Cara awal. Paling setia mengisi area hitam, tapi lebih lama."));
        cm.addView(modeRow(1, "✨", "Kontur (Cepat & Mulus)", "Garis disambung jadi jalur panjang, jauh lebih cepat. Area hitam tebal jadi garis tengah."));
        cm.addView(modeRow(2, "🧪", "Dua Jari (Eksperimen)", "Bagian atas & bawah digambar bersamaan. Bisa memicu zoom di sebagian aplikasi."));
        l.addView(cm);

        LinearLayout c1 = card("① Izin Aksesibilitas", "Aktifkan AutoDraw agar bisa menyentuh layar untuk menggambar.", 0xFFF472B6);
        c1.addView(btn("⚙️  Buka Pengaturan Aksesibilitas", 0xFFEC4899, 0xFFF97316,
            v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        l.addView(c1);

        LinearLayout c2 = card("② Pilih Gambar", "Bagian hitam gambar akan dijadikan garis (line art).", 0xFF67E8F9);
        c2.addView(btn("🖼️  Pilih Gambar Referensi", 0xFF06B6D4, 0xFF3B82F6, v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT); i.setType("image/*"); startActivityForResult(i, 1);
        }));
        prev = new ImageView(this); prev.setScaleType(ImageView.ScaleType.FIT_CENTER); prev.setBackgroundColor(0xFFFFFFFF);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(150)); pp.topMargin = dp(12);
        prev.setLayoutParams(pp); prev.setVisibility(View.GONE); c2.addView(prev);
        l.addView(c2);

        LinearLayout c3 = card("③ Mulai Menggambar", "Kotak mengambang muncul di atas aplikasi mana pun.", 0xFF86EFAC);
        c3.addView(btn("🚀  Tampilkan Kotak Mengambang", 0xFF22C55E, 0xFF14B8A6, v -> {
            if (DrawService.inst == null) toast("Aktifkan dulu AutoDraw di Aksesibilitas");
            else if (DrawService.src == null) toast("Pilih gambar dulu");
            else { DrawService.inst.show(); toast("Buka aplikasi gambar, atur kotaknya, tekan ▶"); }
        }));
        l.addView(c3);

        LinearLayout c4 = card("💡 Tips & Tombol", null, 0xFFFDE68A);
        TextView tip = tv("▶ mulai   ✕ tutup   ■ STOP berhenti\nS+/S-  kecepatan\nM  ganti mode\nT+/T-  ketebalan garis yang diambil\nD+/D-  tingkat detail\n◢ sudut kotak = resize, seret gambar = pindah\n\n" +
            "• Pakai kuas pensil kecil & warna hitam.\n• Jangan ubah zoom kanvas saat menggambar.\n" +
            "• Android 13+: jika aksesibilitas abu-abu, buka Info Aplikasi → ⋮ → Izinkan setelan terbatas.", 13, 0xFFE0E7FF, false);
        tip.setPadding(0, dp(6), 0, 0); c4.addView(tip);
        l.addView(c4);

        LinearLayout f = new LinearLayout(this); f.setOrientation(LinearLayout.VERTICAL); f.setGravity(Gravity.CENTER_HORIZONTAL);
        f.setPadding(0, dp(26), 0, 0);
        TextView a = tv("Dibuat dengan ❤️ oleh", 12, 0xFFA5B4FC, false);
        TextView b = tv("@dodosadventure", 20, 0xFFFFFFFF, true);
        b.getPaint().setShader(new LinearGradient(0, 0, dp(190), 0,
            new int[]{0xFFF472B6, 0xFFFBBF24, 0xFF34D399}, null, Shader.TileMode.CLAMP));
        f.addView(a); f.addView(b); l.addView(f);
        setContentView(sc);
        selectMode(DrawService.mode, false);

        // animasi masuk berurutan
        for (int i = 0; i < l.getChildCount(); i++) {
            View v = l.getChildAt(i);
            v.setAlpha(0f); v.setTranslationY(dp(28));
            v.animate().alpha(1f).translationY(0f).setStartDelay(60L * i).setDuration(420)
                .setInterpolator(new DecelerateInterpolator()).start();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        boolean on = DrawService.inst != null;
        status.setText(on ? "●  Aksesibilitas AKTIF" : "●  Aksesibilitas belum aktif");
        status.setTextColor(on ? 0xFF4ADE80 : 0xFFF87171);
        if (DrawService.src != null) { prev.setImageBitmap(DrawService.src); prev.setVisibility(View.VISIBLE); }
    }

    void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    @Override protected void onActivityResult(int rq, int rs, Intent d) {
        if (rq != 1 || rs != RESULT_OK || d == null) return;
        try {
            Uri u = d.getData();
            BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(getContentResolver().openInputStream(u), null, o);
            int s = 1; while (Math.max(o.outWidth, o.outHeight) / s > 2400) s *= 2;
            o = new BitmapFactory.Options(); o.inSampleSize = s;
            DrawService.src = BitmapFactory.decodeStream(getContentResolver().openInputStream(u), null, o);
            prev.setImageBitmap(DrawService.src); prev.setVisibility(View.VISIBLE);
            toast("Gambar dimuat ✅");
            if (DrawService.inst != null) DrawService.inst.refresh();
        } catch (Exception e) { toast("Gagal: " + e.getMessage()); }
    }
}
