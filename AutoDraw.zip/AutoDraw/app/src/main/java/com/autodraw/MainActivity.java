package com.autodraw;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    static final int PAPER = 0xFFF4F1EA, INK = 0xFF16181D, MUTE = 0xFF6B6F76, LINE = 0xFFD9D4C7, ACC = 0xFFE8462A;
    static final String[] UNITS = {" / 10", "", " px", " px"};
    interface IntCb { void on(int v); }

    TextView status, locCap; ImageView prev; Switch locSw, fillSw;
    View[] radio = new View[3]; LinearLayout[] rows = new LinearLayout[3];
    SeekBar[] sb = new SeekBar[4]; TextView[] sv = new TextView[4];
    final int[] mins = {1, 20, 1, 1};
    boolean syncing;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    TextView tv(String s, int sp, int color, boolean bold, boolean mono) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        t.setTypeface(mono ? Typeface.MONOSPACE : Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return t;
    }

    void press(View v) {
        v.setOnTouchListener((x, e) -> {
            int a = e.getAction();
            if (a == MotionEvent.ACTION_DOWN) x.animate().alpha(.6f).setDuration(60).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) x.animate().alpha(1f).setDuration(160).start();
            return false;
        });
    }

    Button btn(String t, int style, View.OnClickListener c) {
        Button b = new Button(this);
        b.setText(t); b.setAllCaps(false); b.setTextSize(14); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL); b.setPadding(dp(16), 0, dp(16), 0);
        GradientDrawable g = new GradientDrawable(); g.setCornerRadius(dp(8));
        if (style == 1) { g.setColor(ACC); b.setTextColor(PAPER); } else { g.setColor(0x00000000); g.setStroke(dp(1) + 1, INK); b.setTextColor(INK); }
        b.setBackground(g); b.setOnClickListener(c); press(b);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(48)); p.topMargin = dp(12);
        b.setLayoutParams(p); return b;
    }

    LinearLayout section(String no, String title, String desc) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(28); c.setLayoutParams(p);
        View line = new View(this); line.setBackgroundColor(INK); c.addView(line, new LinearLayout.LayoutParams(-1, 2));
        LinearLayout h = new LinearLayout(this); h.setGravity(Gravity.CENTER_VERTICAL); h.setPadding(0, dp(12), 0, 0);
        h.addView(tv(no, 12, ACC, true, true));
        TextView t = tv(title, 17, INK, true, false); t.setPadding(dp(10), 0, 0, 0); h.addView(t);
        c.addView(h);
        if (desc != null) { TextView d = tv(desc, 13, MUTE, false, false); d.setPadding(0, dp(4), 0, 0); c.addView(d); }
        return c;
    }

    void tint(Switch s) {
        int[][] st = {{android.R.attr.state_checked}, {}};
        s.setThumbTintList(new ColorStateList(st, new int[]{ACC, 0xFFB9B3A4}));
        s.setTrackTintList(new ColorStateList(st, new int[]{0x66E8462A, 0x33000000}));
    }

    void changed(boolean recompute) {
        Cfg.save(this);
        if (DrawService.inst != null) DrawService.inst.cfgChanged(recompute);
    }

    LinearLayout slider(final int id, String title, String hint, final int min, int max, final IntCb cb, final boolean recompute) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(0, dp(16), 0, 0);
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(tv(title, 14, INK, true, false), new LinearLayout.LayoutParams(0, -2, 1f));
        final TextView val = tv("", 13, ACC, true, true); top.addView(val); sv[id] = val;
        c.addView(top);
        c.addView(tv(hint, 12, MUTE, false, false));
        SeekBar s = new SeekBar(this); s.setMax(max - min); sb[id] = s; mins[id] = min;
        s.getProgressDrawable().setColorFilter(ACC, PorterDuff.Mode.SRC_IN);
        s.getThumb().setColorFilter(ACC, PorterDuff.Mode.SRC_IN);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar b, int p, boolean user) {
                int v = p + min; val.setText(v + UNITS[id]);
                if (user && !syncing) cb.on(v);
            }
            @Override public void onStartTrackingTouch(SeekBar b) {}
            @Override public void onStopTrackingTouch(SeekBar b) { changed(recompute); }
        });
        c.addView(s);
        return c;
    }

    LinearLayout modeRow(final int idx, String name, String desc) {
        LinearLayout r = new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(4), dp(12), dp(4), dp(12));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(2); r.setLayoutParams(p);
        View rd = new View(this); LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(dp(18), dp(18)); rp.rightMargin = dp(14);
        r.addView(rd, rp); radio[idx] = rd;
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL);
        col.addView(tv(name, 15, INK, true, false));
        col.addView(tv(desc, 12, MUTE, false, false));
        r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        r.setOnClickListener(v -> { Cfg.mode = idx; selectModeUi(); changed(true); }); press(r);
        rows[idx] = r; return r;
    }

    void selectModeUi() {
        for (int i = 0; i < 3; i++) {
            GradientDrawable g = new GradientDrawable(); g.setShape(GradientDrawable.OVAL);
            if (i == Cfg.mode) { g.setColor(ACC); g.setStroke(dp(2), ACC); } else { g.setColor(0x00000000); g.setStroke(dp(2), 0xFFB9B3A4); }
            radio[i].setBackground(g);
            GradientDrawable rb = new GradientDrawable(); rb.setCornerRadius(dp(8));
            rb.setColor(i == Cfg.mode ? 0x14000000 : 0x00000000); rows[i].setBackground(rb);
        }
    }

    void updLoc() {
        locCap.setText(Cfg.floatCtl
            ? "Aktif: panel pengaturan lengkap melayang di atas aplikasi gambar. Praktis, tapi bisa menutupi kanvas (panel bisa digeser)."
            : "Aktif: mode jangan ganggu. Layar hanya menampilkan kotak gambar dan tombol Mulai/Tutup kecil. Semua pengaturan diubah dari aplikasi ini.");
    }

    void syncUi() {
        syncing = true;
        int[] v = {Cfg.speed, Cfg.thr, Cfg.step, Cfg.brush};
        for (int i = 0; i < 4; i++) { sb[i].setProgress(v[i] - mins[i]); sv[i].setText(v[i] + UNITS[i]); }
        fillSw.setChecked(Cfg.fill); locSw.setChecked(Cfg.floatCtl); updLoc(); selectModeUi();
        syncing = false;
    }

    @Override protected void onCreate(Bundle sv0) {
        super.onCreate(sv0);
        Cfg.load(this);
        getWindow().setStatusBarColor(PAPER); getWindow().setNavigationBarColor(PAPER);
        int f = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | (Build.VERSION.SDK_INT >= 26 ? View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR : 0);
        getWindow().getDecorView().setSystemUiVisibility(f);

        ScrollView sc = new ScrollView(this); sc.setBackgroundColor(PAPER); sc.setVerticalScrollBarEnabled(false);
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(24), dp(40), dp(24), dp(32)); sc.addView(l);

        TextView title = tv("AutoDraw", 34, INK, true, false); title.setLetterSpacing(-0.02f); l.addView(title);
        TextView sub = tv("Auto-gambar line art di aplikasi gambar apa pun.", 14, MUTE, false, false);
        sub.setPadding(0, dp(2), 0, dp(14)); l.addView(sub);
        status = tv("", 12, INK, true, true); status.setCompoundDrawablePadding(dp(8)); l.addView(status);

        LinearLayout s1 = section("01", "Izin aksesibilitas", "Dibutuhkan agar AutoDraw bisa menyentuh layar.");
        s1.addView(btn("Buka pengaturan aksesibilitas  →", 0, v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        l.addView(s1);

        LinearLayout s2 = section("02", "Gambar referensi", "Bagian hitam gambar diambil sebagai garis.");
        s2.addView(btn("Pilih gambar  →", 0, v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT); i.setType("image/*"); startActivityForResult(i, 1);
        }));
        prev = new ImageView(this); prev.setScaleType(ImageView.ScaleType.FIT_CENTER);
        GradientDrawable pb = new GradientDrawable(); pb.setColor(0xFFFFFFFF); pb.setStroke(dp(1), LINE); prev.setBackground(pb);
        prev.setPadding(dp(1), dp(1), dp(1), dp(1));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(140)); pp.topMargin = dp(12);
        prev.setLayoutParams(pp); prev.setVisibility(View.GONE); s2.addView(prev);
        l.addView(s2);

        LinearLayout s3 = section("03", "Mode menggambar", "Pilih cara AutoDraw menggambar.");
        s3.addView(modeRow(0, "Klasik", "Pemindaian baris. Paling setia ke area hitam, lebih lambat."));
        s3.addView(modeRow(1, "Kontur", "Garis tengah presisi + isi area tebal. Lebih cepat dan akurat."));
        s3.addView(modeRow(2, "Dua jari", "Atas dan bawah bersamaan. Eksperimen, bisa memicu zoom."));
        l.addView(s3);

        LinearLayout s4 = section("04", "Pengaturan", "Perubahan langsung dipakai oleh kotak gambar.");
        s4.addView(slider(0, "Kecepatan menggambar", "Kecil = lambat tapi aman. Besar = cepat, tapi aplikasi gambar bisa melewatkan goresan.", 1, 10, v -> Cfg.speed = v, false));
        s4.addView(slider(1, "Batas kegelapan", "Makin besar, makin banyak warna abu-abu dihitung sebagai garis hitam.", 20, 250, v -> Cfg.thr = v, true));
        s4.addView(slider(2, "Ukuran grid (tingkat detail)", "Makin kecil makin detail dan akurat, tapi makin lama.", 1, 20, v -> Cfg.step = v, true));
        s4.addView(slider(3, "Tebal kuas di aplikasi gambar", "Samakan dengan ukuran kuas di aplikasi gambar (piksel layar). Dipakai Kontur untuk mengisi area tebal.", 1, 30, v -> Cfg.brush = v, true));

        fillSw = new Switch(this); fillSw.setText("Isi area hitam yang tebal"); fillSw.setTextSize(15); tint(fillSw);
        fillSw.setTypeface(Typeface.DEFAULT, Typeface.BOLD); fillSw.setTextColor(INK); fillSw.setPadding(0, dp(18), 0, 0);
        fillSw.setOnCheckedChangeListener((b, on) -> { if (syncing) return; Cfg.fill = on; changed(true); });
        s4.addView(fillSw);
        s4.addView(tv("Berlaku untuk Kontur dan Dua jari. Matikan jika gambarmu hanya garis tipis.", 12, MUTE, false, false));

        locSw = new Switch(this); locSw.setText("Letakkan pengaturan di layar mengambang"); locSw.setTextSize(15); tint(locSw);
        locSw.setTypeface(Typeface.DEFAULT, Typeface.BOLD); locSw.setTextColor(INK); locSw.setPadding(0, dp(22), 0, 0);
        locSw.setOnCheckedChangeListener((b, on) -> { if (syncing) return; Cfg.floatCtl = on; updLoc(); changed(false); });
        s4.addView(locSw);
        locCap = tv("", 12, MUTE, false, false); s4.addView(locCap);
        l.addView(s4);

        LinearLayout s5 = section("05", "Mulai", "Setelah kotak muncul, buka aplikasi gambar, geser kotak ke atas kanvas, lalu tekan Mulai.");
        s5.addView(btn("Tampilkan kotak gambar  →", 1, v -> {
            if (DrawService.inst == null) toast("Aktifkan AutoDraw di Aksesibilitas dulu");
            else if (DrawService.src == null) toast("Pilih gambar dulu");
            else DrawService.inst.show();
        }));
        s5.addView(btn("Tutup layar mengambang", 0, v -> { if (DrawService.inst != null) DrawService.inst.close(); }));
        l.addView(s5);

        LinearLayout st = section("--", "Catatan", null);
        TextView tip = tv("Pakai kuas pensil kecil, warna hitam.\nJangan ubah zoom kanvas saat menggambar.\n" +
            "Tombol Stop merah di pojok kanan atas layar akan muncul saat menggambar.\n" +
            "Seret kotak untuk memindah, seret sudut ◢ untuk mengubah ukuran.\n" +
            "Android 13+: bila aksesibilitas abu-abu, buka Info Aplikasi > menu > Izinkan setelan terbatas.", 12, MUTE, false, true);
        tip.setPadding(0, dp(8), 0, 0); tip.setLineSpacing(0, 1.15f); st.addView(tip);
        l.addView(st);

        String ver = "";
        try { PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0); ver = "  •  v" + pi.versionName + " (build " + pi.versionCode + ")"; } catch (Exception e) { }
        TextView credit = new TextView(this); credit.setTypeface(Typeface.MONOSPACE); credit.setTextSize(12);
        SpannableStringBuilder sb2 = new SpannableStringBuilder("dibuat oleh @dodosadventure" + ver);
        sb2.setSpan(new ForegroundColorSpan(MUTE), 0, 11, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb2.setSpan(new ForegroundColorSpan(INK), 11, 27, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb2.setSpan(new StyleSpan(Typeface.BOLD), 11, 27, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb2.setSpan(new ForegroundColorSpan(MUTE), 27, sb2.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        credit.setText(sb2); credit.setPadding(0, dp(32), 0, 0); l.addView(credit);

        setContentView(sc);
        syncUi();
        for (int i = 0; i < l.getChildCount(); i++) {
            View v = l.getChildAt(i); v.setAlpha(0f);
            v.animate().alpha(1f).setStartDelay(40L * i).setDuration(260).start();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        syncUi(); // pengaturan bisa berubah dari panel layar mengambang
        boolean on = DrawService.inst != null;
        GradientDrawable dot = new GradientDrawable(); dot.setShape(GradientDrawable.OVAL); dot.setSize(dp(8), dp(8));
        dot.setColor(on ? 0xFF2E9E5B : ACC);
        status.setCompoundDrawablesWithIntrinsicBounds(dot, null, null, null);
        status.setText(on ? "AKSESIBILITAS AKTIF" : "AKSESIBILITAS BELUM AKTIF");
        if (DrawService.src != null) { prev.setImageBitmap(DrawService.src); prev.setVisibility(View.VISIBLE); }
    }

    void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    @Override protected void onActivityResult(int rq, int rs, Intent d) {
        if (rq != 1 || rs != RESULT_OK || d == null) return;
        try {
            Uri u = d.getData();
            BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(getContentResolver().openInputStream(u), null, o);
            int s = 1; while (Math.max(o.outWidth, o.outHeight) / s > 2400) s *= 2;
            o = new BitmapFactory.Options(); o.inSampleSize = s;
            DrawService.src = BitmapFactory.decodeStream(getContentResolver().openInputStream(u), null, o);
            prev.setImageBitmap(DrawService.src); prev.setVisibility(View.VISIBLE);
            toast("Gambar dimuat");
            if (DrawService.inst != null) DrawService.inst.refresh();
        } catch (Exception e) { toast("Gagal: " + e.getMessage()); }
    }
}
