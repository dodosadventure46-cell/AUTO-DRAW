package com.autodraw;

import android.app.Activity;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    Button btn(String t, View.OnClickListener c) {
        Button b = new Button(this); b.setText(t); b.setOnClickListener(c); return b;
    }
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL); l.setPadding(40, 60, 40, 40);
        l.addView(btn("1. Aktifkan Aksesibilitas (AutoDraw)", v ->
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        l.addView(btn("2. Pilih Gambar", v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT); i.setType("image/*");
            startActivityForResult(i, 1);
        }));
        l.addView(btn("3. Tampilkan Kotak Mengambang", v -> {
            if (DrawService.inst == null) toast("Aktifkan dulu AutoDraw di Aksesibilitas");
            else if (DrawService.src == null) toast("Pilih gambar dulu");
            else DrawService.inst.show();
        }));
        TextView t = new TextView(this);
        t.setPadding(0, 40, 0, 0);
        t.setText("Cara pakai:\n• Buka Ibis Paint, pilih kuas pensil kecil (ukuran ±1-2 px), warna hitam.\n" +
            "• Tampilkan kotak, geser (seret gambar) & resize (sudut ◢) ke atas kanvas.\n" +
            "• T+/T- = ketebalan garis yg diambil, D+/D- = detail. Tekan ▶ untuk mulai, STOP untuk berhenti.\n" +
            "• Android 13+: jika aksesibilitas abu-abu, buka Info Aplikasi > ⋮ > Izinkan setelan terbatas.");
        l.addView(t);
        setContentView(l);
    }
    void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }
    @Override protected void onActivityResult(int rq, int rs, Intent d) {
        if (rq != 1 || rs != RESULT_OK || d == null) return;
        try {
            Uri u = d.getData();
            BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(getContentResolver().openInputStream(u), null, o);
            int s = 1; while (Math.max(o.outWidth, o.outHeight) / s > 2400) s *= 2;
            o = new BitmapFactory.Options(); o.inSampleSize = s;
            DrawService.src = BitmapFactory.decodeStream(getContentResolver().openInputStream(u), null, o);
            toast("Gambar dimuat");
            if (DrawService.inst != null) DrawService.inst.refresh();
        } catch (Exception e) { toast("Gagal: " + e.getMessage()); }
    }
}
