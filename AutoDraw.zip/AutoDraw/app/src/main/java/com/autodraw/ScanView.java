package com.autodraw;

import android.content.Context;
import android.graphics.*;
import android.view.View;

/** Animasi pemindaian: garis menyapu ke bawah, grid + kotak-kotak kecil muncul mengikuti garis. */
public class ScanView extends View {
    static final int ACC = 0xFFE8462A;
    final Bitmap layer;
    final Paint pl = new Paint(Paint.ANTI_ALIAS_FLAG), pb = new Paint(Paint.FILTER_BITMAP_FLAG), pg = new Paint();
    final float d;
    float p;

    ScanView(Context ctx, boolean[][] work, boolean[][] uncov, int W, int H, int cell) {
        super(ctx);
        d = ctx.getResources().getDisplayMetrics().density;
        layer = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(layer);
        int gh = work.length, gw = work[0].length;
        float cw = (float) W / gw, ch = (float) H / gh;
        int cols = (int) Math.ceil(W / (float) cell), rows = (int) Math.ceil(H / (float) cell);
        boolean[][] blk = new boolean[rows][cols];
        for (int y = 0; y < gh; y++) for (int x = 0; x < gw; x++) {
            if (work[y][x] || (uncov != null && uncov[y][x])) {
                int bx = Math.min(cols - 1, (int) ((x + .5f) * cw / cell));
                int by = Math.min(rows - 1, (int) ((y + .5f) * ch / cell));
                blk[by][bx] = true;
            }
        }
        Paint gl = new Paint(); gl.setColor(0x55E8462A); gl.setStrokeWidth(Math.max(1f, d * .6f));
        for (int i = 0; i <= cols; i++) c.drawLine(i * cell, 0, i * cell, H, gl);
        for (int j = 0; j <= rows; j++) c.drawLine(0, j * cell, W, j * cell, gl);
        Paint fp = new Paint(Paint.ANTI_ALIAS_FLAG); fp.setColor(0xDDE8462A);
        float in = cell * .18f;
        for (int j = 0; j < rows; j++) for (int i = 0; i < cols; i++) if (blk[j][i])
            c.drawRoundRect(new RectF(i * cell + in, j * cell + in, (i + 1) * cell - in, (j + 1) * cell - in), 2 * d, 2 * d, fp);
        pl.setColor(ACC);
    }

    void setProgress(float v) { p = v; invalidate(); }

    @Override protected void onDraw(Canvas cv) {
        int w = getWidth(), h = getHeight(); float y = p * h;
        cv.save(); cv.clipRect(0, 0, w, y); cv.drawBitmap(layer, null, new RectF(0, 0, w, h), pb); cv.restore();
        float band = 36 * d;
        for (int i = 0; i < 6; i++) {
            pg.setColor(((6 - i) * 14 << 24) | 0x00E8462A);
            cv.drawRect(0, y - band * (i + 1) / 6f, w, y - band * i / 6f, pg);
        }
        cv.drawRect(0, y - 1.5f * d, w, y + 1.5f * d, pl);
    }
}
