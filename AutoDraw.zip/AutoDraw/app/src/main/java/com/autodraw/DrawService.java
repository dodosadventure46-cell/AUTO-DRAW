package com.autodraw;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.widget.*;
import java.util.*;

public class DrawService extends AccessibilityService {
    static DrawService inst;
    static Bitmap src;
    static int mode = 0; // 0 Klasik, 1 Kontur, 2 Dua Jari
    static final String[] MN = {"Klasik", "Kontur", "Dua Jari"};
    static final int[] DX = {1, 0, -1, 0, 1, -1, -1, 1}, DY = {0, 1, 0, -1, 1, 1, -1, -1};

    WindowManager wm;
    FrameLayout box; ImageView iv; Button stopB;
    WindowManager.LayoutParams lp;
    int thr = 140, step = 4, spd = 5, brush = 3, gw, gh, cs = 2, workMode = 0, gen = 0;
    boolean fill = true;
    boolean[][] mask, work, uncov;
    volatile boolean stop; boolean drawing;
    Handler h = new Handler(Looper.getMainLooper());

    static class Result { boolean[][] mask, work, uncov; int gw, gh; Bitmap pv; }

    @Override protected void onServiceConnected() { inst = this; wm = (WindowManager) getSystemService(WINDOW_SERVICE); }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() {}
    @Override public boolean onUnbind(Intent i) { close(); inst = null; return super.onUnbind(i); }

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
    void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }
    long minD() { return Math.max(1, 11 - spd); }
    long gap() { return spd >= 8 ? 1 : (spd >= 5 ? 3 : 8); }

    Button mk(String t, View.OnClickListener c) {
        Button b = new Button(this); b.setText(t); b.setTextSize(10); b.setAllCaps(false);
        b.setMinWidth(0); b.setMinimumWidth(dp(34)); b.setMinHeight(0); b.setMinimumHeight(dp(30));
        b.setPadding(dp(4), 0, dp(4), 0); b.setTextColor(0xFFF4F1EA); b.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        int col = t.equals("▶") ? 0xFFE8462A : t.equals("✕") ? 0xFF3A3D45 : 0xFF2B2E36;
        GradientDrawable g = new GradientDrawable(); g.setColor(col); g.setCornerRadius(dp(6)); b.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, dp(30)); p.setMargins(dp(2), dp(2), dp(2), dp(2));
        b.setLayoutParams(p); b.setOnClickListener(c);
        b.setOnTouchListener((v, e) -> {
            int a = e.getAction();
            if (a == MotionEvent.ACTION_DOWN) v.animate().scaleX(.9f).scaleY(.9f).setDuration(70).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) v.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
            return false;
        });
        return b;
    }

    void show() {
        if (src == null) return;
        if (box != null) { refresh(); return; }
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = dm.widthPixels * 2 / 3, hh = (int) (w * (float) src.getHeight() / src.getWidth());
        lp = new WindowManager.LayoutParams(w, hh, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START; lp.x = dm.widthPixels / 6; lp.y = dm.heightPixels / 5;

        box = new FrameLayout(this);
        GradientDrawable gd = new GradientDrawable(); gd.setColor(0x22FFFFFF); gd.setStroke(dp(2), 0xFFE8462A);
        box.setBackground(gd);
        iv = new ImageView(this); iv.setScaleType(ImageView.ScaleType.FIT_XY);
        box.addView(iv, new FrameLayout.LayoutParams(-1, -1));

        final float[] d = new float[4];
        iv.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN: d[0] = e.getRawX() - lp.x; d[1] = e.getRawY() - lp.y; break;
                case MotionEvent.ACTION_MOVE: lp.x = (int) (e.getRawX() - d[0]); lp.y = (int) (e.getRawY() - d[1]);
                    wm.updateViewLayout(box, lp); break;
            }
            return true;
        });

        LinearLayout bar = new LinearLayout(this); bar.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable(); bg.setColor(0xE616181D); bg.setCornerRadius(dp(8));
        bar.setBackground(bg); bar.setPadding(dp(2), dp(2), dp(2), dp(2));
        LinearLayout r1 = new LinearLayout(this), r2 = new LinearLayout(this), r3 = new LinearLayout(this);
        r1.addView(mk("▶", v -> draw()));
        r1.addView(mk("S+", v -> { spd = Math.min(10, spd + 1); toast("Kecepatan: " + spd + "/10"); }));
        r1.addView(mk("S-", v -> { spd = Math.max(1, spd - 1); toast("Kecepatan: " + spd + "/10"); }));
        r1.addView(mk("M", v -> { mode = (mode + 1) % 3; refresh(); toast("Mode: " + MN[mode]); }));
        r1.addView(mk("✕", v -> close()));
        r2.addView(mk("T+", v -> { thr = Math.min(250, thr + 15); refresh(); toast("Gelap: " + thr); }));
        r2.addView(mk("T-", v -> { thr = Math.max(20, thr - 15); refresh(); toast("Gelap: " + thr); }));
        r2.addView(mk("D+", v -> { step = Math.max(1, step - 1); refresh(); toast("Detail: grid " + step + "px"); }));
        r2.addView(mk("D-", v -> { step = Math.min(20, step + 1); refresh(); toast("Detail: grid " + step + "px"); }));
        r3.addView(mk("B+", v -> { brush = Math.min(30, brush + 1); refresh(); toast("Kuas: " + brush + "px (samakan dgn kuas di aplikasi)"); }));
        r3.addView(mk("B-", v -> { brush = Math.max(1, brush - 1); refresh(); toast("Kuas: " + brush + "px (samakan dgn kuas di aplikasi)"); }));
        r3.addView(mk("F", v -> { fill = !fill; refresh(); toast("Isi area tebal: " + (fill ? "ON" : "OFF")); }));
        bar.addView(r1); bar.addView(r2); bar.addView(r3);
        box.addView(bar, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP));

        TextView hd = new TextView(this); hd.setText("◢"); hd.setTextSize(26); hd.setTextColor(0xFFF4F1EA);
        hd.setBackgroundColor(0xFFE8462A); hd.setGravity(Gravity.CENTER);
        box.addView(hd, new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.BOTTOM | Gravity.END));
        final int[] r = new int[4];
        hd.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN: r[0] = (int) e.getRawX(); r[1] = (int) e.getRawY(); r[2] = lp.width; r[3] = lp.height; break;
                case MotionEvent.ACTION_MOVE:
                    lp.width = Math.max(dp(120), r[2] + (int) e.getRawX() - r[0]);
                    lp.height = Math.max(dp(140), r[3] + (int) e.getRawY() - r[1]);
                    wm.updateViewLayout(box, lp); break;
                case MotionEvent.ACTION_UP: refresh(); break;
            }
            return true;
        });
        wm.addView(box, lp);
        box.setAlpha(0f); box.animate().alpha(1f).setDuration(250).start();
        box.post(this::refresh);
    }

    // ================= Pratinjau (dihitung di thread terpisah) =================
    void refresh() {
        if (box == null || src == null || iv == null) return;
        final int my = ++gen;
        final Bitmap s0 = src;
        final int W = Math.max(1, lp.width), H = Math.max(1, lp.height);
        final int c = mode == 0 ? step : Math.max(1, step / 2); // Kontur memakai grid 2x lebih halus
        final int md = mode, t = thr, b = brush; final boolean f = fill;
        new Thread(() -> {
            Result res = null;
            try { res = compute(s0, W, H, c, md, t, b, f); } catch (Throwable e) { }
            final Result rr = res;
            h.post(() -> {
                if (rr == null || my != gen || iv == null) return;
                mask = rr.mask; work = rr.work; uncov = rr.uncov; gw = rr.gw; gh = rr.gh; cs = c; workMode = md;
                BitmapDrawable bd = new BitmapDrawable(getResources(), rr.pv); bd.setFilterBitmap(false);
                iv.setImageDrawable(bd);
            });
        }).start();
    }

    static Bitmap scaleTo(Bitmap b, int tw, int th) {
        Bitmap c = b;
        while (c.getWidth() / 2 >= tw && c.getHeight() / 2 >= th)
            c = Bitmap.createScaledBitmap(c, c.getWidth() / 2, c.getHeight() / 2, true);
        return Bitmap.createScaledBitmap(c, tw, th, true);
    }

    static Result compute(Bitmap src, int W, int H, int cs, int mode, int thr, int brush, boolean fill) {
        Result r = new Result();
        int gw = Math.max(3, W / cs), gh = Math.max(3, H / cs);
        int k = 3, need = 2;
        if (mode > 0) {
            k = cs >= 3 ? 3 : (cs == 2 ? 2 : 1);
            if ((long) gw * k * gh * k > 6000000L) k = 1;
            need = k == 1 ? 1 : 2;
        }
        Bitmap s = mode == 0 ? Bitmap.createScaledBitmap(src, gw * k, gh * k, true) : scaleTo(src, gw * k, gh * k);
        int[] px = new int[gw * k * gh * k]; s.getPixels(px, 0, gw * k, 0, 0, gw * k, gh * k);
        boolean[][] mask = new boolean[gh][gw];
        for (int y = 0; y < gh; y++) for (int x = 0; x < gw; x++) {
            int cnt = 0;
            for (int j = 0; j < k; j++) for (int i = 0; i < k; i++) {
                int c = px[(y * k + j) * gw * k + x * k + i];
                int a = c >>> 24, l = (((c >> 16) & 255) * 299 + ((c >> 8) & 255) * 587 + (c & 255) * 114) / 1000;
                if (a > 128 && l < thr) cnt++;
            }
            mask[y][x] = cnt >= need;
        }
        boolean[][] work = mask, uncov = new boolean[gh][gw];
        if (mode > 0) {
            work = thin(mask);
            prune(work, Math.max(3, (int) (8f / cs)));
            if (fill) {
                boolean[][] cov = new boolean[gh][gw];
                float rcf = brush / (2f * cs); int rc = (int) Math.floor(rcf); float r2 = rcf * rcf;
                for (int y = 0; y < gh; y++) for (int x = 0; x < gw; x++) {
                    if (!work[y][x]) continue;
                    for (int dy = -rc; dy <= rc; dy++) for (int dx = -rc; dx <= rc; dx++) {
                        int ty = y + dy, tx = x + dx;
                        if (ty < 0 || tx < 0 || ty >= gh || tx >= gw) continue;
                        if ((dx == 0 && dy == 0) || dx * dx + dy * dy <= r2) cov[ty][tx] = true;
                    }
                }
                for (int y = 0; y < gh; y++) for (int x = 0; x < gw; x++) uncov[y][x] = mask[y][x] && !cov[y][x];
                boolean[][] u2 = new boolean[gh][gw];
                for (int y = 0; y < gh; y++) for (int x = 0; x < gw; x++) {
                    if (!uncov[y][x]) continue;
                    int n = 0;
                    for (int d = 0; d < 8; d++) { int ty = y + DY[d], tx = x + DX[d]; if (ty >= 0 && tx >= 0 && ty < gh && tx < gw && uncov[ty][tx]) n++; }
                    u2[y][x] = n > 0;
                }
                uncov = u2;
            }
        }
        Bitmap pv = Bitmap.createBitmap(gw, gh, Bitmap.Config.ARGB_8888);
        for (int y = 0; y < gh; y++) for (int x = 0; x < gw; x++) {
            if (work[y][x]) pv.setPixel(x, y, 0xCCE8462A); else if (uncov[y][x]) pv.setPixel(x, y, 0x66E8462A);
        }
        r.mask = mask; r.work = work; r.uncov = uncov; r.gw = gw; r.gh = gh; r.pv = pv;
        return r;
    }

    // Zhang-Suen thinning -> garis tengah 1 piksel
    static boolean[][] thin(boolean[][] m) {
        int H = m.length, W = m[0].length;
        boolean[][] a = new boolean[H][W];
        for (int y = 0; y < H; y++) System.arraycopy(m[y], 0, a[y], 0, W);
        int[] buf = new int[W * H];
        boolean changed = true;
        while (changed) {
            changed = false;
            for (int pass = 0; pass < 2; pass++) {
                int n = 0;
                for (int y = 1; y < H - 1; y++) for (int x = 1; x < W - 1; x++) {
                    if (!a[y][x]) continue;
                    boolean p2 = a[y - 1][x], p3 = a[y - 1][x + 1], p4 = a[y][x + 1], p5 = a[y + 1][x + 1],
                            p6 = a[y + 1][x], p7 = a[y + 1][x - 1], p8 = a[y][x - 1], p9 = a[y - 1][x - 1];
                    int B = (p2 ? 1 : 0) + (p3 ? 1 : 0) + (p4 ? 1 : 0) + (p5 ? 1 : 0) + (p6 ? 1 : 0) + (p7 ? 1 : 0) + (p8 ? 1 : 0) + (p9 ? 1 : 0);
                    if (B < 2 || B > 6) continue;
                    int A = (!p2 && p3 ? 1 : 0) + (!p3 && p4 ? 1 : 0) + (!p4 && p5 ? 1 : 0) + (!p5 && p6 ? 1 : 0)
                          + (!p6 && p7 ? 1 : 0) + (!p7 && p8 ? 1 : 0) + (!p8 && p9 ? 1 : 0) + (!p9 && p2 ? 1 : 0);
                    if (A != 1) continue;
                    if (pass == 0) { if ((p2 && p4 && p6) || (p4 && p6 && p8)) continue; }
                    else { if ((p2 && p4 && p8) || (p2 && p6 && p8)) continue; }
                    buf[n++] = y * W + x;
                }
                for (int i = 0; i < n; i++) a[buf[i] / W][buf[i] % W] = false;
                if (n > 0) changed = true;
            }
        }
        return a;
    }

    static int trans(boolean[][] a, int y, int x) {
        if (y < 1 || x < 1 || y >= a.length - 1 || x >= a[0].length - 1) return 0;
        boolean p2 = a[y - 1][x], p3 = a[y - 1][x + 1], p4 = a[y][x + 1], p5 = a[y + 1][x + 1],
                p6 = a[y + 1][x], p7 = a[y + 1][x - 1], p8 = a[y][x - 1], p9 = a[y - 1][x - 1];
        return (!p2 && p3 ? 1 : 0) + (!p3 && p4 ? 1 : 0) + (!p4 && p5 ? 1 : 0) + (!p5 && p6 ? 1 : 0)
             + (!p6 && p7 ? 1 : 0) + (!p7 && p8 ? 1 : 0) + (!p8 && p9 ? 1 : 0) + (!p9 && p2 ? 1 : 0);
    }

    static int bcount(boolean[][] a, int y, int x) {
        int n = 0;
        for (int d = 0; d < 8; d++) { int ty = y + DY[d], tx = x + DX[d]; if (ty >= 0 && tx >= 0 && ty < a.length && tx < a[0].length && a[ty][tx]) n++; }
        return n;
    }

    // Buang cabang pendek (duri) yang muncul dari proses thinning
    static void prune(boolean[][] a, int L) {
        int H = a.length, W = a[0].length;
        for (int it = 0; it < 2; it++) {
            for (int y = 1; y < H - 1; y++) for (int x = 1; x < W - 1; x++) {
                if (!a[y][x] || bcount(a, y, x) != 1) continue;
                ArrayList<Integer> br = new ArrayList<>();
                int cy = y, cx = x; boolean hit = false;
                for (int s = 0; s <= L + 1; s++) {
                    if (s > 0 && trans(a, cy, cx) >= 3) { hit = true; break; }
                    br.add(cy * W + cx);
                    int nd = -1;
                    for (int d = 0; d < 8; d++) {
                        int ty = cy + DY[d], tx = cx + DX[d];
                        if (ty < 1 || tx < 1 || ty >= H - 1 || tx >= W - 1 || !a[ty][tx]) continue;
                        if (br.contains(ty * W + tx)) continue;
                        nd = d; break;
                    }
                    if (nd < 0) break;
                    cy += DY[nd]; cx += DX[nd];
                }
                if (hit && br.size() <= L) for (int c : br) a[c / W][c % W] = false;
            }
        }
    }

    // ================= Pembuat goresan =================
    // Pemindaian baris + kolom (dipakai Klasik, dan untuk mengisi area tebal di Kontur)
    ArrayList<float[]> scanRuns(boolean[][] m, float ox, float oy) {
        ArrayList<float[]> r = new ArrayList<>();
        int GH = m.length, GW = m[0].length;
        boolean[][] cov = new boolean[GH][GW];
        float cw = (float) iv.getWidth() / GW, ch = (float) iv.getHeight() / GH;
        for (int y = 0; y < GH; y++) {
            int x = 0;
            while (x < GW) {
                if (!m[y][x]) { x++; continue; }
                int s = x; while (x < GW && m[y][x]) x++;
                if (x - s >= 2) {
                    for (int q = s; q < x; q++) cov[y][q] = true;
                    r.add(new float[]{ox + (s + .5f) * cw, oy + (y + .5f) * ch, ox + (x - .5f) * cw, oy + (y + .5f) * ch});
                }
            }
        }
        for (int x = 0; x < GW; x++) {
            int y = 0;
            while (y < GH) {
                if (!m[y][x] || cov[y][x]) { y++; continue; }
                int s = y; while (y < GH && m[y][x] && !cov[y][x]) y++;
                r.add(new float[]{ox + (x + .5f) * cw, oy + (s + .5f) * ch, ox + (x + .5f) * cw, oy + (y - .5f) * ch});
            }
        }
        return r;
    }

    boolean free(int y, int x, boolean[][] vis) { return y >= 0 && x >= 0 && y < gh && x < gw && work[y][x] && !vis[y][x]; }

    int nbrs(int y, int x) {
        int n = 0;
        for (int d = 0; d < 8; d++) { int ny = y + DY[d], nx = x + DX[d]; if (ny >= 0 && nx >= 0 && ny < gh && nx < gw && work[ny][nx]) n++; }
        return n;
    }

    // Jalan menyusuri garis tengah, di persimpangan pilih arah yang paling lurus
    ArrayList<Integer> walk(int y, int x, boolean[][] vis, float[] init) {
        ArrayList<Integer> r = new ArrayList<>();
        int cy = y, cx = x;
        while (true) {
            float vx = 0, vy = 0; int n = r.size();
            if (n > 0) {
                int back = Math.min(n, 4), bi = n - 1 - back;
                int pi = bi >= 0 ? r.get(bi) : y * gw + x;
                vy = cy - pi / gw; vx = cx - pi % gw;
            } else if (init != null) { vx = init[0]; vy = init[1]; }
            float vl = (float) Math.hypot(vx, vy);
            int best = -1; float bs = -10;
            for (int d = 0; d < 8; d++) {
                if (!free(cy + DY[d], cx + DX[d], vis)) continue;
                float sc = vl > 0 ? (DX[d] * vx + DY[d] * vy) / (vl * (float) Math.hypot(DX[d], DY[d])) : 0;
                sc += d < 4 ? 0.01f : 0f; sc -= d * 1e-4f;
                if (sc > bs) { bs = sc; best = d; }
            }
            if (best < 0) break;
            cy += DY[best]; cx += DX[best]; vis[cy][cx] = true; r.add(cy * gw + cx);
        }
        return r;
    }

    int adj(int idx, int[][] pid) {
        int cy = idx / gw, cx = idx % gw;
        for (int d = 0; d < 8; d++) {
            int ty = cy + DY[d], tx = cx + DX[d];
            if (ty >= 0 && tx >= 0 && ty < gh && tx < gw && pid[ty][tx] > 0) return ty * gw + tx;
        }
        return -1;
    }

    // Kontur: telusuri garis tengah -> sambungkan di persimpangan -> haluskan -> sederhanakan
    ArrayList<float[]> trace(float ox, float oy) {
        float cw = (float) iv.getWidth() / gw, ch = (float) iv.getHeight() / gh;
        boolean[][] vis = new boolean[gh][gw]; int[][] pid = new int[gh][gw]; int nid = 0;
        ArrayList<float[]> out = new ArrayList<>();
        float eps = Math.max(0.6f, 1.2f / cs);
        for (int pass = 0; pass < 2; pass++)
            for (int y = 0; y < gh; y++) for (int x = 0; x < gw; x++) {
                if (!work[y][x] || vis[y][x]) continue;
                if (pass == 0 && nbrs(y, x) != 1) continue;
                vis[y][x] = true;
                ArrayList<Integer> fwd = walk(y, x, vis, null);
                float[] init = null;
                if (!fwd.isEmpty()) { int fi = fwd.get(Math.min(3, fwd.size() - 1)); init = new float[]{x - fi % gw, y - fi / gw}; }
                ArrayList<Integer> bwd = walk(y, x, vis, init);
                ArrayList<Integer> cells = new ArrayList<>();
                for (int i = bwd.size() - 1; i >= 0; i--) cells.add(bwd.get(i));
                cells.add(y * gw + x); cells.addAll(fwd);
                int n = cells.size();
                int a0 = adj(cells.get(0), pid), a1 = adj(cells.get(n - 1), pid);
                nid++;
                for (int c : cells) pid[c / gw][c % gw] = nid;
                if (n <= 2 && (a0 >= 0 || a1 >= 0)) continue; // serpihan sisa di dekat persimpangan
                if (a0 >= 0) cells.add(0, a0);
                if (a1 >= 0 && a1 != a0) cells.add(a1);
                else if (a1 < 0 && n >= 6) {
                    int f0 = cells.get(0), l = cells.get(cells.size() - 1);
                    if (f0 != l && Math.abs(f0 / gw - l / gw) <= 1 && Math.abs(f0 % gw - l % gw) <= 1) cells.add(f0);
                }
                int m = cells.size();
                float[] px = new float[m], py = new float[m];
                for (int i = 0; i < m; i++) { px[i] = cells.get(i) % gw; py[i] = cells.get(i) / gw; }
                if (m >= 5) {
                    float[] sx = new float[m], sy = new float[m];
                    for (int i = 0; i < m; i++) {
                        int rr = Math.min(2, Math.min(i, m - 1 - i)); float ax = 0, ay = 0;
                        for (int j = i - rr; j <= i + rr; j++) { ax += px[j]; ay += py[j]; }
                        sx[i] = ax / (2 * rr + 1); sy[i] = ay / (2 * rr + 1);
                    }
                    px = sx; py = sy;
                }
                boolean[] keep = new boolean[m]; keep[0] = true; keep[m - 1] = true;
                if (m > 2) rdp(px, py, 0, m - 1, eps, keep);
                int cnt = 0; for (boolean b : keep) if (b) cnt++;
                float[] s = new float[cnt * 2]; int q = 0;
                for (int i = 0; i < m; i++) if (keep[i]) { s[q++] = ox + (px[i] + .5f) * cw; s[q++] = oy + (py[i] + .5f) * ch; }
                if (cnt == 1) s = new float[]{s[0], s[1], s[0], s[1]};
                out.add(s);
            }
        return out;
    }

    void rdp(float[] px, float[] py, int a, int b, float eps, boolean[] keep) {
        if (b <= a + 1) return;
        float dx = px[b] - px[a], dy = py[b] - py[a], len = (float) Math.sqrt(dx * dx + dy * dy);
        int idx = -1; float md = eps;
        for (int i = a + 1; i < b; i++) {
            float d = len == 0 ? (float) Math.hypot(px[i] - px[a], py[i] - py[a])
                    : Math.abs(dy * (px[i] - px[a]) - dx * (py[i] - py[a])) / len;
            if (d > md) { md = d; idx = i; }
        }
        if (idx >= 0) { keep[idx] = true; rdp(px, py, a, idx, eps, keep); rdp(px, py, idx, b, eps, keep); }
    }

    float plen(float[] s) {
        float l = 0;
        for (int k = 2; k + 1 < s.length; k += 2) l += (float) Math.hypot(s[k] - s[k - 2], s[k + 1] - s[k - 1]);
        return l;
    }

    float[] rev(float[] s) {
        float[] r = new float[s.length];
        for (int i = 0; i < s.length; i += 2) { r[i] = s[s.length - 2 - i]; r[i + 1] = s[s.length - 1 - i]; }
        return r;
    }

    // Urutan goresan terdekat (kurangi lompatan jari)
    ArrayList<float[]> order(ArrayList<float[]> in) {
        int n = in.size();
        if (n < 2 || n > 8000) return in;
        boolean[] used = new boolean[n];
        ArrayList<float[]> out = new ArrayList<>(n);
        used[0] = true; out.add(in.get(0));
        float[] c = in.get(0); float ex = c[c.length - 2], ey = c[c.length - 1];
        for (int k = 1; k < n; k++) {
            int bi = -1; boolean rv = false; float bd = Float.MAX_VALUE;
            for (int i = 0; i < n; i++) {
                if (used[i]) continue;
                float[] s = in.get(i);
                float d1 = (s[0] - ex) * (s[0] - ex) + (s[1] - ey) * (s[1] - ey);
                float d2 = (s[s.length - 2] - ex) * (s[s.length - 2] - ex) + (s[s.length - 1] - ey) * (s[s.length - 1] - ey);
                if (d1 < bd) { bd = d1; bi = i; rv = false; }
                if (d2 < bd) { bd = d2; bi = i; rv = true; }
            }
            used[bi] = true; float[] s = in.get(bi); if (rv) s = rev(s);
            out.add(s); ex = s[s.length - 2]; ey = s[s.length - 1];
        }
        return out;
    }

    ArrayList<ArrayList<float[]>> split(ArrayList<float[]> st) {
        ArrayList<float[]> c = new ArrayList<>(st);
        Collections.sort(c, (a, b) -> Float.compare(a[1], b[1]));
        float tot = 0; for (float[] s : c) tot += plen(s) + 2;
        ArrayList<float[]> A = new ArrayList<>(), B = new ArrayList<>();
        float acc = 0;
        for (float[] s : c) { if (acc < tot / 2) A.add(s); else B.add(s); acc += plen(s) + 2; }
        ArrayList<ArrayList<float[]>> r = new ArrayList<>();
        r.add(order(A)); r.add(order(B));
        return r;
    }

    // ================= Eksekusi =================
    long addS(GestureDescription.Builder g, float[] s, long t) {
        Path p = new Path(); p.moveTo(s[0], s[1]);
        float len = 0;
        for (int k = 2; k + 1 < s.length; k += 2) {
            len += (float) Math.hypot(s[k] - s[k - 2], s[k + 1] - s[k - 1]);
            p.lineTo(s[k], s[k + 1]);
        }
        if (len < 1) p.lineTo(s[0] + 1, s[1]);
        long d = Math.min(30000L, (long) Math.max(minD(), len / spd));
        g.addStroke(new GestureDescription.StrokeDescription(p, t, d));
        return d;
    }

    void draw() {
        if (drawing || work == null || iv == null) return;
        if (workMode != mode) { toast("Pratinjau masih dihitung, coba lagi sebentar"); return; }
        final int md = workMode;
        int[] loc = new int[2]; iv.getLocationOnScreen(loc);
        ArrayList<float[]> st;
        if (md == 0) st = scanRuns(work, loc[0], loc[1]);
        else { st = trace(loc[0], loc[1]); st.addAll(scanRuns(uncov, loc[0], loc[1])); }
        if (st.isEmpty()) { toast("Tidak ada garis hitam terdeteksi"); return; }
        final ArrayList<float[]> A, B;
        if (md == 2) { ArrayList<ArrayList<float[]>> sp = split(st); A = sp.get(0); B = sp.get(1); }
        else { A = md == 1 ? order(st) : st; B = null; }
        drawing = true; stop = false;
        toast("Mode " + MN[md] + " • " + st.size() + " goresan");
        box.animate().cancel(); box.setAlpha(0f);
        lp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE; wm.updateViewLayout(box, lp);
        stopB = new Button(this); stopB.setText("■ STOP"); stopB.setTextColor(0xFFF4F1EA); stopB.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        GradientDrawable sg = new GradientDrawable(); sg.setColor(0xFFE8462A); sg.setCornerRadius(dp(8)); stopB.setBackground(sg);
        stopB.setOnClickListener(v -> stop = true);
        WindowManager.LayoutParams sp = new WindowManager.LayoutParams(-2, -2,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        sp.gravity = Gravity.TOP | Gravity.END; sp.x = dp(8); sp.y = dp(8);
        wm.addView(stopB, sp);
        h.postDelayed(() -> { if (B == null) run(A, 0); else run2(A, B, 0); }, 500);
    }

    void run(final ArrayList<float[]> st, final int i) {
        if (stop || i >= st.size()) { finish(); return; }
        GestureDescription.Builder g = new GestureDescription.Builder();
        long t = 0; int e = i; int max = Math.min(GestureDescription.getMaxStrokeCount(), 20);
        while (e < st.size() && e - i < max && (e == i || t < 15000)) { t += addS(g, st.get(e), t) + gap(); e++; }
        final int end = e;
        boolean ok = dispatchGesture(g.build(), new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gd) { run(st, end); }
            @Override public void onCancelled(GestureDescription gd) { run(st, end); }
        }, null);
        if (!ok) finish();
    }

    void run2(final ArrayList<float[]> A, final ArrayList<float[]> B, final int i) {
        int n = Math.max(A.size(), B.size());
        if (stop || i >= n) { finish(); return; }
        GestureDescription.Builder g = new GestureDescription.Builder();
        long t = 0; int e = i; int per = Math.max(1, Math.min(GestureDescription.getMaxStrokeCount(), 20) / 2);
        while (e < n && e - i < per && (e == i || t < 15000)) {
            long dA = e < A.size() ? addS(g, A.get(e), t) : 0;
            long dB = e < B.size() ? addS(g, B.get(e), t) : 0;
            t += Math.max(dA, dB) + gap(); e++;
        }
        final int end = e;
        boolean ok = dispatchGesture(g.build(), new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gd) { run2(A, B, end); }
            @Override public void onCancelled(GestureDescription gd) { run2(A, B, end); }
        }, null);
        if (!ok) finish();
    }

    void finish() {
        drawing = false;
        if (stopB != null) { try { wm.removeView(stopB); } catch (Exception e) {} stopB = null; }
        if (box != null) {
            lp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE; wm.updateViewLayout(box, lp);
            box.animate().alpha(1f).setDuration(200).start();
        }
        toast("Selesai");
    }

    void close() {
        stop = true; drawing = false; gen++;
        if (stopB != null) { try { wm.removeView(stopB); } catch (Exception e) {} stopB = null; }
        if (box != null) {
            final FrameLayout b = box; box = null; iv = null;
            b.animate().alpha(0f).setDuration(150).withEndAction(() -> { try { wm.removeView(b); } catch (Exception e) {} }).start();
        }
    }
}
