package com.autodraw;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.widget.*;
import java.util.ArrayList;

public class DrawService extends AccessibilityService {
    static DrawService inst;
    static Bitmap src;
    WindowManager wm;
    FrameLayout box; ImageView iv; Button stopB;
    WindowManager.LayoutParams lp;
    int thr = 140, step = 4, spd = 5, gw, gh;
    boolean[][] mask;
    volatile boolean stop; boolean drawing;
    Handler h = new Handler(Looper.getMainLooper());

    @Override protected void onServiceConnected() { inst = this; wm = (WindowManager) getSystemService(WINDOW_SERVICE); }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() {}
    @Override public boolean onUnbind(Intent i) { close(); inst = null; return super.onUnbind(i); }

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    Button mk(String t, View.OnClickListener c) {
        Button b = new Button(this); b.setText(t); b.setTextSize(10); b.setAllCaps(false);
        b.setMinWidth(0); b.setMinimumWidth(dp(34)); b.setMinHeight(0); b.setMinimumHeight(dp(30));
        b.setPadding(dp(4), 0, dp(4), 0); b.setTextColor(0xFFFFFFFF); b.setTypeface(null, Typeface.BOLD);
        int col = t.equals("▶") ? 0xFF22C55E : t.equals("✕") ? 0xFFEF4444 : t.startsWith("S") ? 0xFFF59E0B
                : t.startsWith("T") ? 0xFF3B82F6 : 0xFF8B5CF6;
        GradientDrawable g = new GradientDrawable(); g.setColor(col); g.setCornerRadius(dp(9)); b.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, dp(30)); p.setMargins(dp(2), dp(2), dp(2), dp(2));
        b.setLayoutParams(p); b.setOnClickListener(c); return b;
    }

    void show() {
        if (src == null) return;
        if (box != null) { refresh(); return; }
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = dm.widthPixels * 2 / 3, hh = (int) (w * (float) src.getHeight() / src.getWidth());
        lp = new WindowManager.LayoutParams(w, hh, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START; lp.x = dm.widthPixels / 6; lp.y = dm.heightPixels / 5;

        box = new FrameLayout(this);
        GradientDrawable gd = new GradientDrawable(); gd.setColor(0x22FFFFFF); gd.setStroke(dp(2), 0xFFEC4899);
        box.setBackground(gd);
        iv = new ImageView(this); iv.setScaleType(ImageView.ScaleType.FIT_XY);
        box.addView(iv, new FrameLayout.LayoutParams(-1, -1));

        final float[] d = new float[4];
        iv.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN: d[0] = e.getRawX() - lp.x; d[1] = e.getRawY() - lp.y; break;
                case MotionEvent.ACTION_MOVE: lp.x = (int) (e.getRawX() - d[0]); lp.y = (int) (e.getRawY() - d[1]);
                    wm.updateViewLayout(box, lp); break;
            }
            return true;
        });

        LinearLayout bar = new LinearLayout(this); bar.setOrientation(LinearLayout.VERTICAL); GradientDrawable bg = new GradientDrawable(); bg.setColor(0xCC1E1B4B); bg.setCornerRadius(dp(12)); bar.setBackground(bg); bar.setPadding(dp(2), dp(2), dp(2), dp(2));
        LinearLayout r1 = new LinearLayout(this), r2 = new LinearLayout(this);
        r1.addView(mk("▶", v -> draw()));
        r1.addView(mk("S+", v -> { spd = Math.min(10, spd + 1); toast("Kecepatan: " + spd + "/10"); }));
        r1.addView(mk("S-", v -> { spd = Math.max(1, spd - 1); toast("Kecepatan: " + spd + "/10"); }));
        r1.addView(mk("✕", v -> close()));
        r2.addView(mk("T+", v -> { thr = Math.min(250, thr + 15); refresh(); toast("Gelap: " + thr); }));
        r2.addView(mk("T-", v -> { thr = Math.max(20, thr - 15); refresh(); toast("Gelap: " + thr); }));
        r2.addView(mk("D+", v -> { step = Math.max(1, step - 1); refresh(); toast("Detail: grid " + step + "px"); }));
        r2.addView(mk("D-", v -> { step = Math.min(20, step + 1); refresh(); toast("Detail: grid " + step + "px"); }));
        bar.addView(r1); bar.addView(r2);
        box.addView(bar, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP));

        TextView hd = new TextView(this); hd.setText("◢"); hd.setTextSize(26); hd.setTextColor(0xFFEC4899);
        hd.setBackgroundColor(0x66FFFFFF); hd.setGravity(Gravity.CENTER);
        box.addView(hd, new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.BOTTOM | Gravity.END));
        final int[] r = new int[4];
        hd.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN: r[0] = (int) e.getRawX(); r[1] = (int) e.getRawY(); r[2] = lp.width; r[3] = lp.height; break;
                case MotionEvent.ACTION_MOVE:
                    lp.width = Math.max(dp(120), r[2] + (int) e.getRawX() - r[0]);
                    lp.height = Math.max(dp(120), r[3] + (int) e.getRawY() - r[1]);
                    wm.updateViewLayout(box, lp); break;
                case MotionEvent.ACTION_UP: refresh(); break;
            }
            return true;
        });
        wm.addView(box, lp);
        box.post(this::refresh);
    }

    void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    void refresh() {
        if (box == null || src == null) return;
        int W = Math.max(1, lp.width), H = Math.max(1, lp.height);
        gw = Math.max(1, W / step); gh = Math.max(1, H / step);
        final int k = 3;
        Bitmap s = Bitmap.createScaledBitmap(src, gw * k, gh * k, true);
        int[] px = new int[gw * k * gh * k]; s.getPixels(px, 0, gw * k, 0, 0, gw * k, gh * k);
        mask = new boolean[gh][gw];
        Bitmap pv = Bitmap.createBitmap(gw, gh, Bitmap.Config.ARGB_8888);
        for (int y = 0; y < gh; y++) for (int x = 0; x < gw; x++) {
            int cnt = 0;
            for (int j = 0; j < k; j++) for (int i = 0; i < k; i++) {
                int c = px[(y * k + j) * gw * k + x * k + i];
                int a = c >>> 24, l = (((c >> 16) & 255) * 299 + ((c >> 8) & 255) * 587 + (c & 255) * 114) / 1000;
                if (a > 128 && l < thr) cnt++;
            }
            boolean dk = cnt >= 2; mask[y][x] = dk;
            if (dk) pv.setPixel(x, y, 0xCCFF0000);
        }
        BitmapDrawable bd = new BitmapDrawable(getResources(), pv); bd.setFilterBitmap(false);
        iv.setImageDrawable(bd);
    }

    ArrayList<float[]> strokes(float ox, float oy) {
        ArrayList<float[]> r = new ArrayList<>();
        boolean[][] cov = new boolean[gh][gw];
        float cw = (float) iv.getWidth() / gw, ch = (float) iv.getHeight() / gh;
        for (int y = 0; y < gh; y++) {
            int x = 0;
            while (x < gw) {
                if (!mask[y][x]) { x++; continue; }
                int s = x; while (x < gw && mask[y][x]) x++;
                if (x - s >= 2) {
                    for (int q = s; q < x; q++) cov[y][q] = true;
                    r.add(new float[]{ox + (s + .5f) * cw, oy + (y + .5f) * ch, ox + (x - .5f) * cw, oy + (y + .5f) * ch});
                }
            }
        }
        for (int x = 0; x < gw; x++) {
            int y = 0;
            while (y < gh) {
                if (!mask[y][x] || cov[y][x]) { y++; continue; }
                int s = y; while (y < gh && mask[y][x] && !cov[y][x]) y++;
                r.add(new float[]{ox + (x + .5f) * cw, oy + (s + .5f) * ch, ox + (x + .5f) * cw, oy + (y - .5f) * ch});
            }
        }
        return r;
    }

    void draw() {
        if (drawing || mask == null) return;
        int[] loc = new int[2]; iv.getLocationOnScreen(loc);
        final ArrayList<float[]> st = strokes(loc[0], loc[1]);
        if (st.isEmpty()) { toast("Tidak ada garis hitam terdeteksi"); return; }
        drawing = true; stop = false;
        box.setAlpha(0f); lp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE; wm.updateViewLayout(box, lp);
        stopB = new Button(this); stopB.setText("■ STOP"); stopB.setBackgroundColor(0xFFEF4444); stopB.setTextColor(0xFFFFFFFF);
        stopB.setOnClickListener(v -> stop = true);
        WindowManager.LayoutParams sp = new WindowManager.LayoutParams(-2, -2,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        sp.gravity = Gravity.TOP | Gravity.END; wm.addView(stopB, sp);
        h.postDelayed(() -> run(st, 0), 500);
    }

    void run(final ArrayList<float[]> st, final int i) {
        if (stop || i >= st.size()) { finish(); return; }
        GestureDescription.Builder g = new GestureDescription.Builder();
        long t = 0; final int end = Math.min(i + Math.min(GestureDescription.getMaxStrokeCount(), 20), st.size());
        long minD = Math.max(1, 11 - spd), gap = spd >= 8 ? 1 : (spd >= 5 ? 3 : 8);
        for (int j = i; j < end; j++) {
            float[] s = st.get(j);
            Path p = new Path(); p.moveTo(s[0], s[1]);
            float len = Math.abs(s[2] - s[0]) + Math.abs(s[3] - s[1]);
            p.lineTo(s[2] + (len < 1 ? 1 : 0), s[3]);
            long d = (long) Math.max(minD, len / spd);
            g.addStroke(new GestureDescription.StrokeDescription(p, t, d));
            t += d + gap;
        }
        boolean ok = dispatchGesture(g.build(), new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gd) { run(st, end); }
            @Override public void onCancelled(GestureDescription gd) { run(st, end); }
        }, null);
        if (!ok) finish();
    }

    void finish() {
        drawing = false;
        if (stopB != null) { try { wm.removeView(stopB); } catch (Exception e) {} stopB = null; }
        if (box != null) { box.setAlpha(1f); lp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE; wm.updateViewLayout(box, lp); }
        toast("Selesai");
    }

    void close() {
        stop = true;
        if (stopB != null) { try { wm.removeView(stopB); } catch (Exception e) {} stopB = null; }
        if (box != null) { try { wm.removeView(box); } catch (Exception e) {} box = null; }
        drawing = false;
    }
}
